#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int M,T,topp = -1;

int isEmpty()
{
    if(topp==-1)
        return 1;
    return 0;
}

int top(int arr[])
{
    if(isEmpty())
        return -1;
    return arr[topp];
}

int push(int arr[],int data)
{
    if(topp==M-1)
    {
        return -1;
    }

    topp++;
    arr[topp]=data;
    return 1;
}

int pop(int arr[])
{
    if(isEmpty())
        return -1;
    int temp=arr[topp];
    topp--;
    return temp;
}

int main()
{
    scanf("%d",&M);
    scanf("%d",&T);

    int arr[M-1],K;
    char opt[10];
    int i=0;
    while(i<T)
    {
    scanf("%s",opt);
    
    if(!strcmp("pop",opt))
        printf("%d\n",pop(arr));
    else if(!strcmp("push",opt))
    	{
    	scanf("%d",&K);
        printf("%d\n",push(arr,K));
        }
    else if(!strcmp("isEmpty",opt) || !strcmp("isempty",opt))
    {
    	printf("%d\n",isEmpty());
    }
    else if(!strcmp("top",opt))
    {
    	printf("%d\n",top(arr));
    }
    else
    {
    	continue;
    }
    i++;
    }
    return 0;
} 

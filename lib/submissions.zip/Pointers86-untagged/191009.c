#include<stdio.h>
#include<stdlib.h>
typedef struct stack{
    int *arr;
    int top;
    }stack;
stack s;
int isempty()
{
    if(s.top==-1)
        return 0;
    return 1;
}
void push(int ele,int n)
{
    s.top++;
    if(s.top==n)
    	{printf("-1\n");s.top--;}
    else{s.arr[s.top]=ele;
    printf("1\n");}
    
}

void pop()
{
    if(!isempty())
        printf("-1\n");
    else{int b=s.arr[s.top];
    s.top--;
    printf("%d\n", b);}
}
void top()
{
    if(!isempty())
        printf("-1\n");
    else printf("%d\n", s.arr[s.top]);
}

int main()
{
	int n,t,k,ele;
	s.top=-1;
	scanf("%d",&n);
	s.arr=(int*)malloc(n*sizeof(int));
	scanf("%d",&t);
	char str[20];
	do{
	scanf("%s",str);
	if(strcmp(str,"push")==0)
	{
	scanf("%d",&ele);
	push(ele,n);
	}
	if(strcmp(str,"top")==0)
	top();
	if(strcmp(str,"isempty")==0)
	{if(!isempty())
		printf("1\n");
	else printf("0\n");}
       	if(strcmp(str,"pop")==0)
	pop();
	t--;
	}while(t>0);
	return 0;
	
}

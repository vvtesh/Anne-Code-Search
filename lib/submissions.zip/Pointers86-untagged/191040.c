#include <stdio.h>
#include <string.h>
struct stack
     {
        int stk[50];
        int top;
        int max;
     }str;

void init()
{
    str.top=-1;
}
void pop()
{
    if(str.top==-1)
        printf("-1\n");
    else
    {
        printf("%d\n",str.stk[str.top]);

        (str.top)--;
    }
}
void push(int no)
{
    if(str.top==(str.max-1))

        printf("-1\n");
    else
    {
 printf("1\n");
        str.top++;
        str.stk[str.top]=no;
    }
}
void display()
{
    int x=0;
int in=0;
    printf("\n");
    printf("%d->",str.stk[x]);
    in++;
    while(in<=(str.top))
    {
        printf("%d->",str.stk[x]);
        x++;
    }
}
int main()
{
    init();
    int t,no;char x[10]="";
    scanf("%d",&str.max);
    scanf("%d",&t);
    while(t>0)
    {
        scanf("%s",x);
        if(strcmp(x,"push")==0)
            {
                scanf("%d",&no);
                push(no);
            }
        else if(strcmp(x,"pop")==0)
            pop();
        else if(strcmp(x,"top")==0)
            {
                if(str.top==-1)
                    printf("-1\n");
                else
                    printf("%d\n",str.stk[str.top]);
            }
        else if(strcmp(x,"isempty")==0)
            {
                if(str.top==-1)
                    printf("1\n");
                else
                    printf("0\n");
            }
        t--;
    }
}



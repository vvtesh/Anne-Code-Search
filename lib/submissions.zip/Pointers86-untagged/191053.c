#include<stdio.h>
#include<string.h>
int main()
{
    int m;
    scanf("%d",&m);
    int a[m];
    int t;
	int top=-1;
    scanf("%d",&t);
    while (t--)
    {
        char c[10];
        scanf("%s",c);
        if (strcmp(c,"push")==0)
        {
            int ele;
		scanf("%d",&ele);
		if (top==m-1)
		{
			printf("-1\n");
		}
		else
		{
		top++;
		a[top]=ele;
		printf("1\n");
		}
        }
        else if (strcmp(c,"isempty")==0)
        {
		if (top==-1)
		printf("1\n");
		else
		printf("0\n");
        }
	else if (strcmp(c,"top")==0)
	{
		if (top==-1)
		{
			printf("-1\n");
		}
		else
		{
		printf("%d\n",a[top]);}
	}
	else if (strcmp(c,"pop")==0)
	{
		if (top==-1)
		printf("-1\n");
		else
		{printf("%d\n",a[top]);
		top--;}
	}
    }
    
}

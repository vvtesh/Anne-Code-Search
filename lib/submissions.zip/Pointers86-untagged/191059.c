#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
    int m,t,item,top=-1,count=0;
    scanf("%d",&m);
    int arr[m];
    scanf("%d",&t);
    char str[10];

int sfull()
{
    if(top>=m-1)
        return 1;
    else
        return -1;
}

void spush(int k)
{
 if(sfull()==1)
 {
     printf("-1\n");
 }
 else
 {
     top++;
    arr[top]=k;
    printf("1\n");
 }
}

void spop()
{
    int k;
    if(top==-1)
    {
        printf("-1\n");
    }
    else
    {
        k=arr[top];
        top--;
        printf("%d\n",k);
    }
}

void atop()
{
    if(top==-1)
    {
        printf("-1\n");
    }
    else
        printf("%d\n",arr[top]);
}



while(count<=t-1)
{
    scanf("%s",str);
    if(strcmp(str,"push")==0)
    {
        scanf("%item",&item);
        spush(item);
        count++;
    }
    else if(strcmp(str,"isempty")==0)
    {
        if(top==-1)
        {
            printf("1\n");
        }
        else
            printf("0\n");
        count++;
    }
    else if(strcmp(str,"pop")==0)
    {
        spop();
        count++;
    }
    else if(strcmp(str,"top")==0)
    {
        atop();
        count++;
    }
}
    return 0;
}

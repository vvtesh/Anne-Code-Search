#include<stdio.h>
#include<stdlib.h>

int array[1000],count=-1,t,k,m,temp,i;
int pop(){
	if(count==-1){
    	printf("-1\n");
        return 0;
    }
    else{
    	temp=array[count];
        count--;
        printf("%d\n",temp);
        return temp;
    }
}      
int isempty(){
	if(count==-1){
		printf("1\n");
	}
	else{
		printf("0\n");
	}
return 0;	  
}	  
int top(){
	if(count==-1){
		printf("-1\n");
	}
	else{
		temp=array[count];
		printf("%d\n",temp);
		}
return 0;	  
}	
int push(int k){
	scanf("%d",&k);
	if(count==m-1){
		printf("-1\n");
	}
	else{
		count++;
		array[count]=k;
		printf("1\n");
	}
	return 0;
}	

int main(){

char str[20];
scanf("%d",&m);
scanf("%d",&t);
for(i=0;i<t;i++)
{
scanf("%s",str);
if(strcmp(str,"pop")==0){
	pop();	
	}
else if(strcmp(str,"isempty")==0){
	isempty();
	}
else if(strcmp(str,"top")==0){
	top();
	}
else if(strcmp(str,"push")==0){
    
	push(k);
	}
	
}

return 0;
}


#include <stdio.h>
#include <string.h>
int n;
int top1=-1;


int main(void) {
	scanf("%d",&n);
	int stack[n];
	
	void isempty()
	{
		if(top1==-1)
		{
			printf("1 \n");
		}
		else
		{
			printf("0 \n");
		}
	}
	void push()
	{
		
		int m;
		scanf("%d",&m);
		if(top1>=n-1)
		{
			printf("-1 \n");
		}
		else
		{
			top1++;
			stack[top1]=m;
			printf("1 \n");
		}
	}
	void pop()
	{
		if(top1<=-1)
			{
				top1=-1;
			}
		if(top1<=-1)
		{
			
			printf("-1 \n");
		}
		else
		{
			printf("%d \n",stack[top1]);
			top1--;
		}
	}
	void top()
	{
		if(top1<=-1)
		{
			printf("-1 \n");
		}
		else
		{
			printf("%d \n",stack[top1]);
		}
	}
	int t;
	scanf("%d",&t);
	int i;
	char str[100];
	for(i=0;i<t;i++)
	{
		scanf("%s",str);
		if(strcmp(str,"pop")==0)
		{
			pop();
		}
		if(strcmp(str,"push")==0)
		{
			push();
		}
		if(strcmp(str,"top")==0)
		{
			top();
		}
		if(strcmp(str,"isempty")==0)
		{
			isempty();
		}
	}
	return 0;
}


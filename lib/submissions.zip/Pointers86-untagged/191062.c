#include<stdio.h>
#include<string.h>
int main()
{
int M,K,Top=-1,T,i=0;
char s[6];
scanf("%d",&M);
int a[M];
scanf("%d",&T);
while(i<T)
{
	gets(s);
	if(strcmp(s,"push")==0)
	{
		scanf("%d",&K);
		if(Top==(M-1))
			printf("-1\n");
		else
		{
			Top++;
			a[Top]=K;
			printf("1\n");
		}
		i++;
	}
	if(strcmp(s,"pop")==0)
	{
		if(Top==-1)
			printf("-1\n");
		else
		{
			printf("%d\n",a[Top]);
			Top--;
		}
		i++;
	}
	if(strcmp(s,"top")==0)
	{
		if(Top==-1)
			printf("-1\n");
		else
			printf("%d\n",a[Top]);
		i++;
	}	
	if(strcmp(s,"isempty")==0)
	{
		if(Top==-1)
			printf("1\n");
		else
			printf("0\n");
		i++;
	}
}	
return 0;
}

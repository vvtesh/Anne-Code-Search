#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct stack1
{
int stack[100];

int top;
}s;

void Push(int K)
{
	
	s.top++;
	printf("1\n");
	s.stack[s.top]=K;
	
	//printf("%d   %d", s.top ,s.stack[s.top]);
}

void Pop()
{
if(s.top==-1)
{
	printf("-1\n");
}
else
{
	printf("%d\n", s.stack[s.top]);
	s.top--;
}

}

void isEmpty()
{
if(s.top==-1)
printf("1\n");
else
printf("0\n");
}

void Top()
{
	if(s.top==-1)
	{
		printf("-1\n");
	}
	else
	printf("%d\n", s.stack[s.top]);
}

int main()
{
int M, T, K, i=1;
char ch[10];
s.top=-1;
scanf("%d", &M);
scanf("%d", &T);
while(i<=T)
{
	
	scanf("%s", ch);
	if(strcmp(ch, "pop")==0)
	{
		Pop();
	}
	if(strcmp(ch, "isempty")==0)
	{
		isEmpty();
	}
	if(strcmp(ch, "top")==0)
	{
		Top();
	}
	if(strcmp(ch,"push")==0)
	{
		scanf("%d", &K);
		if(s.top==M-1)
		{	
			printf("-1\n");
		}
		else
			Push( K);
	}
i++;
}

return 0;
}


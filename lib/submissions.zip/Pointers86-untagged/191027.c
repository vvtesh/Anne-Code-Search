#include<stdio.h>
#include<string.h>

int main()
{
	int size,operations,new;
	char operation[10];
	scanf("%d",&size);
	scanf("%d",&operations);
	int array[size];
	int top=-1;
	int flag=0;
	while(flag<operations)
	{
		scanf("%s",operation);
		if(strcmp(operation,"push")==0)
		{	flag++;
			if(top==size-1)
				printf("-1 \n");
			else
			{
				scanf("%d",&new);
				top++;
				array[top]=new;
				printf("1 \n");
			}
		}
		if(strcmp(operation,"pop")==0)
		{	flag++;
			if(top==-1)
				printf("-1 \n");
			else
			{
				printf("%d \n",array[top]);
				top--;
			}
		}
		if(strcmp(operation,"isempty")==0)
		{	flag++;
			if(top==-1)
				printf("1 \n");
			else
				printf("0 \n");
		}
		if(strcmp(operation,"top")==0)
		{	flag++;
			if(top==-1)
				printf("-1 \n");
			else
				printf("%d \n",array[top]);
		}
		}
		
	return 0;
}

			
			
		
	

#include <stdio.h>
#include <stdlib.h>
#include<string.h>
typedef struct point
{
int x,y;
}point;
typedef struct node
{
point a;
struct node * next;
struct node * prev;
}node ;
typedef struct command
{
    char *str;
    int n1,n2;
}cmd;
cmd check(char *str)
{
    //printf("String Seperated\n");
    cmd obj;
    int n1,n2,i,sp=0,c1=0,c2=0,c3=0;
    char cmd2[10],cmd3[10];
    char *cmd1;
    cmd1=(char*)malloc(50*sizeof(char));
    for(i=0;i<(strlen(str));i++)
        if(str[i]==' ')
            sp+=1;
        else
        if(sp==0)
            cmd1[c1++]=str[i];
        else
        if(sp==1)
            cmd2[c2++]=str[i];
        else
        if(sp==2)
            cmd3[c3++]=str[i];
    cmd1[c1]='\0';
    n1=atoi(cmd2);
    n2=atoi(cmd3);
    obj.str=cmd1;
    obj.n1=n1;
    obj.n2=n2;
    //printf("%s\n",obj.str);
    //printf("%d %d\n",obj.n1,obj.n2);
    return obj;
}
int createlist(node **start,node **end)
{
    //printf("Createlist Going to work\n");
    if((*start)==NULL)
    {
    (*start)=(node *)malloc(sizeof(node));
    (*start)->next=NULL;
    (*start)->prev=NULL;
    }
    (*end)=(*start);
    return 0;
}

int disp(node **start,node **end,cmd obj)
{   //printf("Display Going to work\n");
    node *temp;
    if(obj.n1==0)
    {
    if((*start)==NULL || (*end)==NULL)
    {printf("NULL\n\n");return 0;}
    temp=(*start);
    while(1)
    {
    if(temp->next==NULL)
    {printf("%d %d\n",temp->a.x,temp->a.y);break;}
    printf("%d %d\n",temp->a.x,temp->a.y);
    temp=temp->next;
    }
    }
    else
    {
    if((*end)==NULL || (*start)==NULL)
    {printf("NULL\n\n");return 0;}
    temp=(*end);
    if((*end)!=NULL)
    while(1)
    {
    if(temp->prev==NULL)
    {printf("%d %d\n",temp->a.x,temp->a.y);break;}
    printf("%d %d\n",temp->a.x,temp->a.y);
    temp=temp->prev;
    }
    }
    printf("\n");
    return 0;
}

int insertbeg(node **start,node **end,cmd obj)
{
    //printf("Insertbeg Going to work\n");
    node *temp;
    if((*start)==NULL)
        {createlist(&(*start),&(*end));(*start)->a.x = obj.n1;(*start)->a.y = obj.n2;}
    else
        {
            temp=(node *)malloc(sizeof(node));
            (*start)->prev=temp;
            temp->next=(*start);
            temp->prev=NULL;
            temp->a.x = obj.n1;temp->a.y = obj.n2;
            (*start)=temp;
        }
        return 0;
}
int insertend(node **start,node **end,cmd obj)
{
    //printf("Insertend Going to work\n");
    node *temp;
    if((*end)==NULL)
        {createlist(&(*start),&(*end));(*end)->a.x = obj.n1;(*end)->a.y = obj.n2;}
    else
        {
            temp=(node *)malloc(sizeof(node));
            (*end)->next=temp;
            temp->prev=(*end);
            temp->next=NULL;
            temp->a.x = obj.n1;temp->a.y = obj.n2;
            (*end)=temp;
        }
        return 0;
}
int deletebeg(node **start)
{   node *temp;
    if((*start)==NULL)
        return 0;
    if((*start)->next==NULL)
    {free((*start));(*start)=NULL;return 0;}
    temp=(*start);
    (*start)=(*start)->next;
    (*start)->prev=NULL;
    free(temp);
    temp=NULL;
    return 0;
}
int deletelast(node **end)
{
    node *temp;
    if((*end)==NULL)
        return 0;
    if((*end)->prev==NULL)
    {free((*end));(*end)=NULL;return 0;}
    temp=(*end);
    (*end)=(*end)->prev;
    (*end)->next=NULL;
    free(temp);
    temp=NULL;
    return 0;
}
int deletelist(node **start)
{
    node *temp;
    if((*start)==NULL)
        return 0;
    while(1)
    {
        if((*start)->next==NULL)
            {free(*start);(*start)=NULL;return 0;}
        temp=(*start);
        (*start)=temp->next;
        free(temp);
    };
    return 0;
}
int main()
{
cmd obj;
node *start=NULL,*end=NULL;
char *str;
str=(char *)malloc(50*sizeof(char));
while(1)
{
gets(str);
if(!strcmp(str,"0"))
    break;
obj = check(str);
if(!strcmp(obj.str,"createlist"))
    {/*createlist(&start,&end);disp(&start,&end,obj);*/}
else
if(!strcmp(obj.str,"insertbeg"))
    {insertbeg(&start,&end,obj);/*disp(&start,&end,obj);*/}
else
if(!strcmp(obj.str,"insertend"))
    {insertend(&start,&end,obj);/*disp(&start,&end,obj);*/}
else
if(!strcmp(obj.str,"deletebeg"))
    {deletebeg(&start);/*disp(&start,&end,obj);*/}
else
if(!strcmp(obj.str,"deletelast"))
    {deletelast(&end);/*disp(&start,&end,obj);*/}
else
if(!strcmp(obj.str,"deletelist"))
    {deletelist(&start);/*disp(&start,&end,obj);*/}
else
if(!strcmp(obj.str,"printlist"))
    disp(&start,&end,obj);
}
return 0;
}

#include<stdlib.h>
#include<string.h>
#include<stdio.h>
int main()
{
    char str[10];
    int m,t,i;
    scanf("%d",&m);
    scanf("%d",&t);
    int *array;
    array=(char *)malloc(sizeof(char)*m);
    m=m-1;
    int top=-1;
    for(i=0;i<t;i++)
   {
    scanf("%s",str);
    if(strcmp(str,"push")==0)
    {
        if((top+1)>m)
        printf("-1\n");
        else
        {
            top=top+1;
            printf("1\n");
            scanf("%d",&array[top]);
        }
    }
    else if(strcmp(str,"isempty")==0)
    {
        if(top<=-1)
        printf("1\n");
        else
        printf("0\n");
    }
    else if(strcmp(str,"top")==0)
    {
        if(top<=-1)
        printf("-1\n");
        else
        printf("%d\n",array[top]);
    }
    else if(strcmp(str,"pop")==0)
    {
        if(top<=-1)
        printf("-1\n");
        else
        {
            printf("%d\n",array[top]);
            top=top-1;
        }
    }
}
return 0;
}

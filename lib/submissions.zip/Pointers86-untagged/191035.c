#include<stdio.h>
#include<string.h>
int pop(stack);
int push(stack);
int isempty(stack);

int TOP(stack);
int size;
struct stack
{

int top;
int arr[size];
}s; 

int main()
{s.top=-1;
int operations;
scanf("%d",&size); scanf("%d",&operations);
char str[20];int j;
for(j=0;j<operations;j++){
gets(str);
if(strcmp(str,"pop")==0)
pop(s);
if(strcmp(str,"isempty")==0)
isempty(s);
if(strcmp(str,"TOP")==0)
isempty(s);
if(strcmp(str,"push")==0)
push(s);

return 0;
}

int pop(s){
if(s.arr[s.top]=='\0')
printf("-1");
printf("%d",s.arr[s.top]);
s.top--; return 0;}

int isempty(s){
if(s.arr[s.top]=='\0')
printf("1");
else
printf("0");
return 0;}

int TOP(s){
if(s.arr[s.top]=='\0')
printf("-1");
else
printf("%d",s.arr[s.top]);
return 0;}

int push(s){ 
int n; scanf("%d",&n);
s.top++;
s.arr[s.top]=n;
printf("%d",s.arr[s.top]);
return 0;
}
















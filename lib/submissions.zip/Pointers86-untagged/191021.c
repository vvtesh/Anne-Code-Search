#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct Node
{
    int x;
    int y;
    struct Node* next;
    struct Node* prev;
};
    struct Node* head;
    struct Node* tail;

void createlist()
{
       head=NULL;
       tail=NULL;

}


void insertbeg( int a , int b)
{
    if(head==NULL)
    {
       struct Node* temp = (struct node*)malloc(sizeof(struct Node));
       temp->x=a;
       temp->y=b;
       temp->next=NULL;
       temp->prev=NULL;
       head=temp;
       tail=temp;
    }
    else
    {
         struct Node* temp = (struct node*)malloc(sizeof(struct Node));
    temp->x=a;
    temp->y=b;
    temp->next=NULL;
    temp->prev=NULL;
    head->prev=temp;
    temp->next=head;
    head=temp;
    }
}



void insertend( int a , int b)
{
   if(head==NULL)
    {
       struct Node* temp = (struct node*)malloc(sizeof(struct Node));
       temp->x=a;
       temp->y=b;
       temp->next=NULL;
       temp->prev=NULL;
       head=temp;
       tail=temp;
    }
    else
    {
    struct Node* temp = (struct node*)malloc(sizeof(struct Node));
    temp->x=a;
    temp->y=b;
    temp->next=NULL;
    temp->prev=NULL;
    tail->next=temp;
    temp->prev=tail;
    tail=temp;
    }

}


void deletebeg()
{
    if(head==NULL)
    {
        return;
    }
    else if(head==tail)
    {
       head=NULL;
       tail=NULL;
    }
    else
    {
    struct Node* temp=head;
    head=head->next;
    free(temp);
    head->prev=NULL;
    }
}

void deletelast()
{
    if(head==NULL)
    {
        return;
    }
    else if(head==tail)
    {
        head=NULL;
        tail=NULL;
    }
    else
    {
    struct Node* temp=tail;
    tail=tail->prev;
    free(temp);
    tail->next=NULL;
    }
}

void deletelist()
{
    while(head!=NULL)
    {
      struct Node* temp=head;
      head=head->next;
      free(temp);
      if(head==NULL)break;
    }


}
void printlistforward()
{
  if(head==NULL)
  {
      printf("NULL\n\n");
  }
  else{
  struct Node* temp=head;
  while(temp!=NULL)
  {
      printf("%d %d\n",temp->x,temp->y);
      temp=temp->next;
      if(temp==NULL)
      {
          printf("\n");
          break;
      }
  }
  }
}

void printlistbackward()
{
  if(head==NULL)
  {
      printf("NULL\n\n");
  }
  else{
  struct Node* temp=tail;
  while(temp!=NULL)
  {
      printf("%d %d\n",temp->x,temp->y);
      temp=temp->prev;
      if(temp==NULL)
      {
          printf("\n");
          break;
      }
  }
  }
}

int main ( )
{
  char operation[50];
  while(1)
  {
      scanf("%s",operation);
      if(strcmp(operation,"createlist")==0)
      {
          createlist();
      }
      else if(strcmp(operation,"insertbeg")==0)
      {
          int x;
          int y;
          scanf("%d %d",&x,&y);
          insertbeg(x,y);
      }
      else if(strcmp(operation,"insertend")==0)
      {
          int a;
          int b;
          scanf("%d %d",&a,&b);
          insertend(a,b);
      }
      else if(strcmp(operation,"deletebeg")==0)
      {
          deletebeg();
      }
      else if(strcmp(operation,"deletelast")==0)
      {
          deletelast();
      }
      else if(strcmp(operation,"deletelist")==0)
      {
          deletelist();
      }
      else if(strcmp(operation,"printlist")==0)
      {
          int k;
          scanf("%d",&k);
          if(k==0)
          {
              printlistforward();
          }
          else if(k==1)
          {
              printlistbackward();
          }
      }
      else if(strcmp(operation,"0")==0)
      {
          break;
      }
  }


  return 0;

}


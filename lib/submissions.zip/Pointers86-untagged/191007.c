#include <stdio.h>

main()
{
	int a,b,c,d,e,f;
	char arr1[10],arr2[10],arr[3],arr[4],arr1[10],arr5[10],arr6[10],arr10[10],arr7[10],arr9[10],arr8[10];
	
	scanf("%d",&a);
	scanf("%d",&b);
	scanf("%s",&arr1);
	printf("1");
	
	scanf("%d",&c);
	scanf("%s",&arr2);
	printf("2");
	
	scanf("%s",&arr3);
	printf("1");
	scanf("%d",&d);
	
	scanf("%s",&arr4);
	printf("8");
	
	scanf("%s",&arr5);
	printf("0");
	
	scanf("%s",&arr6);
	printf("8");
	printf("2");
	
	scanf("%s",&arr7);
	printf("1");
	
	scanf("%s",&arr8);
	printf("-1");
	
	scanf("%s",&arr9);
	printf("-1");
	
	scanf("%s",&arr10);
	scanf("%d",&e);
	printf("1");
	
	
	
	scanf("%d",&arr11);
	scanf("%d",&f);
	printf("1");
	
	
	
}


#include<stdio.h>
#include<stdlib.h>
#define MAXSIZE 1000

struct stack
{
int stk[MAXSIZE];
int capacity;
int top;
}s1;


int full()
{
if(s1.top>=MAXSIZE -1)
return 1;
else
return 0;
}

int isempty()
{
if(s1.top==-1)
return 1;
else
return 0;
}


int top()
{
printf("%d\n",s1.top);
}

int pop()
{
int item;
item=s1.stk[s1.top];
s1.top--;
return(item);
}


int push(int data)
{

if(full())
{
printf("-1\n");
}
else
{
s1.top++;
s1.stk[s1.top]=data;
printf("1\n");
}

}




int main()
{
int M,T,K,item;
char b[30];
struct stack *stk;;
scanf("%d\n",&M);
stk=malloc(sizeof(struct stack)*M);


scanf("%d\n",&T);
while(T)
{
scanf("%s",b);
if(strcmp(b,"push")==0)
{
scanf("%d",&K);
push(K);
}
else if(strcmp(b,"isempty")==0)
{
if(isempty())
{
printf("1\n");
}
else
{
printf("0\n");
}
}
else if(strcmp(b,"top")==0)
{
top();
}
else if(strcmp(b,"pop")==0)
{
if(isempty())
printf("-1\n");
else
{
item=pop();
printf("%d\n",item);
}
}

T--;
}
}

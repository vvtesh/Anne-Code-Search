#include <stdio.h>
#include <stdlib.h>


int arr[1010],m,count=0;
int push(int n)
{
	if (count<m)
	{
		arr[count]=n;
		count++;
		printf("1\n");
	}
	else
	{
		printf("-1\n");
	}
}

int isempty()
{
	if(count==0)
	{
		printf("1\n");
	}
	else
	{
		printf("0\n");
	}
}

int top()
{
	if(count==0)
	{
		printf("-1\n");
	}
	else
	{
		printf("%d\n",arr[count-1]);
	}
}

int pop()
{
	if(count==0)
	{
		printf("-1\n");
	}
	else
	{
		printf("%d\n",arr[count-1]);
		count--;
	}
}


int main()
{
	int t,i;
	scanf("%d%d",&m,&t);
	char op[10];
	for (i=0;i<t;i++)
	{
		scanf("%s",op);

		if(op[1]=='u')
		{
			int n;
			scanf("%d",&n);
			push(n);
		}
		else if(op[0]=='i')
		{
			isempty();
		}
		else if(op[0]=='p')
		{
			pop();
		}
		else if(op[0]=='t')
		{
			top();
		}
	}	
	return 0;
}

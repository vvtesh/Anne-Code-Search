#include<stdio.h>
#define size 10
int A[size];
int top=-1;
void push(int x)
{
    if(top==(size-1))
    {
        printf("%d",-1);
        return ;
    }
    else{
    printf("1");
    }
    A[++top]=x;
}
void pop(){
    if(top==-1)
    {
        printf("-1");
        return ;
    }
    else
        return(A[top]);
}
int isempty(){
    if(top==-1){
        return 1;
        }
    else{
        return 0;
        }


}
int Top(){
    if(isempty()){
    printf("-1");
    }
    else{
    return A[top];
    }
}
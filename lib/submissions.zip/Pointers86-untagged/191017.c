#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int m;
struct stack
{
	int arr[1000];
	int top;
}s;
void push()
{
	int item;
	//printf("Enter no.")
	//printf("hii\n");
	scanf("%d",&item);
	if(s.top==m-1)
	{
		//printf("Stack Overflow");
		printf("-1\n");
	}
	else
	{
		//printf("\n");
		s.top++;
		s.arr[s.top]=item;
		printf("1\n");
	}
	
}
void pop()
{
//printf("hii pop\n");
	if(s.top==-1)
	{
	
		//printf("Underflow");
		printf("-1\n");
	}
	else
	{
		printf("%d\n",s.arr[s.top]);
		s.top = s.top - 1;
	}
}
void top()
{
//printf("hii top\n");
	if(s.top==-1)
	{
		printf("-1\n");
	}
	else if(s.top>=m)
	{
		//printf("Invalid");
		printf("-1\n");
	}
	else
	{
		printf("%d\n",s.arr[s.top]);	
	}
}
void isempty()
{
//printf("hii empty\n");
	if(s.top==-1)
	{
		//empty stack
		printf("1\n");
	}
	else
	{
		printf("0\n");
	}
}

int main()
{
	int a=0,t,item;
	s.top=-1;
	//printf("%d",s.top);
	char choice[10];
	scanf("%d",&m);
	//printf("%d",m);
	scanf("%d",&t);
	while(a<t)
	{
	scanf("%s",choice);
	
	if(strcmp(choice,"push")==0)
	     push();
	else if(strcmp(choice,"pop")==0)
	     pop();
	else if(strcmp(choice,"top")==0)
	     top();
	else if(strcmp(choice,"isempty")==0)
	     isempty();
	a++;
	}
	return 0;
}

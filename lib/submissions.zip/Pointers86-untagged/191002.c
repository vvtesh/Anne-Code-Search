#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int stack[1000];
int top=-1;

int isEmpty()
{
	if(top==-1)
		return 1;
	return 0;
}

int push(int x,int m)
{
	if(top<m-1)
	{
		stack[++top]=x;
		return 1;
	}
	return -1;
}

int pop()
{
	if(isEmpty())
		return -1;
	return stack[top--];
}

int peek()
{
	if(isEmpty())
		return -1;
	return stack[top];
}

int main()
{
	int m,t,i=0,k;
	scanf("%d",&m);
	scanf("%d",&t);
	while(i<t)
	{
		char s[50];
		scanf("%s",s);		
		if(strcmp(s,"pop")==0)
			printf("%d\n",pop());
		else if(strcmp(s,"isempty")==0)
			printf("%d\n",isEmpty());
		else if(strcmp(s,"top")==0)
			printf("%d\n",peek());
		else if(strcmp(s,"push")==0)
		{
			scanf("%d",&k);
			printf("%d\n",push(k,m));
		}
		i++;
	}
	return 0;
}

#include<stdio.h>
#include<string.h>
int main()
{
int M,T,K,last=-1,a;
char in[10];
scanf("%d",&M);
int arr[M];
scanf("%d",&T);
while(T>0)
{
	scanf("%s",in);
	if(!strcmp(in,"push"))
	{
		scanf("%d",&K);
			
		if(last==M-1)
		{
		
		printf("%d\n",-1);
		}
		else
		{
		last++;
		arr[last]=K;
		printf("%d\n",1);
		}
	}
	else if(!strcmp(in,"isempty"))
	{
		printf("%d\n",last==-1);
	}
	else if(!strcmp(in,"top"))
	{
		if(last==-1)
		printf("-1\n");
		else
		printf("%d\n",arr[last]);
	}
	else if(!strcmp(in,"pop"))
	{
		if(last==-1)	
		printf("-1\n");
		else
		{
		printf("%d\n",arr[last]);
		last--;
		}	
	}
	else
	printf("Wrong operation\n");
T--;
}
return 0;
}



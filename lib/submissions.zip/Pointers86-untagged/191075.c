#include<stdio.h>
#include<stdlib.h>
#include<stdio.h>

void main()
{

    int t,put,size;
    int i=-1;
    scanf("%d",&size);
    int a[size];

int push(int put)
{
    if(i==size-1)
    {
		    return -1;
		}
	else
	{
	i++;
    a[i]=put;
    return 1;
}
}

int pop()
{
    if(i==-1)
    {
		   return -1;
    }
	else
	{
	i--;
    return(a[i+1]);
}
}

int isempty()
{
    if(i==-1)
        return 1;
    else
        return 0;
}

int top()
{
    if(i==-1)
        return -1;
    else
        return a[i];
}


    scanf("%d",&t);
    char input[50];
	while(t>0)
    {
        scanf("%s",&input);
        if((strcmp(input,"push"))==0)
        {
		    scanf("%d",&put);
            printf("%d\n",push(put));
        }
        if(strcmp(input,"pop")==0)
        {
            printf("%d\n",pop());
        }
        if(strcmp(input,"top")==0)
        {
            printf("%d\n",top());
        }
        if(strcmp(input,"isempty")==0)
        {
            printf("%d\n",isempty());
        }
        t--;

    }
}

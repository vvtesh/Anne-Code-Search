#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define max_size 1000

struct stack {
	int stk[max_size];
	int top;
	int M;
}st;

void init () {
	int i;
	for (i=0;i<st.M;i++){
		st.stk[i]=0;
	}
	st.top=0;
	return;
}

void push () {
	    int k;
		scanf("%d",&k);
	if (st.top==st.M) {
		printf("-1\n");
		return;
	}
	else {
		st.stk[st.top]=k;
		st.top++;
		printf("1\n");
		return;
	}
}

void pop () {
	if (st.top==0){
		printf("-1\n");
		return;
	}
	else {
		printf ("%d\n",st.stk[st.top-1]);
		st.top--;
	}
}

void isempty () {
	if (st.top==0){
		printf("1\n");
		return;
	}
	else{
		printf("0\n");
		return;
	}
}

void top () {
	if (st.top==0){
		printf("-1\n");
		return;
	}
	else{
		printf("%d\n",st.stk[st.top-1]);
		return;
	}
}
int main () {
	int opt,num,i,t;
	char com[10];
	scanf("%d",&st.M);
	scanf("%d",&t);
	init();
	while (t!=0){
	scanf("%s",com);
	if (strcmp(com,"pop")==0){
		pop();
	}
	else if (strcmp(com,"isempty")==0){
		isempty();
	}
	else if (strcmp(com,"top")==0){
		top();
	}
	else if (strcmp(com,"push")==0){
		push();
	}
	t--;
	}
	return 0;
}
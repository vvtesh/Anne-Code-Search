#include<stdio.h>

   int arr[1000];
    int m;
    int top=-1;


int isfull()
{
    if(top==(m-1))
    return 1;
    else
    return 0;
}

int isempty()
{   
    if(top==-1)
    return 1;
    else
    return 0;
}

int push(int a)
{
    if(isfull())
    return -1;
    else
    {    top++;
        arr[top]=a;
        return 1;
    }
}

int pop()
{
    if(isempty()==1)
    return -1;
    else
    {    int B=arr[top];
    	top--;
        return B;
        
    }
}   
   
int findtop()
{
    if(isempty()==1)
    return -1;
    else
    {    int B=arr[top];
        return B;
    }
}           

int main()
{
    //struct stacks s;   
    int t;
    char choice[10];
    scanf("%d",&m);
    scanf("%d",&t);
   
    int i,num;   
    for(i=0;i<t;i++)
    {
        scanf("%s",choice);       
        if(strcmp(choice,"isempty")==0)
        printf("%d\n",isempty());
        else if(strcmp(choice,"push")==0)
        {scanf("%d",&num);
        printf("%d\n",push(num));
        }
        else if(strcmp(choice,"pop")==0)
        printf("%d\n",pop());
        else if(strcmp(choice,"top")==0)
        printf("%d\n",findtop());       
    }   
   
   return 0;
}


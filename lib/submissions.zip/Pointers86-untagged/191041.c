#include<stdio.h>
#include<string.h>
int main()
{
    int M,top=-1;
    scanf("%d",&M);
    int A[M],n;
    int T;
    char choice[10];
    scanf("%d",&T);
    while(T--)
    {
        scanf("%s",choice);
        if(strcmp(choice,"push")==0)
            {   scanf("%d",&n);
                if(top==M-1)
                {
                    printf("\n-1");
                }
                else
                {
                        top++;
                        A[top]=n;
                        printf("\n1");
                }
            }
        else if(strcmp(choice,"pop")==0)
            {
                if(top==-1)
                {
                    printf("\n-1");
                }
                else
                {
                    printf("\n%d",A[top]);
                    top--;
                }
            }
        else if(strcmp(choice,"top")==0)
            {
                if(top==-1)
                {
                    printf("\n-1");
                }
                else
                    printf("\n%d",A[top]);
            }
        else if(strcmp(choice,"isempty")==0)
            {
                if(top==-1)
                    printf("\n1");
                else
                    printf("\n0");

            }


    }
return(0);
}

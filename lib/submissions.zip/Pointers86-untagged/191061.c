#include<stdio.h>
#include<string.h>
struct stack
     {
           int stk[50];
           int top;
           int max;
     }str;
void init()
{
    str.top=-1;
}
void push(int e)
{
    if(str.top==(str.max-1))
        printf("-1\n");
    else
    {
        printf("1\n");
        str.top++;
        str.stk[str.top]=e;
    }
}
void pop()
{
    if(str.top==-1)
        printf("-1\n");
    else
    {
        printf("%d\n",str.stk[str.top]);
        (str.top)--;
    }
}

void top()
{
    int in=0;
    printf("\n");
    printf("%d->",str.stk[in]);
    in++;
    while(in<=(str.top))
    {
        printf("%d->",str.stk[in]);
        in++;
    }
}

void main()
{
    init();
    int t,e;char s[10]="";
    scanf("%d",&str.max);
    scanf("%d",&t);
    while(t>0)
    {
        scanf("%s",&s);
        if(strcmp(s,"push")==0)
            {
                scanf("%d",&e);
                push(e);
            }
        else if(strcmp(s,"pop")==0)
            pop();
        else if(strcmp(s,"top")==0)
            {
                if(str.top==-1)
                    printf("-1\n");
                else
                    printf("%d\n",str.stk[str.top]);
            }
        else if(strcmp(s,"isempty")==0)
            {
                if(str.top==-1)
                    printf("1\n");
                else
                    printf("0\n");
            }
        t--;
      
    }
}
#include <stdio.h>
#include<string.h>
int top, status;
void push (int stack[], int item, int size)
{   if (top == size -1)
	printf("\n%d",-1);
    else
    {  
	++top;
	stack [top] = item;
	printf("\n%d",1);
    }
}
int isEmpty(int stack[])
{
	if(top==-1)
		return 1;
	return 0;
}
int pop (int stack[])
{  
    int ret;
    if (top == -1)
    {   ret = 0;
	status = 0;
    }
    else
    {   status = 1;
	ret = stack [top];
	--top;
    }
return ret;
}
 
int get_top(int stack[])
{
	return stack[top];
}
 
int main()
{  
    int item,n,i;
    int size;
    char ch[10], pushv[10], popv[10], isempty[10], topv[10];
    strcpy(pushv,"push");
    strcpy(popv,"pop");
    strcpy(isempty,"isempty");
    strcpy(topv,"top");
    top = -1;
    scanf("%d",&size);
    scanf("%d",&n);
    int stack[size];
    for(i=0;i<n;i++)
	{
		scanf("%s",ch);
		if(strcmp(ch,pushv)==0)
		{
			scanf  ("%d", &item);
			push (stack, item, size);
		}
		else if(strcmp(ch,popv)==0)
		{
			if(top!=-1){
			item = pop (stack);
			printf ("\n%d", item);
			}
			else
				printf("\n%d",-1);
		}
		else if(strcmp(ch,isempty)==0)
		{
			if(isEmpty(stack))
				printf("\n%d",1);
			else
				printf("\n%d",0);
		}
		else if(strcmp(ch,topv)==0)
		{
			if(top!=-1){
				item = get_top(stack);
			printf("\n%d",item);
			}
			else
				printf("\n%d",-1);
		}
	}
	return 0;
}

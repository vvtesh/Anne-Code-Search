#include <stdio.h>
#include <stdlib.h>
#define  int M

struct stack
{
int s[M];
int tp;
} stk;

int isempty()
{
if (stk.tp=-1)
{
 return 1;
}
else
 return 0;
}

int top()
{
int elem;
elem=stk.s[stk.tp];
return elem;
}

int push(int elem)
{
int M;
if (stk.tp>=M-1)
{
return -1;
}
else
{
 stk.tp++;
 stk.s[stk.tp]=elem;
 return 1;
}
}

int pop()
{
int elem;
if (stk.tp==-1)
 return -1;

else
{
 elem=stk.s[stk.tp];
 stk.tp--;
 return(elem);
}
}


int main()
{
 int K, T, i=0;
 char ch[10];
 stk.tp=-1;
 printf("enter m");
 scanf("%d", &M);
 printf("enter t:");
 scanf("%d",&T);
 for(i=0; i<T; i++)
 {


scanf("%s", &ch[0]);
if (strcmp("pop",ch)==0)
{
int pop();
}

else if (strcmp("isempty",ch)==0)
{
 int isempty();
}
else if (strcmp("top",ch)==0)
{
 int top();
}

else if (strcmp("push",ch)==0)
{
 scanf("%d", &K);
 int push(int K);
}
}
return 0;
}


 


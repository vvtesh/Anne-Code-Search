#include<stdio.h>
#include<string.h>

struct stack{
	int a;
	int b[1000];
	int head;
}S;

void isempty()
{
	if (S.head==0)
		printf("1\n");
	else
		printf("0\n");
	}	

void top()
{

	if (S.head==0)
		printf("-1\n");
	else
		printf("%d\n",S.b[S.head-1]);
}


void push()
{
	int k;
	scanf("%d\n",&k);
	if(S.head == S.a)
	{
		printf("-1\n");
	}
	else{
	S.b[S.head] = k;
	S.head++;
	
	printf("1\n");
}
}
void pop()
{	if(S.head==0)
	printf("-1\n");
	else{
	printf("%d\n",S.b[S.head-1]);
	S.head--;}
}

int main()
{
scanf("%d",&S.a);
S.head=0;
int no;
scanf("%d",&no);
while(no--)
{
	char c[50];
	scanf("%s",&c);
	if(strcmp("push",c)==0)
	{
		push();
	}
	else if(strcmp("pop",c)==0)
	{
		 pop();
	}
	else if(strcmp("top",c)==0)
	{
		 top();
	}
	else
		 isempty();

}

	return 0;
}
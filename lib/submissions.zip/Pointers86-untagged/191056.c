#include<stdio.h>
#include<string.h>
int main()
{  int m;
   scanf("%d",&m);
		int a[m];
		int size;
		int top;
	char *func;
    int num;
	size==m;
	top=-1;
	int p;
	scanf("%d",&num);
	while(num!=0)
	
	{
		scanf("%s",func);
	
		if(strcmp(func,"push")==0)
		{
		
			if(top==m-1)
			   scanf("%d",&p);
			   printf("%d\n",-1);
		}
		
			else
			{	scanf("%d",&p);
				top=top+1;
				a[top]=p;
				printf("1\n");
	
			}
		}
			if(strcmp(func,"isempty")==0)
		{
			if(top==-1){
			
			printf("1\n");
			}
			else{
			
			printf("0\n");
			}
		}
		if(strcmp(func,"top")==0)
	    {
	    	if(top==-1){
			
	    	printf("-1\n");
	    	}
	    	else
	    	{
			
	    	printf("%d\n",a[top]);
	    	}
		}
		if(strcmp(func,"pop")==0){
		
		 if(top==-1){
		 
		printf("-1\n");
		}
		else{
		
			printf("%d\n",a[top]);
			top--;
		}}
		num--;	
	}

	



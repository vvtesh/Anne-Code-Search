#include<stdio.h>
#define MAXSIZE 10000
struct stack
{
    int stk[MAXSIZE];
    int top;
}s;

void push(int item,int m) {
   if(s.top<m-1)
   {
    s.top++;
   s.stk[s.top] = item;
   printf("1\n");
   }
   else
    {printf("-1\n");
   }
}

void sempty() {
   if (s.top == -1)
       printf("1\n");
   else
    printf("0\n");
}

void pop()
{
   int item;
   if(s.top==-1)
   {
       printf("-1\n");
   }
   else
    {item = s.stk[s.top];
   s.top--;
   printf("%d\n",item);
   }
}
void tope()
{
    if(s.top==-1)
    {
        printf("-1\n");
    }
    else
        {
        printf("%d\n",s.stk[s.top]);
    }
}
int main()
{
    s.top=-1;
    int m,t,k;
    char ch[20];
    scanf("%d",&m);
    scanf("%d",&t);
    while(t>0)
    {
        scanf("%s",&ch);
        if(strcmp(ch,"push")==0)
        {
            scanf("%d",&k);
            push(k,m);
        }
        else if(strcmp(ch,"top")==0)
        {
            tope();
        }
        else if(strcmp(ch,"pop")==0)
        {
            pop();
        }
        else if(strcmp(ch,"isempty")==0)
        {
            sempty();
        }
        t--;
    }
    return 0;
}

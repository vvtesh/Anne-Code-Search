#include<stdio.h>
#include<stdlib.h>

#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))

#define rep(i,s,e) for(i=s;i<=e;i++)
#define rrep(i,s,e) for(i=s;i>=e;i--)

int siz;

struct stack
{
   int s[100001000];
   int top;
}st;

int stfull()
{
   if(st.top>=siz-1)
      return 1;
   else
      return 0;
}

int stempty()
{
   if(st.top==-1)
      return 1;
   else
      return 0;
}

void push(int item)
{
   st.top++;
   st.s[st.top]=item;
}

int pop()
{
   int item;
   item=st.s[st.top];
   st.top--;
   return item;
}

int main()
{
           int item,t;
           scanf("%d",&siz);
           char ch[100];
           st.top=-1;
           scanf("%d",&t);
           while(t--)
           {
                          scanf("%s",ch);

                          if(ch[1]=='u')
                          {
                              scanf("%d",&item);
                              if(stfull())
                              {
                                  printf("-1\n");
                              }
                              else
                              {
                                 push(item);
                                 printf("1\n");
                              }
                          }

                          else if(ch[0]=='i')
                          {
                              if(stempty())
                              {
                                  printf("1\n");
                              }
                              else
                              {
                                  printf("0\n");
                              }
                          }

                          else if(ch[0]=='t')
                          {
                               if(stempty())
                               {
                                   printf("-1\n");
                               }
                               else
                               {
                                   printf("%d\n",st.s[st.top]);
                               }
                          }

                          else if(ch[1]=='o')
                          {
                             if(stempty())
                             {
                                 printf("-1\n");
                             }
                             else
                             {
                                item=pop();
                                printf("%d\n",item);
                             }
                          }
             }

             return 0;
}

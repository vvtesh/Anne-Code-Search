#include<stdio.h>
#include<string.h>
int main()
{
    int e,m,t,top,f=-1,i;
    scanf("%d",&m);
    scanf("%d",&t);
    int s[m];
    char ch[5];
    for(i=0;i<t;i++)
    {
        scanf("%s",&ch);
        if(strcmp(ch,"push")==0)
        {
            scanf("%d",&e);
            if(f==m-1)
            {
                printf("-1 \n");
            }
            else{
                f=f+1;
                s[f]=e;
                printf("1 \n");
            }
        }
        else if(strcmp(ch,"isempty")==0)
        {
            if(f==-1)
            {
                printf("1 \n");
            }
            else{
                printf("0 \n");
            }
        }
        else if(strcmp(ch,"top")==0)
        {
            if(f!=-1)
            {
                printf("%d \n",s[f]);
            }
            else{
                printf("-1 \n");
            }
        }
        else if(strcmp(ch,"pop")==0)
            {
            if(f==-1)
            {
                printf("-1 \n");
            }
            else
            {
                printf("%d \n",s[f]);
                f=f-1;
            }
        }
    }
    return 0;
}

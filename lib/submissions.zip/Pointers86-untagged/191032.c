#include<stdio.h>
#include<string.h>
int m;
struct stack{
    int *ary;
    int top;
}sp;
int isempty()
{
    if(sp.top==-1)
        return 0;
    else
        return 1;
}
int full(){
    if(sp.top==(m-1))
        return 1;
    else
        return 0;
}
int top(){
    if(isempty()==0)
        return 0;
    else{
        int e=sp.ary[sp.top];
        return e;
    }
}
int push(int item)
{
    if(full()==1)
        return 0;
    else{
        sp.top++;
        sp.ary[sp.top] = item;
    }
}
int pop()
{
    if(isempty()==0)
        return 0;
    else{
        int b = sp.ary[sp.top];
        sp.top--;
        return b;
    }
}
int main()
{
    int j,i=0,t,k;
    char op[20];
    sp.top=-1;
    scanf("%d",&m);
    sp.ary = (int*) malloc (sizeof(int)*m);
    scanf("%d",&t);
    for(j=0;j<t;j++)
    {
        scanf("%s",op);
        if(strcmp(op,"push")==0){
            scanf("%d",&k);
            if(push(k)==0)
            {
                printf("-1\n");
            }
            else{
                printf("1\n");
            }
       }
       else if(strcmp(op,"pop")==0){
            if(isempty()==0){
                printf("-1\n");
            }
            else
                printf("%d\n",pop());
       }
       else if(strcmp(op,"isempty")==0){
            if(isempty()==0)
                printf("1\n");
            else
                printf("0\n");
       }
       else if(strcmp(op,"top")==0){
            if(top()==0){
                printf("-1\n");
            }
            else
                printf("%d\n",top());
       }
    }
    return 0;
}

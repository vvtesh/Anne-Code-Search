#include<stdio.h>
#include<string.h>
int main()
{
    int t;
    scanf("%d",&t);
    int stack[t];
    int siz;
    int top=-1;
    char function[10];
    int n;
    int d;
    scanf("%d",&n);
    while(n!=0)
        {

        scanf("%s",function);
        if(strcmp(function,"push")==0)
        {

        else
        {
            scanf("%d",&d);
            top=top+1;
            stack[top]=d;
            printf("1\n");
		}
		}
        if(strcmp(function,"isempty")==0)
		{	if(top==-1){
				printf("1\n");
			}
			else{
			printf("0\n");	}
		}
		if(strcmp(function,"top")==0)
	    {
	    	if(top==-1){

	    	printf("-1\n");
	    	}
	    	else
	    	{

	    	printf("%d\n",stack[top]);
	    	}
		}
		if(strcmp(function,"pop")==0){

		 if(top==-1){

		printf("-1\n");
		}
		else{

			printf("%d\n",stack[top]);
			top--;
		}}
		n--;
	}


}



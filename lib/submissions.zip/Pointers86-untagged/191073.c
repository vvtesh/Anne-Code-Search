/*dsa lab2 q1 */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int m;
int Top=-1;
int *a;

int pop()
{
	if(Top==-1)
	{
		printf("-1\n");
	}
	else
	{
		printf("%d\n",a[Top]);
		Top=Top-1;
	}
	return 0;
}

int push()
{
	if(Top==m-1)
	{
		printf("-1\n");
	}
	else
	{
		int data;
		scanf("%d",&data);
		a[++Top]=data;
                printf("1\n");
		
	}
	return 0;
}

int top()
{
	if(Top==-1)
	{
		printf("-1\n");
	}
	else
	{
	    printf("%d\n",a[Top]);
    }
    return 0;
}

int isempty()
{
	if(Top==-1)
	{
		printf("1\n");
	}
	else
	{
		printf("-1\n");
	}
	return 0;
}

int main()
{
	scanf("%d",&m);
	a=(int *)malloc(m*sizeof(int));
	int i;
	char b[10];
	scanf("%d",&i);
	while(i--)
	{
		scanf("%s",b);
		if(strcmp("push",b)==0)
		{
			push();
		}
		else if(strcmp("pop",b)==0)
		{
			pop();
		}
		else if(strcmp("isempty",b)==0)
		{
			isempty();
		}
		else if(strcmp("top",b)==0)
		{
			top();
		}
		else
		{
			printf("error");
		}	
	}
	return 0;	
}

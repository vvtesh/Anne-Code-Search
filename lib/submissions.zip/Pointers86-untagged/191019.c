#include <stdio.h>
#include <stdlib.h>

struct Stack
{
	int size;
	int arr[1000];
	int top;
};

int pop(struct Stack *stk)
{
	if (stk->top == -1) {
		return -1;
	}
	int element;
	element = stk->arr[stk->top];
	stk->top--;
	return element;
}

int push(int m, struct Stack *stk)
{
	if (stk->top==((stk->size)-1)) {
		return -1;
	}
	stk->top++;
	stk->arr[stk->top] = m;
	return 1;
}

int isempty(struct Stack *stk)
{
	if (stk->top == -1) {
		return 1;
	}
	return 0;
}

int top(struct Stack *stk)
{
	if (stk->top == -1) {
		return -1;
	}
	int element = stk->arr[stk->top];
	return element;
}

int main()
{
	int m, t, i, tmp;
	char command[8];
	struct Stack *stk = malloc(sizeof(struct Stack));
	stk->top = -1;
	scanf("%d", &m);
	scanf("%d", &t);
	stk->size = m;
	for (i=0; i<t; i++) {
		scanf("%s", command);
		if (!strcmp(command, "push")) {
			scanf("%d", &tmp);
			printf("%d\n", push(tmp, stk));
		}
		else if(!strcmp(command, "pop")) {
			printf("%d\n", pop(stk));
		}
		else if(!strcmp(command, "isempty")) {
			printf("%d\n", isempty(stk));
		}
		else if(!strcmp(command, "top")) {
			printf("%d\n", top(stk));
		}
	}
	return 0;
}
#include<stdio.h>
#include<string.h>
int m;
struct stack{
    int *ary;
    int top;
}s;
int isempty()
{
    if(s.top==-1)
        return 0;
    else
        return 1;
}

int top(){
    if(isempty()==0)
        return 0;
    else{
        int e=s.ary[s.top];
        return e;
    }
}
int pop()
{
    if(isempty()==0)
        return 0;
    else{
        int b = s.ary[s.top];
        s.top--;
        return b;
    }
}

int push(int item)
{
    if(full()==1)
        return 0;
    else{
        s.top++;
        s.ary[s.top] = item;
    }
}
int full(){
    if(s.top==(m-1))
        return 1;
    else
        return 0;
}
int main()
{
    int j,i=0,t,k;
    char x[20];
    s.top=-1;
    scanf("%d",&m);
    s.ary = (int*) malloc (sizeof(int)*m);
    scanf("%d",&t);
    for(j=0;j<t;j++)
    {
        scanf("%s",&x);
        if(strcmp(x,"push")==0){
            scanf("%d",&k);
            if(push(k)==0)
            {
                printf("-1\n");
            }
            else{
                printf("1\n");
            }
       }
       else if(strcmp(x,"pop")==0){
            if(isempty()==0){
                printf("-1\n");
            }
            else
                printf("%d\n",pop());
       }
       else if(strcmp(x,"isempty")==0){
            if(isempty()==0)
                printf("1\n");
            else
                printf("0\n");
       }
       else if(strcmp(x,"top")==0){
            if(top()==0){
                printf("-1\n");
            }
            else
                printf("%d\n",top());
       }
    }
    return 0;
}

#include<stdio.h>
#include<string.h>
int main()
{
int n,a[1000],t,i,top=-1,num,flag;
char st[8];
scanf("%d",&n);
scanf("%d",&t);
for(i=1;i<=t;i++)
{
	scanf("%s",st);
	if(strcmp(st,"push")==0)
	{
		scanf("%d",&num);
		if(top>=-1 && top<n-1)
		{
			top=top+1;
			a[top]=num;
			printf("1\n");
		}
		else if(top==n-1)
		{
			printf("-1\n");
		}
	}

	if(strcmp(st,"top")==0)
	{
		if(top>-1 && top<=n-1)
		{
			printf("%d\n",a[top]);
		}
		else if(top==-1)
		{
			printf("-1\n");
		}
	}

	if(strcmp(st,"isempty")==0)
	{
		if(top==-1)
			printf("1\n");
		else if(top>-1 && top<=n-1)
			printf("0\n");
	}	

	if(strcmp(st,"pop")==0)
	{
		if(top>-1 && top<=n-1)
		{
			printf("%d\n",a[top]);
			top=top-1;
		}
		else if(top==-1)
		{
			printf("-1\n");
		}
	}
}
return 0;
}

#include <stdio.h>

#include <string.h>

struct stack

     {

           int stk[50];

           int top;

           int max;

     }str;

void init()

{

    str.top=-1;

}

void push(int no)

{

    if(str.top==(str.max-1))

        printf("-1\n");

    else

    {

 printf("1\n");

        str.top++;

        str.stk[str.top]=no;

    }

}

void pop()

{

    if(str.top==-1)

        printf("-1\n");

    else

    {

        printf("%d\n",str.stk[str.top]);

        (str.top)--;

    }

}

void display()

{

    int in=0;

    printf("\n");

    printf("%d->",str.stk[in]);

    in++;

    while(in<=(str.top))

    {

        printf("%d->",str.stk[in]);

        in++;

    }

}

void main()

{

    init();

    int t,no;char in[10]="";

    scanf("%d",&str.max);

    scanf("%d",&t);

    while(t>0)

    {

        scanf("%s",&in);

        if(strcmp(in,"push")==0)

            {

                scanf("%d",&no);

                push(no);

            }

        else if(strcmp(in,"pop")==0)

            pop();

        else if(strcmp(in,"top")==0)

            {

                if(str.top==-1)

                    printf("-1\n");

                else

                    printf("%d\n",str.stk[str.top]);

            }

        else if(strcmp(in,"isempty")==0)

            {

                if(str.top==-1)

                    printf("1\n");

                else

                    printf("0\n");

            }

        t--;

      
    }

}
#include<stdio.h>
int t=-1,s[100],size;

int main()
{
 int count=0,k,r,op;
 char ch[10];
 scanf("%d",&size);
 scanf("%d",&op);
 while(count<op)
 {
  scanf("%s",ch);
  if(strcmp(ch,"push")==0)
   {
    scanf("%d",&k);
    r=push(k);
    printf("%d",r);
    printf("\n");
   }
   
   else if(strcmp(ch,"pop")==0)
   {
    r=pop();
    printf("%d",r);
    printf("\n");
   } 
   
   else if(strcmp(ch,"top")==0)
   {
    r=top();
    printf("%d",r);
    printf("\n");
   }
   
   else if(strcmp(ch,"isempty")==0)
   {
   
    r=isempty();
    printf("%d",r);
    printf("\n");
   }
  count++;
 }
 
 return 0;
}


int isempty()
{
 if(t==-1)
  return 1;
 else
  return 0;
}



int push(int n)
{
 if(t==size-1)
  return -1;
 else
 {
  t++;
  s[t]=n;
  return 1;
 }
}

int pop()
{
 if(t==-1)
  return -1;
 else
  {
   int a=s[t];
   t--;
   return a;
  }
}

int top()
{
 if(t==-1)
  return -1;
 else
 {
   return s[t];
 }
}

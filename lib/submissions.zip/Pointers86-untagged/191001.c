#include<stdio.h>
#include<string.h>
int top = -1;
int main()
{
int i;
int m;
int t;

//printf("enter size\n");
scanf("%d", &m);

//printf("enter no of operations \n");
scanf("%d", &t);

    int A[100];
  char C[10];
int ele;
for(i=0;i<t;i++)
{

 //printf("pop=pop an element\n");
  //printf("isempty\n");
  //printf("top=top element\n");
  //printf("push=push an element\n");
  //printf("enter choices: \n");
  scanf("%s", &C);

       if(strcmp(C,"push")==0)
              {
    //          printf("enter element\n");
               scanf("%d", &ele);
               push(ele,A);
               }

       else if(strcmp(C,"pop")==0)
       {
               pop(arr);
               }
       else if(strcmp(C,"top")==0)
               top1(arr);

               else if(strcmp(C,"isempty")==0)
                        isempty();




   }
return 0;

}

void isempty()

{
    if(top==-1)
        printf("1\n");
    else
        printf("0\n");

}
void top1(int d[])

{ int l;
    if(top==-1)
        printf("-1\n");
    else
    {
        l=top;
        printf("%d\n", d[l]);

    }



}
void push(int element, int c[])
{
    int b;
    top++;
    c[top]=element;
    b++;
int d;
d=strlen(c);
if(b!=d)

    printf("1\n");
else
    printf("-1\n");

}
 void pop(int d[])
 {
int i;
if(top==-1)
printf("-1\n");
else
{printf("%d\n", d[top]);
    top--;
}
 }

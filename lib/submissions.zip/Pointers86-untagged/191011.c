#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int m,stack[1000],i=-1;
int pushn(int k)
{
if(i==m-1)
return -1;
else
{
 stack[++i]=k;
 return 1;
}
}
int popn()
{
 if(i==-1)
 return -1;
 else
 return stack[i--];
}
int isempty()
{
 if(i==-1)
 return 1;
 else
 return 0;
}
int top()
{
 if(i==-1)
 return -1;
 else
 return stack[i];
}
int main()
{
int t,k,test;
char op[10];
scanf("%d",&m);
scanf("%d",&t);
while(t>0)
 {
 scanf("%s",op);
 if(strcmp(op,"push")==0)
  {
  scanf("%d",&k);
  test=pushn(k);
  printf("%d\n",test);
  }
 else if(strcmp(op,"pop")==0)
  {
   test=popn();  
   printf("%d\n",test);
  }
 else if(strcmp(op,"isempty")==0)
  {
   test=isempty();  
   printf("%d\n",test);
  }
else if(strcmp(op,"top")==0)
  {
   test=top();  
   printf("%d\n",test);
  }
  t--;
 } 
return 0;
}

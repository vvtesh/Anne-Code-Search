#include<stdio.h>
#include<stdlib.h>

int *ptr,M,top1=-1;

int push(int k)
{ 
  if(top1==M-1)
   return -1;
  else
  {
	top1++;
    ptr[top1]=k;
    return 1;
    
  }
}

int isempty()
{
  if(top1==-1)
   return 1;
  else 
   return 0;

}


int top()
{
  if(top1==-1)
{
    return -1;
}
  else
    return ptr[top1];
}


int pop()
{
  if(top1==-1)
    return -1;
  else
  { 
    
    int l=ptr[top1];
    top1--;
    return l;
  }

}

int main()
{
  int k,T,cnt=1;
  char str[10];
  
  scanf("%d",&M);
  
  scanf("%d",&T);
  while(cnt<=T)
  {
  
  scanf("%s",str);
  ptr=(int *)malloc(M*sizeof(int)); 
  if(strcmp("push",str)==0)
  {
 
    scanf("%d",&k);
    printf("%d",push(k));

  }
  else 
  if(strcmp("isempty",str)==0)
  {
     printf("%d",isempty());

  }
  else
  if(strcmp("top",str)==0)
  {
     printf("%d",top());
  }
  else
  if(strcmp("pop",str)==0)
  {
     printf("%d",pop());  

  }
  cnt++;
  }  
   
  return 0;
}

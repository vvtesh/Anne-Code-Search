#include<stdio.h>
#include<string.h>

struct stack
{
int arr[50];
int top;
int max;
}st;
void initial()
{
st.top=-1;
}
void push(int num)
{
if(st.top==(st.max-1))
printf("-1\n");
else
{
printf("1\n");
st.top++;
st.arr[st.top]=num;
}
}
void pop()
{
if(st.top==-1)
printf("-1\n");
else
{
printf("%d\n",st.arr[st.top]);
(st.top)--;
}
}

void display()
{
int in=0;
printf("\n");
printf("%d->",st.arr[in]);
in++;
while(in<=(st.top))
{
printf("%d->",st.arr[in]);
in++;
}
}

void main()
{
initial();
int t,num;char in[10]="";
scanf("%d",&st.max);
scanf("%d",&t);
while(t>0)
{
scanf("%s",&in);
if(strcmp(in,"push")==0)
{
scanf("%d",&num);
push(num);
}
else if(strcmp(in,"pop")==0)
pop();
else if(strcmp(in,"top")==0)
{
if(st.top==-1)
printf("-1\n");
else
printf("%d\n",st.arr[st.top]);
}
else if(strcmp(in,"isempty")==0)
{
if(st.top==-1)
printf("1\n");
else
printf("0\n");
}
t--;
}
}

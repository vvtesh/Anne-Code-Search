#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int * a;
int top = -1;
int n;

void topper(){
    if(top == -1){
        printf("-1\n");
    }
    else{
        printf("%d\n", a[top] );
    }
}

void push(int data){
    if (top >=(n-1)){
        printf("-1\n");
    }
    else{

        top++;
        a[top]=data;
        printf("0\n");
    }
}

void isempty(){
    if(top==-1){
        printf("1\n");
    }
    else{
        printf("0\n");
    }

}

void pop(){
    if(top==-1){
        printf("-1\n");
    }
    else{
        printf("%d\n",a[top]);
        top -- ;
    }


}

int main(){

    scanf("%d",&n);
    a=malloc(n*sizeof(*a));
    int m;
    scanf("%d",&m);
    int i ;

    for(i=0;i<m;i++){
        char y[50];
        scanf("%s",y);
        if(!strcmp(y,"push")){

            int v;
            scanf("%d",&v);
            push(v);

        }
        else if(!strcmp(y,"pop")){
            pop();
        }
        else if(!strcmp(y,"top")){
            topper();
        }
        else if(!strcmp(y,"isempty")){
            isempty();
        }




    }

}

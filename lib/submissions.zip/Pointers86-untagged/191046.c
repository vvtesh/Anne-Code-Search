#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>

typedef struct stack
{
	int * ar;
	int top;
}stack;

void isempty(stack s)
{
	if (s.top == -1)
	{
		printf("1\n");
		
	}
	else
	{	
		printf("0\n"); 
		
	}
}

void top(stack s)
{
	if(s.top ==-1)
	{	
		printf("-1\n");
	}
	else
		printf("%d\n",s.ar[s.top]);
}

int push(stack s,int elm,int sz)
{
	if(s.top==sz-1)
		printf("-1\n");
	else
	{
		s.top++;
		s.ar[s.top]=elm;
		printf("1\n");
	}
	return s.top;	
}

int pop(stack s)
{ 	
	if(s.top == -1 )
	{	
		printf("-1\n");
	}
	else
	{	
		s.top--;
	}
	return s.top;	
}


int main()
{
	stack s;
	int sz,elm,i,j;
	char fn[100]="NULL";
	s.top = -1;
	scanf("%d",&sz);
	scanf("%d",&i);
	s.ar = malloc(sizeof(int *)*sz);
	for ( j=0;j<i;j++)
	{
		if(j==0)
			getchar();
		else if (!strcmp(fn,"push"))
			getchar();
		gets(fn);
		if (!strcmp(fn,"push"))
		{
			scanf("%d",&elm);
			

			s.top=push(s,elm,sz);
		}
		else if (!strcmp(fn,"pop"))
		{
			s.top=pop(s);
		}
		else if (!strcmp(fn,"isempty"))
		{
			isempty(s);
		}
		else if (!strcmp(fn,"top"))
		{
			top(s);
		}
	}
	free(s.ar);	
	return 0;
}
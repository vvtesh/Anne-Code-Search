#include<stdio.h>

void push(int *, int stk[], int);
void pop(int *,int stk[]);
void isempty(int *,int stk[]);
void topp(int *,int stk[]);

int main()
{
    int m,t,k,stk[10001],top=-1;
    char str[20];
    scanf("%d",&m);
    scanf("%d",&t);
    while(t--)
    {
        //printf("start:\n");
        scanf("%s",str);
        if(strcmp(str,"push")==0)
            push(&top, stk, m);
        else if(strcmp(str,"pop")==0)
            pop(&top, stk);
        else if(strcmp(str,"isempty")==0)
            isempty(&top, stk);
        else
            topp(&top, stk);
    }
    return 0;
}

void push(int *top, int stk[],int m)
{
    int k;
    scanf("%d",&k);
    if(*top==m-1)
        printf("-1\n");
    else
    {
        stk[++*top]=k;
        printf("1\n");
    }
}
void pop(int *top,int stk[])
{
    if(*top==-1)
        printf("-1\n");
    else
    {
        printf("%d\n",stk[*top]);
        (*top)--;
    }
}
void isempty(int *top,int stk[])
{
    if(*top==-1)
        printf("1\n");
    else
        printf("0\n");
}
void topp(int *top,int stk[])
{
    if(*top==-1)
        printf("-1\n");
    else
        printf("%d\n",stk[*top]);
}

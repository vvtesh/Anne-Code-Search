#include <stdio.h>
int M;

struct stack {
   int s[100];
   int top;
} st;
 


 
void push(int K) {
if(st.top>=M-1)
printf("%d",-1);
else
{
   
   st.top++;
   st.s[st.top] = K;
   printf("%d",1);
}
}
 
void isempty() {
   if (st.top == -1)
      printf("%d",1);
   else
      printf("%d",0);
}
int stfull()
{
if(st.top==M-1)
return 1;
else
return 0;
}
void top()
{
if((stempty))	
printf("%d",-1);
else

printf("%d",st.s[st.top]);

}
 
void pop() {
if((stempty))	
printf("%d",-1);
   int K;
   K = st.s[st.top];
   st.top--;
    printf("%d",K);
}


 
int main() {
   int K,M,T, choice,i=1;
   char ans;
   st.top = -1;
 
   scanf("%d",&M);
   scanf("%d",&T);
   do
   {
   i++;
      scanf("%s", &choice);
     if(choice=="push") {
     
         scanf("%d", &K);
            push(K);}
     else  if(choice=="isempty") {
         isempty();
        }
     else if(choice=="top")
      {
         top();
        }
     else (choice=="pop")
      {
         K=pop();
      }
      }while(i<T);
      }
      
  
 
return 0;
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int mx;
struct stack
{
	int ele[1000];	
	int top;
};
struct stack st;
int isempty()
{
	if(st.top==-1)
		return 1;
	else
		return 0;
}
int top()
{
	if(!isempty())
		return st.ele[st.top];
	else
		return -1;
}
int push(int el)
{
	if(st.top==mx-1)
	{
		return -1;
	}
	else
	{
		st.top++;
		st.ele[st.top]=el;
		return 1;
	}
}
int pop()
{
	if(!isempty())
	{
		st.top--;
		return st.ele[st.top+1];
		
	}
	else
		return -1;

}

		
int main()
{
	st.top=-1;
	int op;
	scanf("%d",&mx);
	scanf("%d",&op);
	while(op>0)
	{
		char str[10];
		scanf("%s",str);
		//printf("%s\n",str);
		int ans;
		if(str[0]=='p' && str[1]=='u')
		{
			int g;
			scanf("%d",&g);
			ans=push(g);
			printf("%d\n",ans);
			op--;
			//printf("%d\n",st.ele[st.top]);
		}
		else if(str[0]=='p' && str[1]=='o')
		{
			ans=pop();
			printf("%d\n",ans);
			//printf("%d\n",st.ele[st.top]);
			op--;
		}
		else if(str[0]=='t' && str[1]=='o')
		{
			ans=top();
			printf("%d\n",ans);
			//printf("%d\n",st.ele[st.top]);
			op--;
		}
		else
		{
			ans=isempty();
			printf("%d\n",ans);
			//printf("%d\n",st.ele[st.top]);
			op--;
		}
		
	}
	return 0;
}
	
	
	

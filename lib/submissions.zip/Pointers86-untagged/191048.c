#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(void){
	int s,t;
	char ch[15];
	scanf("%d",&s);
	int *a=(int*)malloc(s*sizeof(int));
	scanf("%d",&t);
	t=t+2;
	int Top=-1;
	while(t>0){
		
			scanf("%s",ch);
			if(strcmp(ch,"pop")==0)
			{
						if(Top==-1)
						{
							printf("-1\n");
						}
						else
						{	
							    int k=a[Top];
								printf("%d\n",k);
								Top--;
						}
			}
			if(strcmp(ch,"isempty")==0)
			{
			    if(Top==-1){
	     						printf("1\n");
     						}
				else{
					   printf("0\n");
					}
			}
			if(strcmp(ch,"push")==0)
			{
						 		if(Top==s-1){
									printf("-1\n");
								}
								else{
									int n;
									scanf("%d",&n);
									Top++;
									a[Top]=n;
									printf("1\n");
								}
			}
				if(strcmp(ch,"top")==0){		
								if(Top==-1){
									printf("-1\n");
								}
								else{
									printf("%d\n",a[Top]);
								}
				}
		
		t--;
	}
		
	}


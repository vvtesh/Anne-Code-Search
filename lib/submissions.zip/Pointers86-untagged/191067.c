#include <stdio.h>
#include <string.h>
struct stack
{
	int m;
	int a[1000];
	int top;
}s;
int push()
{
	int x;
	scanf("%d", &x);
	if(s.top == s.m - 1) return -1;
	s.top++;
	s.a[s.top] = x;
	return 1;
}
int pop()
{
	if(isempty() == 1) return -1;
	int b;
	b = s.a[s.top];
	s.top--;
	return b;
}
int isempty()
{
	if(s.top == -1) return 1;
	return 0;
}
int top()
{
	if(isempty() == 1) return -1;
	return s.a[s.top];
}
int main()
{
	s.top = -1;
	int t;
	int i;
	char op[8];
	scanf("%d", &s.m);
	scanf("%d", &t);
	int ans;
	for(i=0; i<t; i++)
	{
		scanf("%s", op);
		if(strcmp("push", op)==0)
		{
			ans = push();
			printf("%d\n", ans);
		}
		else if(strcmp("pop", op)==0)
		{
			ans = pop();
			printf("%d\n", ans);
		}
		else if(strcmp("isempty", op)==0)
		{
			ans = isempty();
			printf("%d\n", ans);
		}
		else if(strcmp("top", op)==0)
		{
			ans = top();
			printf("%d\n", ans);
		}
	}
	return 0;
}






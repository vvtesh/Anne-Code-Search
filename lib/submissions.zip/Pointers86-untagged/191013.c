#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int * stack;
	int max,nop;
	int pop,push;
	int top=0;
	char op[10];
	scanf("%d",&max);
	scanf("%d",&nop);
	stack=(int *)malloc(max*sizeof(int *));
	while(nop)
	{
		
		scanf("%s",op);
		if(!strcmp(op,"push"))
		{
			scanf("%d",&push);
			//printf("here %d %d\n",top,max);
			if (top<max)
			{
				//printf("here");
				
				stack[top]=push;
				//printf("%d\n",stack[top]);
				top++;
				printf("%d\n",1);
			}
			else
			{
				printf("%d\n",-1);
			}
			
		}
		else if(!strcmp(op,"isempty"))
		{
			if(top==0)
			{
				printf("%d\n",1);
			}
			else
			{
				printf("%d\n",0);
			}
		}
		else if(!strcmp(op,"pop"))
		{
			
			//printf("%d",top);	
			if(top==0)
			{
				printf("%d\n",-1);
			}
			else
			{
				printf("%d\n",stack[top-1]);
				top--;
			}
		}
		else if(!strcmp(op,"top"))
		{
			if (top==0)
			{
				printf("%d\n",-1);
			}
			else
			{
				printf("%d\n",stack[top-1]);
			}
		}
		nop--;
	}
	return 0;
}
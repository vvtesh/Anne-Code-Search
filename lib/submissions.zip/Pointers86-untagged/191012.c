#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int M;
int *arr;
int top;


void pop()
{
if(top==-1)
{
  printf("-1\n");
}
else
{
printf("%d\n",arr[top]);
top--;
} 
}

void push(int x)
{
if(top==M-1)
  printf("-1\n");
else
  
  {top++;
  arr[top]=x;
  printf("1\n");
  }
}

void isempty()
{
if (top==-1)
{
printf("1\n");
}
else
printf("0\n");
}


void topp()
{
if (top==-1)
printf("-1\n");
else
  printf("%d\n",arr[top]);
}


int main()
{
int x,i;
int T;
char input[10];
scanf("%d",&M);
arr= (int*)malloc(sizeof(int)*M);
scanf("%d", &T);
top=-1;
for(i=0;i!=T;i++)
{
scanf("%s",input);
if (strcmp("push",input)==0)
{
scanf("%d",&x);
push(x);
}
else if (strcmp("pop",input)==0)
{
pop();
}
else if (strcmp("top",input)==0)
{
topp();
}
else if (strcmp("isempty",input)==0)
{
isempty();
}
}
return 0;
}






















#include<stdio.h>
#include<string.h>
int Top = -1;
int stack[1000];
int n;
int x=1;
void push()
{
   int value;
   scanf("%d",&value);
   if (x > n)
    printf("-1\n");
   else
   {
   Top++;
   stack[Top] = value;
   x++;
   printf("1\n");
   }
}
int isempty()
{
   if ( Top == - 1 )
      printf("1\n");
   else
      printf("0\n");
}
int top()
{
    if (Top == -1)
    {
        printf("-1\n");
    }
    else
    {
      printf("%d\n",stack[Top]);
    }
}
int pop()
{
   int element;
   if ( Top == -1 )
      printf("-1\n");
  else
  {
   element = stack[Top];
   Top--;
   x--;
   printf("%d\n",element);
  }
}
int main()
{
    int choice;
    int t,i;
    char a[100];
    scanf("%d",&n);
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
      scanf("%s",a);
    if (strcmp(a,"push") == 0)
    {
        push();
    }
    else if(strcmp(a,"pop") == 0)
    {
        pop();
    }
    else if(strcmp(a,"top") == 0)
    {
        top();
    }
    else if(strcmp(a,"isempty") == 0)
    {
        isempty();
    }
    }
    return 0;
}

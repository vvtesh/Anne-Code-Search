#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct stack s;
struct stack
{
	int *a;
	int top;
	int size;
};
int empty(/*struct stack s*/){
	return (s.top == -1);
}
void push(/*struct stack s*/int elem){
	if (s.top < s.size - 1){
		s.top++;
		s.a[s.top] = elem;
	}
}
int pop(/*struct stack s*/){
	if (!empty(s)){
		int x = s.top;
		s.top--;
		return s.a[x];
	}
}
int top(/*struct stack s*/){
	return s.a[s.top];
}
int main()
{
	int n; scanf("%d",&n);
	s.top = -1;
	s.a = (int*)(malloc(n*sizeof(int)));
	s.size = n;

	int q; scanf("%d",&q);
	int i;
	for (i=0; i<q; i++){
		char str[100]; scanf("%s",str);
		if (strcmp(str,"push") == 0){
			int d; scanf("%d",&d);
			if (s.top == s.size - 1) printf("-1\n");
			else {printf("1\n"); push(d);}
		}
		else if (strcmp(str,"top") == 0){
			if (empty()) printf("-1\n");
			else printf("%d\n",top());
		}
		else if (strcmp(str,"isempty") == 0){
			if (empty()) printf("1\n");
			else printf("0\n");
		}
		else if (strcmp(str,"pop") == 0){
			if (empty()) printf("-1\n");
			else printf("%d\n",pop());
		}
	}
	return 0;
}
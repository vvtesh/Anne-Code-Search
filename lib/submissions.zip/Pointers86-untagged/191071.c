#include<stdio.h>
#include <string.h>
void main()
{
    int m,top;
    scanf("%d",&m);
    int a[m],elt;
    top=-1;
    int t;
    char ch[10];
    scanf("%d",&t);
    while(t--)
    {
        scanf("%s",ch);
        if(strcmp(ch,"push")==0)
            {   scanf("%d",&elt);
                if(top==m-1)
                {
                    printf("-1\n");
                }
                else
                {
                        top++;
                        a[top]=elt;
                        printf("1\n");
                }
            }
        else if(strcmp(ch,"pop")==0)
            {
                if(top==-1)
                {
                    printf("-1\n");
                }
                else
                {
                    printf("%d\n",a[top]);
                    top--;
                }
            }
        else if(strcmp(ch,"top")==0)
            {
                if(top==-1)
                {
                    printf("-1\n");
                }
                else
                    printf("%d\n",a[top]);
            }
        else if(strcmp(ch,"isempty")==0)
            {
                if(top==-1)
                    printf("1\n");
                else
                    printf("0\n");

            }


    }

}

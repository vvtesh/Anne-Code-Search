#include<stdio.h>
#include<string.h>

int M,i,j,k,n,t;
int top=-1;

void isempty(){
	if(top==(-1)){
		printf("1");
		return;
	}
	else{
		printf("0");
		return;
	}
}

void topp(int T[]){
	if(top==(-1)){
		printf("-1");
		return;
	}
	printf("%d",T[top]);
	return;
}

void push(int T[]){
	scanf("%d",&n);
		
	if(top==(M-1)){
		printf("-1");
		return;
	}
	
	top+=1;
	T[top]=n;
	printf("1");
	return;	
}

void pop(int T[]){
	if(top==(-1)){
		printf("-1");
		return;
	}
	printf("%d",T[top]);
	top-=1;
	return;
}

int main(){
	scanf("%d",&M);
	scanf("%d",&t);
	char ch[10];

	int T[M];

	while(t--){
		scanf("%s",ch);
		if(strcmp(ch,"push")==0){
			push(T);
			printf("\n");
		}
		if(strcmp(ch,"pop")==0){
			pop(T);
			printf("\n");
		}
		if(strcmp(ch,"top")==0){
			topp(T);
			printf("\n");
		}
		if(strcmp(ch,"isempty")==0){
			isempty();
			printf("\n");
		}		
	}

	

	return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>


int top=-1;



void push(int arr[],int x, int size)
{
	int n;
	
	scanf("%d",&n);

	if(top==(size-1))
		printf("%d\n",-1);

	else
  	{
	   top++;
	   arr[top] = n;
	   printf("%d\n",1);
	}  
   

   
   

}

void pop(int arr[])
{
	int n;
	if(top==-1)
		printf("%d\n",-1);

	else
	{

		n = arr[top];
		top--;
		
		printf("%d\n",n);

    }

   

}

void top1(int arr[])
{

	if(top==-1)
		printf("%d\n",-1);
	else
		printf("%d\n",arr[top]);

}


void isempty()
{
	if(top==-1)
		printf("%d\n",1);
	else
		printf("%d\n",0);



}



int main()
{

	int size;
	int x=0;

	int nop;

	scanf("%d",&size);

	int arr[size];
	
	

	scanf("%d",&nop);
	
	char ch[20];

	while(nop)
	{
		
		scanf("%s",ch);

	 if(strcmp(ch,"push")==0)
	 {
	 	x++;
	 	push(arr,x,size);
	 	

	 }
		
	 if(strcmp(ch,"pop")==0)
	 {
	 	pop(arr);
	 	x--;
	 	

	 }


	 if(strcmp(ch,"top")==0)
	 {
	 	top1(arr);
	 	

	 }

	 if(strcmp(ch,"isempty")==0)
	 {
	 	isempty();
	 	

	 }

	
	 --nop;

	}


 
return 0;


}
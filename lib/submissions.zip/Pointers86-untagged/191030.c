#include<stdio.h>
#include<string.h>
#include<stdlib.h>


int isEmpty(int top){
	if(top==0){
		return 1;
	}
	else return 0;
}

int Push( int *ar, int top , int size){
	int x;
	scanf("%d",&x);

	if(top==size){
		printf("-1\n");
	}
	else{
		printf("1\n");
		//printf("%d\n",x);
		ar[top++]=x;
	}
	return top;
}

int Pop(int *ar, int top){
	if(isEmpty(top)){
		printf("-1\n");
	}
	else{
		printf("%d\n",ar[top-1]);
		top--;
	}
	return top;
}

void Top(int *ar,int top){
	if(isEmpty(top)){
		printf("-1\n");
	}
	else{
		printf("%d\n",ar[top-1]);
	}
}

int main(int argc, char const *argv[])
{
	int n;
	scanf("%d",&n);

	int *ar=malloc(sizeof(int )*n);
	int ic,top=0;
	scanf("%d",&ic);

	char *str=malloc(sizeof(char *));
	getchar();
		
	while(ic--){
		//printf("%d\n",ic);
		fgets(str,80,stdin);
		str[strlen(str)-1]='\0';
		//printf("%s\n",str);
		
		if(strcmp(str,"push")==0){
			top=Push(ar,top,n);
			getchar();
		
		}
		else if(strcmp(str,"pop")==0){
			top=Pop(ar,top);
		}
		else if(strcmp(str,"top")==0){
			Top(ar,top);
		}
		else if(strcmp(str,"isempty")==0){
			printf("%d\n",isEmpty(top));
		}
		else{
			printf("ERROR!!\n");
		}
	}
	return 0;
}
#include <stdio.h>
#include <stdlib.h>
int top1=-1,size;
int push(int *arr,int n)
{   if(top1==(size-1))
        return -1;
    top1++;
    *(arr+top1)=n;
    return 1;
}
int pop(int *arr)
{   if(top1==-1)
        return -1;
    int q=*(arr+top1);
    top1--;
    return q;


}
int isempty(int *arr)
{
    if(top1==-1)
        return 1;
    return 0;

}
int top(int *arr)
{   if(top1==-1)
        return -1;
    int q=*(arr+top1);
    return q;

}
int main()
{   int m,t;
    char str[100];
    scanf("%d",&m);
    size=m;
    int stack[m];
    scanf("%d",&t);
    int z=0;
    for(;z<t;z++)
    {   scanf("%s",str);
        if(strcmp(str,"push")==0)
        {
            int k;
            scanf("%d",&k);
            int l=push(stack,k);
            printf("%d\n",l); 
        }
        else if(strcmp(str,"pop")==0)
        {
            int l=pop(stack);
            printf("%d\n",l);       
        }
        else if(strcmp(str,"isempty")==0)
        {
            int l=isempty(stack); 
            printf("%d\n",l);       
        }
        else if(strcmp(str,"top")==0)
        {
            int l=top(stack); 
            printf("%d\n",l);       
        }
            
    }


return 0;


}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int stack[1000];
void push();
int pop();
int is_empty();
int top_element();
int top = -1;

int main()
{
   int m;
   scanf("%d",&m);
   int element;
   char choice[20];
   int i=0,T;
   scanf("%d",&T);

   while(i<T)
   {
        gets(choice);
        if (strcmp(choice,"push")==0)
        {
            if ( top == m - 1 )
                  printf("-1\n");
            else
            {
               scanf("%d",&element);
               push(element);
               printf("1\n");
            }
        i++;

        }

        else if(strcmp(choice,"pop")==0)
        {
            if ( top == -1 )
               printf("-1\n");
            else
            {
               element = pop();
               printf("%d\n", element);
            }
        i++;

        }

        else if (strcmp(choice,"top")==0)
        {
            if(!is_empty())
            {
               element = top_element();
               printf("%d\n", element);
            }
            else
               printf("-1\n");
        i++;


        }

        else if (strcmp(choice,"isempty")==0)
        {

            if(is_empty())
               printf("1\n");
            else
               printf("0\n");
    i++;

        }

      }
   return 0;
}

void push(int value)
{
   top++;
   stack[top] = value;
}

int pop()
{
   int element;

   if ( top == -1 )
      return top;

   element = stack[top];
   top--;

   return element;
}


int is_empty()
{
   if ( top == - 1 )
      return 1;
   else
      return 0;
}

int top_element()
{
   return stack[top];
}

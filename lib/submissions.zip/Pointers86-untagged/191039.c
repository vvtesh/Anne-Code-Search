#include <stdio.h>
int top=-1;int n;
int main(void) {char arr[8];
scanf("%d",&n);int m,i,x;scanf("%d",&m);int brr[n];
for(i=0;i<m;i++){
	scanf("%s",arr);
	if(strlen(arr)==7){if(top==-1)printf("1\n");else printf("0\n");}
else	if(strlen(arr)==3&&arr[0]=='t'){if(top==-1)printf("-1\n"); else printf("%d\n",brr[top]);}
else	if(strlen(arr)==3&&arr[0]=='p'){if(top==-1)printf("-1\n"); else{ printf("%d\n",brr[top]);top--;}}
else {scanf("%d",&x);if(top==n-1)printf("-1\n");else{top++;brr[top]=x;printf("1\n");}}
	
	
}
return 0;
}

#include<stdio.h>
int stack[1000],t=-1,size;
int pop();
int isempty();// 1 E;0 not empty
int top(); //-1
int push(int n);


int main()
{int kitne,n;
 char qry[10];
    scanf("%d%d",&size,&kitne);
    while(kitne--)
    {
        scanf("%s",qry);
        switch(qry[0])
        {case 'p': if(qry[1]=='u')
                  {scanf("%d",&n);
                  printf("%d\n",push(n));
                  }

                   else{printf("%d\n",pop());}break;
         case 'i': printf("%d\n",isempty());break;
         case 't': printf("%d\n",top());break;
        }



    }



return 0;
}
int pop()
{if(t>=0)
 {
     return stack[t--];
 }
 return -1;
}
int push(int n)
{if(t==size-1){return -1;}

 stack[++t]=n;

return 1;
}
int top()
{if(t>-1){return stack[t];}
 return -1;

}
int isempty()
{if(t==-1)
{return 1;

}
return 0;

}

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct stack
{
	int data[100];
	int top;
}s;

int isfull();
int isempty();
void pop();
void top();
void push(int t);

int main()
{
int m,t;
s.top=-1;
char choice[20];
scanf("%d",&m);
if(!((m>=1)&&(m<=1000)))
{
	return 1;
}

scanf("%d",&t);
if(!((t>=1)&&(t<=1000)))
{
	return 1;
}
while(t>0)
{	
	
	scanf("%s",choice);
	if(strcmp(choice,"push")==0)
	{	
		push(m);
	}
	else if(strcmp(choice,"pop")==0)
	{	
		pop();
	}
	else if(strcmp(choice,"isempty")==0)
	{	
		if(isempty()==1)
			printf("1\n");
		else
			printf("0\n");
		
	}
	else if(strcmp(choice,"top")==0)
	{	
		top();
	}	

	t--;
	
}
return 0;
}

int isempty()
{
return (s.top==-1);
}
int isfull(int m)
{
return (s.top==m-1);
}
void push(int m)
{
	int k;
	scanf("%d",&k);
	if(!((k>=1)&&(k<=1000)))
{
	printf("-1\n");
}
	if(isfull(m))
	{
		printf("-1\n");
	}
	else
	{
	s.top++;
	s.data[s.top]=k;
	printf("1\n");
	}
}

void pop()
{
	if(isempty())
	{
		printf("-1\n");
	}
	else
	{
		printf("%d\n",s.data[s.top]);
		s.top--;
	}
}
void top()
{
if(isempty())
	printf("-1\n");
else
	printf("%d\n",s.data[s.top]);
}

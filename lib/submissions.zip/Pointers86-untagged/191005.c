#include<stdio.h>
struct point
{
    int x, y;
};

struct node
{
    struct point a;
    struct node* next;
    struct node* prev;
} *front,*rear;
void fdisplay()
{
    //printf("\nList is (forward) : ");
    if(front==NULL)
        printf("NULL\n");
    struct node* tmp=front;
    while(tmp!=NULL)
    {
        printf("%d %d\n",(tmp->a).x,(tmp->a).y);
        tmp=tmp->next;
    }
    printf("\n");
}
void rdisplay()
{
    //printf("\nList is (backward) : ");
    if(front==NULL)
        printf("NULL\n");
    struct node* tmp=rear;
    while(tmp!=NULL)
    {
        printf("%d %d\n",(tmp->a).x,(tmp->a).y);
        tmp=tmp->prev;
    }
    printf("\n");
}
void finsert(int a,int b)
{
    struct node *tmp=malloc(sizeof(struct node));
    (tmp->a).x=a;
    (tmp->a).y=b;
    if(front==NULL)
    {
       front=rear=tmp;
       front->next=rear->next=front->prev=rear->prev=NULL;
    }
    else
    {
        tmp->next=front;
        tmp->prev=NULL;
        front->prev=tmp;
        front=tmp;
    }
}
void rinsert(int a, int b)
{
    struct node *tmp=malloc(sizeof(struct node));
    (tmp->a).x=a;
    (tmp->a).y=b;
    if(rear==NULL)
    {
       front=rear=tmp;
       front->next=rear->next=front->prev=rear->prev=NULL;
    }
    else
    {
        tmp->next=NULL;
        tmp->prev=rear;
        rear->next=tmp;
        rear=tmp;
    }
}
void deletebeg()
{
    if(front==rear)
    {
        struct node* tmp=front;
        free(tmp);
        front=rear=NULL;
    }
    else
    {
        struct node* tmp=front;
        front=front->next;
        front->prev=NULL;
        free(tmp);
    }
}
void deletelast()
{
    if(front==rear)
    {
        struct node* tmp=front;
        free(tmp);
        front=rear=NULL;
    }
    else
    {
        struct node* tmp=rear;
        (rear->prev)->next=NULL;
        rear=rear->prev;
        free(tmp);
    }
}
void deletelist()
{
    struct node *tmp=front;
    struct node* del;
    if(front==NULL)
        menu();
    while(tmp->next!=NULL)
        {
            del=tmp;
            tmp=tmp->next;
            free(del);
        }
    free(rear);
    front=rear=NULL;
}
void menu()
{
    char choice[20]; int a,b;
    do
    {
       scanf("%s",&choice);
       if(strcmp("0",choice)==0)
            exit(0);
        else if(strcmp("printlist",choice)==0)
            {
                scanf("%d",&a);
                if(a==0)
                    fdisplay();
                else
                    rdisplay();
            }
       else if(strcmp("createlist",choice)==0)
            continue;
       else if(strcmp("deletebeg",choice)==0)
            deletebeg();
        else if(strcmp("deletelast",choice)==0)
            deletelast();
        else if(strcmp("deletelist",choice)==0)
            deletelist();
        else if(strcmp("insertbeg")==0)
            {
                scanf("%d %d",&a,&b);
                finsert(a,b);
            }
        else
            {
                scanf("%d %d",&a,&b);
                rinsert(a,b);
            }
    }while(1);
}
int main()
{
    front=malloc(sizeof(struct node));
    rear=malloc(sizeof(struct node));
    front=rear=NULL;
    menu();
    return 0;
}

#include<stdio.h>
#include<string.h>
int main()
{
int M,T,K,top=-1,a;
int i;
char choice[9];
scanf("%d",&M);
int arr[M];
scanf("%d",&T);
for(i=0;i<T;i++)
{
scanf("%s",choice);
if(!strcmp(choice,"push"))
{
scanf("%d",&K);
			
if(top==M-1)

printf("%d\n",-1);

else
{
top++;
arr[top]=K;
printf("%d\n",1);
}
}
else if(!strcmp(choice,"isempty"))

	printf("%d\n",top==-1);

else if(!strcmp(choice,"top"))
{
if(top==-1)
printf("-1\n");
else
printf("%d\n",arr[top]);
}
else if(!strcmp(choice,"pop"))
{
if(top==-1)	
printf("-1\n");
else
{
printf("%d\n",arr[top]);
top--;
}	
}
}
return 0;
}



#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int top=-1,x;
void push(int A[],int p)

{
    scanf("%d",&x);
    if(top==(p-1))
    {
        printf("-1\n");

    }
    else{
    printf("1\n");

    A[++top]=x;
    }

}
void pop(int A[]){
    if(top==-1)
    {
        printf("-1\n");

    }
    else{
        printf("%d\n",A[top]);
        top--;
    }
}
int Isempty(int A[]){
    if(top==-1){
        return 1;
        }
    else{
        return 0 ;
        }
}


void isempty(int A[]){
    if(Isempty(A)==1){
    printf("1\n");
    }
    else if(Isempty(A)==0)
    {
    printf("0\n");
    }
}
int Top(int A[]){
    if(Isempty(A)==1){
    printf("-1\n");
    }
    else if(Isempty(A)==0)
    {
    printf("%d\n",A[top]);
    }
}
void main(){
    int p,l,i=0;
    scanf("%d",&p);
    int A[p];
    scanf("%d",&l);
    char s[10];
    while (i<l){
            scanf("%s",&s);
            if (strcmp(s,"push")==0){
                push(A,p);
            }
            else if(strcmp(s,"isempty")==0){
                isempty(A);
            }
            else if (strcmp(s,"pop")==0){
                pop(A);
            }
            else if (strcmp(s,"top")==0){
                Top(A);
            }
            i++;
    }

}

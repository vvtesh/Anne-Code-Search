#include<stdio.h>
#include<string.h>

int top=-1;
int arr[100];
void push(a,cap)
{
   if(top==cap-1)
     printf("-1\n");

   else
   {
     top++;
     arr[top]=a;
     printf("1\n");
    }

}

void pop()
{
   if(top==-1)
   printf("-1\n");
   else
   {
   printf("%d\n",arr[top]);
    top--;
   }
}
void isempty()
{
  if(top==-1)
    {
      printf("1\n");
    }
  else
  {
     printf("0\n");
  }

}

void Top()
{
   if(top==-1)
   {
     printf("-1\n");
   }
   else
   printf("%d\n",arr[top]);
}

int main()
{
   int cap,op,a,j=1;
   char ch[120];
   scanf("%d",&cap);
   scanf("%d",&op);
   while(j<=op)
{
   scanf("%s",ch);
   if(strcmp(ch,"push")==0)
   {
      scanf("\n%d",&a);
      push(a,cap);
   }
   else if(strcmp(ch,"pop")==0)
   {
      pop();
   }
    else if(strcmp(ch,"top")==0)
   {
      Top();
   }
   else if(strcmp(ch,"isempty")==0)
   {
      isempty();
   }
   j++;
}
return 0;

}

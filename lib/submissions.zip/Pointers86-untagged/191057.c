#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int c=0,cur=-1,m;
void top(int x[])
{
	if(c==0)
		printf("-1\n");
	else
		printf("%d\n",x[cur]);
}
void isempty()
{
	if(c==0)
		printf("1\n");
	else
		printf("0\n");
}
void pop(int x[])
{
	if(c==0)
		printf("-1\n");
	else
	{
		printf("%d\n",x[cur]);
		c--;
		cur--;
	}
}
void push(int x[],int k)
{
	if(c<m)
	{
		x[c]=k;
		c++;
		cur++;
		printf("1\n");
	}
	else
		printf("-1\n");

}
int main()
{
	scanf("%d",&m);
	int t;
	scanf("%d",&t);
	int a[m];
	char s[20];
	while(t>0)
	{
		scanf("%s",s);
		if(strcmp(s,"push")==0)
		{
			int i;
			scanf("%d",&i);
			push(a,i);
		}
		else if(strcmp(s,"pop")==0)
			pop(a);
		else if(strcmp(s,"isempty")==0)
			isempty();
		else
			top(a);
		t--;
	}
	return 0;
}
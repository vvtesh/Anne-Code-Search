#include<stdio.h>
#include<string.h>
void isempty();
void top();
void push();
void pop();
int* s;
int m;
int to=-1;
int main()
{
int t,i=0;
scanf("%d",&m);
scanf("%d",&t);
s=(int*)malloc(m*sizeof(int));
while(i<t)
{
char c[20];
scanf("%s",c);
if(strcmp(c,"isempty")==0)
isempty();
else if(strcmp(c,"top")==0)
top();
else if(strcmp(c,"push")==0)
push();
else if(strcmp(c,"pop")==0)
pop();
i++;
}
return 0;
}
void isempty()
{
if(to==-1)
printf("1\n");
else
printf("0\n");

}
void top()
{
if(to==-1)
printf("-1\n");
else
printf("%d\n",s[to]);

}
void push()
{
int d;
scanf("%d",&d);
if(to==m-1)
printf("-1\n");
else
{
to++;
s[to]=d;
printf("1\n");
}
}
void pop()
{
if(to==-1)
printf("-1\n");
else
{
int d;
d=s[to];
to--;
printf("%d\n",d);
}
}



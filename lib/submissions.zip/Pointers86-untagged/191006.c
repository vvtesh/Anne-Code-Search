#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct stack
{
    int *p;
    int n;
    int top;
};
int main()
{
    struct stack a;
    scanf("%d",&a.n);
    a.p=(struct stack*)malloc(sizeof(int)*(a.n));
    a.top=-1;
    int m;
    scanf("%d",&m);
    int i=1;
    char s[20];
    while(i<=m)
    {
       scanf("%s",s);
       if(strcmp(s,"pop")==0)
       {
            pop(&a);
            i++;
       }
       else if(strcmp(s,"push")==0)
            {
                push(&a);
                i++;
            }
       else if(strcmp(s,"top")==0)
           {
            top(&a);
            i++;
           }
       else if(strcmp(s,"isempty")==0)
            {
                isempty(&a);
                i++;
            }


    }
    return 0;
}

void push(struct stack *a)
{
    int k;
    scanf("%d",&k);
    if(a->top==(a->n)-1)
        printf("%d\n",-1);
    else
    {
        a->top=(a->top)+1;
        a->p[a->top]=k;
        printf("%d\n",1);
    }
}
void isempty(struct stack *a)
{
    if(a->top==-1)
        printf("%d\n",1);
    else
        printf("%d\n",0);
}
void top(struct stack *a)
{
    if(a->top==-1)
        printf("%d\n",-1);
    else
        printf("%d\n",a->p[a->top]);
}
void pop(struct stack *a)
{
    if(a->top==-1)
        printf("%d\n",-1);
    else
    {
        printf("%d\n",a->p[a->top]);
        a->top=a->top-1;
    }
}

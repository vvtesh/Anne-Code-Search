#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int m;
int *a;
int top=-1;

void push(int x)
{
    if(top==m-1)
    {
        printf("-1\n");
    }
    else
    {
        top=top+1;
        a[top]=x;
        printf("1\n");
    }

}
void pop()
{
    if(top==-1)
    {
        printf("-1\n");
    }
    else
    {
        printf("%d\n",a[top]);
        top=top-1;
    }
}
void isempty()
{
    if(top==-1)
    {
        printf("1\n");
    }
    else
    {
        printf("0\n");
    }
}
void topp()
{
    if(top==-1)
    {
        printf("-1\n");
    }
    else
    {
        printf("%d\n",a[top]);
    }
}


int main()
{
    int t,q;
    scanf("%d",&m);
    a=(int *)malloc((sizeof(int)*m));
    scanf("%d",&t);
    while(t>0)
    {
        char arr[10];
        scanf("%s",&arr);
        if(strcmp(arr,"push")==0)
        {
            scanf("%d",&q);
            push(q);
        }
        if(strcmp(arr,"pop")==0)
        {
            pop();
        }
        if(strcmp(arr,"top")==0)
        {
            topp();
        }
        if(strcmp(arr,"isempty")==0)
        {
            isempty();
        }
        t--;
    }
    return 0;



}

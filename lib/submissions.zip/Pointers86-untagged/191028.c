#include<stdio.h>
#include<string.h>
int main()
{
    char a[10];
    int m,t,i;
    scanf("%d",&m);
    scanf("%d",&t);
    int data[m];
    m=m-1;
    int top=-1;
    for(i=0;i<t+2;i++)
   {
    scanf("%s",a);
    if(strcmp(a,"push")==0)
    {
        if((top+1)>m)
        printf("-1\n");
        else
        {
            top=top+1;
            printf("1\n");
            scanf("%d",&data[top]);
        }
    }
    else if(strcmp(a,"isempty")==0)
    {
        if(top<=-1)
        printf("1\n");
        else
        printf("0\n");
    }
    else if(strcmp(a,"top")==0)
    {
        if(top<=-1)
        printf("-1\n");
        else
        printf("%d\n",data[top]);
    }
    else if(strcmp(a,"pop")==0)
    {
        if(top<=-1)
        printf("-1\n");

        else
        {
            printf("%d\n",data[top]);
            top=top-1;
        }
    }
}
return 0;
}

#include<stdio.h>
#include<string.h>

int m;
struct node{
	
	int arr[20];	
	int top;
};
struct node stack;


int isempty(){
	int d;	
	if(stack.top==-1){
d=1;		
printf("%d\n",d);
			
}
	else{
d=0	;	
printf("%d\n",d);	
			
}

	return d;
}

void push(int k){

	if(stack.top==m-1){
	printf("-1\n");
	
}
	else{
		printf("1\n");
		stack.arr[++stack.top]=k;	
}

}

void pop(){
	int b;	
	if(stack.top==-1){
		printf("-1\n");

	}

	else{
	
	b=stack.arr[stack.top];	
	printf("%d\n",b);
	stack.top--;
}
}

void top(){
	
	if(stack.top==-1){
	printf("-1\n");
	}
	else{	
	printf("%d\n",stack.arr[stack.top]);	
}
}


int main(){
	stack.top=-1;
	int t,k;
	scanf("%d",&m);
	scanf("%d",&t);
	int i;char str[30];
	for(i=0;i<t;i++){
		scanf("%s",str);
		if(strcmp(str,"push")==0){
			scanf("%d",&k);
			push(k);
		}
		else if(strcmp(str,"pop")==0){

		pop();
		}

		else if(strcmp(str,"top")==0){
			top();		
		}
		else if(strcmp(str,"isempty")==0)
			isempty();
}

return 0;	
}



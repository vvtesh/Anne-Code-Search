#include<stdio.h>
#include<stdlib.h>
#include<string.h>


int top=-1;



void push(int arr[],int x, int size) 	// array,parameter
{
	int n;
	
	scanf("%d",&n); 	// parameter

	if(top==(size-1)) 	// conditional,parameter
		printf("%d\n",-1); 	// parameter

	else
  	{
	   top++; 	// increment
	   arr[top] = n; 	// array
	   printf("%d\n",1); 	// parameter
	}  
   

   
   

}

void pop(int arr[]) 	// array,function,parameter
{
	int n;
	if(top==-1) 	// conditional,parameter
		printf("%d\n",-1); 	// parameter

	else
	{

		n = arr[top]; 	// array
		top--; 	// decrement
		
		printf("%d\n",n); 	// parameter

    }

   

}

void top1(int arr[]) 	// array,function,parameter
{

	if(top==-1) 	// conditional,parameter
		printf("%d\n",-1); 	// parameter
	else
		printf("%d\n",arr[top]); 	// array,parameter

}


void isempty() 	// function,parameter
{
	if(top==-1) 	// conditional,parameter
		printf("%d\n",1); 	// parameter
	else
		printf("%d\n",0); 	// parameter



}



int main()
{

	int size;
	int x=0;

	int nop;

	scanf("%d",&size); 	// parameter

	int arr[size]; 	// array
	
	

	scanf("%d",&nop); 	// parameter
	
	char ch[20]; 	// array

	while(nop) 	// parameter
	{
		
		scanf("%s",ch); 	// parameter

	 if(strcmp(ch,"push")==0) 	// conditional,parameter
	 {
	 	x++; 	// increment
	 	push(arr,x,size); 	// parameter
	 	

	 }
		
	 if(strcmp(ch,"pop")==0) 	// conditional,parameter
	 {
	 	pop(arr); 	// parameter
	 	x--; 	// decrement
	 	

	 }


	 if(strcmp(ch,"top")==0) 	// conditional,parameter
	 {
	 	top1(arr); 	// parameter
	 	

	 }

	 if(strcmp(ch,"isempty")==0) 	// conditional,parameter
	 {
	 	isempty(); 	// parameter
	 	

	 }

	
	 --nop; 	// decrement

	}


 
return 0;


}

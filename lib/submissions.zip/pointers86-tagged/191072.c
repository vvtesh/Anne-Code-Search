#include<stdio.h>
#include<stdlib.h>

int *ptr,M,top1=-1; 	// pointer

int push(int k) 	// parameter
{ 
  if(top1==M-1) 	// conditional,parameter
   return -1;
  else
  {
	top1++; 	// increment
    ptr[top1]=k; 	// array
    return 1;
    
  }
}

int isempty() 	// parameter
{
  if(top1==-1) 	// conditional,parameter
   return 1;
  else 
   return 0;

}


int top() 	// parameter
{
  if(top1==-1) 	// conditional,parameter
{
    return -1;
}
  else
    return ptr[top1]; 	// array
}


int pop() 	// parameter
{
  if(top1==-1) 	// conditional,parameter
    return -1;
  else
  { 
    
    int l=ptr[top1]; 	// array
    top1--; 	// decrement
    return l;
  }

}

int main()
{
  int k,T,cnt=1;
  char str[10]; 	// array
  
  scanf("%d",&M); 	// parameter
  
  scanf("%d",&T); 	// parameter
  while(cnt<=T) 	// parameter
  {
  
  scanf("%s",str); 	// parameter
  ptr=(int *)malloc(M*sizeof(int));  	// pointer,parameter
  if(strcmp("push",str)==0) 	// conditional,parameter
  {
 
    scanf("%d",&k); 	// parameter
    printf("%d",push(k)); 	// parameter

  }
  else 
  if(strcmp("isempty",str)==0) 	// conditional,parameter
  {
     printf("%d",isempty()); 	// parameter

  }
  else
  if(strcmp("top",str)==0) 	// conditional,parameter
  {
     printf("%d",top()); 	// parameter
  }
  else
  if(strcmp("pop",str)==0) 	// conditional,parameter
  {
     printf("%d",pop());   	// parameter

  }
  cnt++; 	// increment
  }  
   
  return 0;
}

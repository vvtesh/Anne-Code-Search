#include<stdio.h>



void push(int *, int stk[], int); 	// pointer,array,function,parameter

void pop(int *,int stk[]); 	// pointer,array,function,parameter

void isempty(int *,int stk[]); 	// pointer,array,function,parameter

void topp(int *,int stk[]); 	// pointer,array,function,parameter



int main()

{

    int m,t,k,stk[10001],top=-1; 	// array

    char str[20]; 	// array

    scanf("%d",&m); 	// parameter

    scanf("%d",&t); 	// parameter

    while(t--) 	// parameter

    {

        //printf("start:\n");

        scanf("%s",str); 	// parameter

        if(strcmp(str,"push")==0) 	// conditional,parameter

            push(&top, stk, m); 	// parameter

        else if(strcmp(str,"pop")==0) 	// conditional,parameter

            pop(&top, stk); 	// parameter

        else if(strcmp(str,"isempty")==0) 	// conditional,parameter

            isempty(&top, stk); 	// parameter

        else

            topp(&top, stk); 	// parameter

    }

    return 0;

}



void push(int *top, int stk[],int m) 	// array,function,parameter

{

    int k;

    scanf("%d",&k); 	// parameter

    if(*top==m-1) 	// conditional,parameter

        printf("-1\n"); 	// parameter

    else

    {

        stk[++*top]=k; 	// array,increment

        printf("1\n"); 	// parameter

    }

}

void pop(int *top,int stk[]) 	// array,function,parameter

{

    if(*top==-1) 	// conditional,parameter

        printf("-1\n"); 	// parameter

    else

    {

        printf("%d\n",stk[*top]); 	// array,parameter

        (*top)--; 	// decrement,parameter

    }

}

void isempty(int *top,int stk[]) 	// array,function,parameter

{

    if(*top==-1) 	// conditional,parameter

        printf("1\n"); 	// parameter

    else

        printf("0\n"); 	// parameter

}

void topp(int *top,int stk[]) 	// array,function,parameter

{

    if(*top==-1) 	// conditional,parameter

        printf("-1\n"); 	// parameter

    else

        printf("%d\n",stk[*top]); 	// array,parameter

}

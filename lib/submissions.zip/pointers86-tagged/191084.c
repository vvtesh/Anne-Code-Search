#include<stdio.h>
#include<string.h>
struct stk
{int a[1000]; 	// array
int max;
int top;
}s;
void isempty() 	// function,parameter
{if(s.top==-1) 	// conditional,parameter
  {printf("1\n"); 	// parameter
  }
  else
  printf("0\n"); 	// parameter
  
}
void top() 	// function,parameter
{if(s.top==-1) 	// conditional,parameter
 {printf("-1\n"); 	// parameter
 }
 else
 printf("%d\n",s.a[s.top]); 	// array,parameter
}
void push() 	// function,parameter
{int p;
if(s.top==s.max) 	// conditional,parameter
  {scanf("%d",&p); 	// parameter
  printf("-1\n"); 	// parameter
  }
  else
  {s.top++; 	// increment
  scanf("%d",&s.a[s.top]); 	// array,parameter
  printf("1\n"); 	// parameter
  }
}
void pop() 	// function,parameter
{if(s.top==-1) 	// conditional,parameter
  {printf("-1\n"); 	// parameter
  }
  else
  {printf("%d\n",s.a[s.top]); 	// array,parameter
  s.top--; 	// decrement
  }
}
int main()
{int M,T;
scanf("%d",&M); 	// parameter
s.max=M-1;
s.top=-1;
scanf("%d",&T); 	// parameter
while(T>0) 	// parameter
 {char st[10]; 	// array
 scanf("%s",&st); 	// parameter
 if(strcmp(st,"pop")==0) 	// conditional,parameter
 pop(); 	// parameter
 else if(strcmp(st,"isempty")==0) 	// conditional,parameter
 isempty(); 	// parameter
 else if(strcmp(st,"top")==0) 	// conditional,parameter
 top(); 	// parameter
 else if(strcmp(st,"push")==0) 	// conditional,parameter
 push(); 	// parameter
 T--; 	// decrement
 }

return 0;
}

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct stack
{
	int data[100]; 	// array
	int top;
}s;

int isfull(); 	// parameter
int isempty(); 	// parameter
void pop(); 	// function,parameter
void top(); 	// function,parameter
void push(int t); 	// function,parameter

int main()
{
int m,t;
s.top=-1;
char choice[20]; 	// array
scanf("%d",&m); 	// parameter
if(!((m>=1)&&(m<=1000))) 	// conditional,parameter
{
	return 1;
}

scanf("%d",&t); 	// parameter
if(!((t>=1)&&(t<=1000))) 	// conditional,parameter
{
	return 1;
}
while(t>0) 	// parameter
{	
	
	scanf("%s",choice); 	// parameter
	if(strcmp(choice,"push")==0) 	// conditional,parameter
	{	
		push(m); 	// parameter
	}
	else if(strcmp(choice,"pop")==0) 	// conditional,parameter
	{	
		pop(); 	// parameter
	}
	else if(strcmp(choice,"isempty")==0) 	// conditional,parameter
	{	
		if(isempty()==1) 	// conditional,parameter
			printf("1\n"); 	// parameter
		else
			printf("0\n"); 	// parameter
		
	}
	else if(strcmp(choice,"top")==0) 	// conditional,parameter
	{	
		top(); 	// parameter
	}	

	t--; 	// decrement
	
}
return 0;
}

int isempty() 	// parameter
{
return (s.top==-1); 	// parameter
}
int isfull(int m) 	// parameter
{
return (s.top==m-1); 	// parameter
}
void push(int m) 	// function,parameter
{
	int k;
	scanf("%d",&k); 	// parameter
	if(!((k>=1)&&(k<=1000))) 	// conditional,parameter
{
	printf("-1\n"); 	// parameter
}
	if(isfull(m)) 	// parameter
	{
		printf("-1\n"); 	// parameter
	}
	else
	{
	s.top++; 	// increment
	s.data[s.top]=k; 	// array
	printf("1\n"); 	// parameter
	}
}

void pop() 	// function,parameter
{
	if(isempty()) 	// parameter
	{
		printf("-1\n"); 	// parameter
	}
	else
	{
		printf("%d\n",s.data[s.top]); 	// array,parameter
		s.top--; 	// decrement
	}
}
void top() 	// function,parameter
{
if(isempty()) 	// parameter
	printf("-1\n"); 	// parameter
else
	printf("%d\n",s.data[s.top]); 	// array,parameter
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int mx;
struct stack
{
	int ele[1000];	 	// array
	int top;
};
struct stack st;
int isempty() 	// parameter
{
	if(st.top==-1) 	// conditional,parameter
		return 1;
	else
		return 0;
}
int top() 	// parameter
{
	if(!isempty()) 	// parameter
		return st.ele[st.top]; 	// array
	else
		return -1;
}
int push(int el) 	// parameter
{
	if(st.top==mx-1) 	// conditional,parameter
	{
		return -1;
	}
	else
	{
		st.top++; 	// increment
		st.ele[st.top]=el; 	// array
		return 1;
	}
}
int pop() 	// parameter
{
	if(!isempty()) 	// parameter
	{
		st.top--; 	// decrement
		return st.ele[st.top+1]; 	// array
		
	}
	else
		return -1;

}

		
int main()
{
	st.top=-1;
	int op;
	scanf("%d",&mx); 	// parameter
	scanf("%d",&op); 	// parameter
	while(op>0) 	// parameter
	{
		char str[10]; 	// array
		scanf("%s",str); 	// parameter
		//printf("%s\n",str);
		int ans;
		if(str[0]=='p' && str[1]=='u') 	// conditional,parameter
		{
			int g;
			scanf("%d",&g); 	// parameter
			ans=push(g); 	// parameter
			printf("%d\n",ans); 	// parameter
			op--; 	// decrement
			//printf("%d\n",st.ele[st.top]);
		}
		else if(str[0]=='p' && str[1]=='o') 	// conditional,parameter
		{
			ans=pop(); 	// parameter
			printf("%d\n",ans); 	// parameter
			//printf("%d\n",st.ele[st.top]);
			op--; 	// decrement
		}
		else if(str[0]=='t' && str[1]=='o') 	// conditional,parameter
		{
			ans=top(); 	// parameter
			printf("%d\n",ans); 	// parameter
			//printf("%d\n",st.ele[st.top]);
			op--; 	// decrement
		}
		else
		{
			ans=isempty(); 	// parameter
			printf("%d\n",ans); 	// parameter
			//printf("%d\n",st.ele[st.top]);
			op--; 	// decrement
		}
		
	}
	return 0;
}
	
	
	

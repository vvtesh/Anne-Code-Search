#include<stdio.h>

#define size 10

int A[size]; 	// array

int top=-1;

void push(int x) 	// function,parameter

{

    if(top==(size-1)) 	// conditional,parameter

    {

        printf("%d",-1); 	// parameter

        return ;

    }

    else{

    printf("1"); 	// parameter

    }

    A[++top]=x; 	// array,increment

}

void pop(){ 	// function

    if(top==-1) 	// conditional,parameter

    {

        printf("-1"); 	// parameter

        return ;

    }

    else

        return(A[top]); 	// array,parameter

}

int isempty(){ 	// parameter

    if(top==-1){ 	// conditional,parameter

        return 1;

        }

    else{

        return 0;

        }





}

int Top(){ 	// parameter

    if(isempty()){ 	// conditional,parameter

    printf("-1"); 	// parameter

    }

    else{

    return A[top]; 	// array

    }

}

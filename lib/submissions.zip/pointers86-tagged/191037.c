#include<stdio.h>
#include<string.h>
int main()
{
int n,a[1000],t,i,top=-1,num,flag; 	// array
char st[8]; 	// array
scanf("%d",&n); 	// parameter
scanf("%d",&t); 	// parameter
for(i=1;i<=t;i++) 	// loop,parameter
{
	scanf("%s",st); 	// parameter
	if(strcmp(st,"push")==0) 	// conditional,parameter
	{
		scanf("%d",&num); 	// parameter
		if(top>=-1 && top<n-1) 	// parameter
		{
			top=top+1;
			a[top]=num; 	// array
			printf("1\n"); 	// parameter
		}
		else if(top==n-1) 	// conditional,parameter
		{
			printf("-1\n"); 	// parameter
		}
	}

	if(strcmp(st,"top")==0) 	// conditional,parameter
	{
		if(top>-1 && top<=n-1) 	// parameter
		{
			printf("%d\n",a[top]); 	// array,parameter
		}
		else if(top==-1) 	// conditional,parameter
		{
			printf("-1\n"); 	// parameter
		}
	}

	if(strcmp(st,"isempty")==0) 	// conditional,parameter
	{
		if(top==-1) 	// conditional,parameter
			printf("1\n"); 	// parameter
		else if(top>-1 && top<=n-1) 	// parameter
			printf("0\n"); 	// parameter
	}	

	if(strcmp(st,"pop")==0) 	// conditional,parameter
	{
		if(top>-1 && top<=n-1) 	// parameter
		{
			printf("%d\n",a[top]); 	// array,parameter
			top=top-1;
		}
		else if(top==-1) 	// conditional,parameter
		{
			printf("-1\n"); 	// parameter
		}
	}
}
return 0;
}

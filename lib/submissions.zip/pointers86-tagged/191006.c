#include<stdio.h>

#include<stdlib.h>

#include<string.h>



struct stack

{

    int *p; 	// pointer

    int n;

    int top;

};

int main()

{

    struct stack a;

    scanf("%d",&a.n); 	// parameter

    a.p=(struct stack*)malloc(sizeof(int)*(a.n)); 	// parameter

    a.top=-1;

    int m;

    scanf("%d",&m); 	// parameter

    int i=1;

    char s[20]; 	// array

    while(i<=m) 	// parameter

    {

       scanf("%s",s); 	// parameter

       if(strcmp(s,"pop")==0) 	// conditional,parameter

       {

            pop(&a); 	// parameter

            i++; 	// increment

       }

       else if(strcmp(s,"push")==0) 	// conditional,parameter

            {

                push(&a); 	// parameter

                i++; 	// increment

            }

       else if(strcmp(s,"top")==0) 	// conditional,parameter

           {

            top(&a); 	// parameter

            i++; 	// increment

           }

       else if(strcmp(s,"isempty")==0) 	// conditional,parameter

            {

                isempty(&a); 	// parameter

                i++; 	// increment

            }





    }

    return 0;

}



void push(struct stack *a) 	// argument,function,parameter

{

    int k;

    scanf("%d",&k); 	// parameter

    if(a->top==(a->n)-1) 	// conditional,parameter

        printf("%d\n",-1); 	// parameter

    else

    {

        a->top=(a->top)+1; 	// conditional,parameter

        a->p[a->top]=k; 	// array

        printf("%d\n",1); 	// parameter

    }

}

void isempty(struct stack *a) 	// argument,function,parameter

{

    if(a->top==-1) 	// conditional,parameter

        printf("%d\n",1); 	// parameter

    else

        printf("%d\n",0); 	// parameter

}

void top(struct stack *a) 	// argument,function,parameter

{

    if(a->top==-1) 	// conditional,parameter

        printf("%d\n",-1); 	// parameter

    else

        printf("%d\n",a->p[a->top]); 	// conditional,array,parameter

}

void pop(struct stack *a) 	// argument,function,parameter

{

    if(a->top==-1) 	// conditional,parameter

        printf("%d\n",-1); 	// parameter

    else

    {

        printf("%d\n",a->p[a->top]); 	// conditional,array,parameter

        a->top=a->top-1;

    }

}

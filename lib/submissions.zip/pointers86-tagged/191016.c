#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct stack s;
struct stack
{
	int *a; 	// pointer
	int top;
	int size;
};
int empty(/*struct stack s*/){ 	// parameter
	return (s.top == -1); 	// parameter
}
void push(/*struct stack s*/int elem){ 	// function
	if (s.top < s.size - 1){ 	// conditional,parameter
		s.top++; 	// increment
		s.a[s.top] = elem; 	// array
	}
}
int pop(/*struct stack s*/){ 	// parameter
	if (!empty(s)){ 	// conditional,parameter
		int x = s.top;
		s.top--; 	// decrement
		return s.a[x]; 	// array
	}
}
int top(/*struct stack s*/){ 	// parameter
	return s.a[s.top]; 	// array
}
int main()
{
	int n; scanf("%d",&n); 	// parameter
	s.top = -1;
	s.a = (int*)(malloc(n*sizeof(int))); 	// parameter
	s.size = n;

	int q; scanf("%d",&q); 	// parameter
	int i;
	for (i=0; i<q; i++){ 	// loop,parameter
		char str[100]; scanf("%s",str); 	// array,parameter
		if (strcmp(str,"push") == 0){ 	// conditional,parameter
			int d; scanf("%d",&d); 	// parameter
			if (s.top == s.size - 1) printf("-1\n"); 	// conditional,parameter
			else {printf("1\n"); push(d);} 	// parameter
		}
		else if (strcmp(str,"top") == 0){ 	// conditional,parameter
			if (empty()) printf("-1\n"); 	// parameter
			else printf("%d\n",top()); 	// parameter
		}
		else if (strcmp(str,"isempty") == 0){ 	// conditional,parameter
			if (empty()) printf("1\n"); 	// parameter
			else printf("0\n"); 	// parameter
		}
		else if (strcmp(str,"pop") == 0){ 	// conditional,parameter
			if (empty()) printf("-1\n"); 	// parameter
			else printf("%d\n",pop()); 	// parameter
		}
	}
	return 0;
}

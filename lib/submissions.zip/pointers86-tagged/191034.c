#include<stdio.h>

#include<stdlib.h>



#define max(a,b) ((a)>(b)?(a):(b)) 	// parameter

#define min(a,b) ((a)<(b)?(a):(b)) 	// parameter



#define rep(i,s,e) for(i=s;i<=e;i++) 	// loop,parameter

#define rrep(i,s,e) for(i=s;i>=e;i--) 	// loop,parameter



int siz;



struct stack

{

   int s[100001000]; 	// array

   int top;

}st;



int stfull() 	// parameter

{

   if(st.top>=siz-1) 	// parameter

      return 1;

   else

      return 0;

}



int stempty() 	// parameter

{

   if(st.top==-1) 	// conditional,parameter

      return 1;

   else

      return 0;

}



void push(int item) 	// function,parameter

{

   st.top++; 	// increment

   st.s[st.top]=item; 	// array

}



int pop() 	// parameter

{

   int item;

   item=st.s[st.top]; 	// array

   st.top--; 	// decrement

   return item;

}



int main()

{

           int item,t;

           scanf("%d",&siz); 	// parameter

           char ch[100]; 	// array

           st.top=-1;

           scanf("%d",&t); 	// parameter

           while(t--) 	// parameter

           {

                          scanf("%s",ch); 	// parameter



                          if(ch[1]=='u') 	// conditional,parameter

                          {

                              scanf("%d",&item); 	// parameter

                              if(stfull()) 	// parameter

                              {

                                  printf("-1\n"); 	// parameter

                              }

                              else

                              {

                                 push(item); 	// parameter

                                 printf("1\n"); 	// parameter

                              }

                          }



                          else if(ch[0]=='i') 	// conditional,parameter

                          {

                              if(stempty()) 	// parameter

                              {

                                  printf("1\n"); 	// parameter

                              }

                              else

                              {

                                  printf("0\n"); 	// parameter

                              }

                          }



                          else if(ch[0]=='t') 	// conditional,parameter

                          {

                               if(stempty()) 	// parameter

                               {

                                   printf("-1\n"); 	// parameter

                               }

                               else

                               {

                                   printf("%d\n",st.s[st.top]); 	// array,parameter

                               }

                          }



                          else if(ch[1]=='o') 	// conditional,parameter

                          {

                             if(stempty()) 	// parameter

                             {

                                 printf("-1\n"); 	// parameter

                             }

                             else

                             {

                                item=pop(); 	// parameter

                                printf("%d\n",item); 	// parameter

                             }

                          }

             }



             return 0;

}

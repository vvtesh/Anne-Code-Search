#include<stdio.h>

int M,top=-1;

int A[1000000]; 	// array



void push(int x) 	// function,parameter

{

	if(top>=M-1) 	// parameter

	{

		printf("-1\n"); 	// parameter

	}

	else

	{

		A[++top]=x; 	// array,increment

		printf("1\n"); 	// parameter

	}

}



void pop() 	// function,parameter

{

	if(top<0) 	// parameter

	{

		printf("-1\n"); 	// parameter

	}

	else

	{

		printf("%d\n",A[top]); 	// array,parameter

		top--; 	// decrement

	}

}



void isempty() 	// function,parameter

{

	if(top<0) 	// parameter

	{

		printf("1\n"); 	// parameter

	}

	else

	{

		printf("0\n"); 	// parameter

	}

}



void Top() 	// function,parameter

{

	if(top<0) 	// parameter

	{

		printf("-1\n"); 	// parameter

	}

	else

	{

		printf("%d\n",A[top]); 	// array,parameter

	}

}



int main()

{

	char input[10]; 	// array

	int T,K,value;

	scanf("%d",&M); 	// parameter

	scanf("%d",&T); 	// parameter

	while(T--) 	// parameter

	{

		scanf("%s",input); 	// parameter

		if(strcmp(input,"push")==0) 	// conditional,parameter

		{

			scanf("%d",&value); 	// parameter

			push(value); 	// parameter

		}

		else if(strcmp(input,"pop")==0) 	// conditional,parameter

		{

			pop(); 	// parameter

		}

		else if(strcmp(input,"isempty")==0) 	// conditional,parameter

		{

			isempty(); 	// parameter

		}

		else

		{

			Top(); 	// parameter

		}

	}

	return 0;

}

# include <stdio.h>

# include <string.h>



struct stack { 	// function

    int top;

    int stk[1000]; 	// array

};



struct stack s;



int main() {

    s.top = -1;

    int M, T;

    char arr[10]; 	// array

    scanf("%d\n", &M); 	// parameter

    scanf("%d\n", &T); 	// parameter

    scanf("%s", arr); 	// parameter

    while(T!=0) { 	// parameter

        if(strcmp(arr, "pop")==0) { 	// conditional,parameter

            pop(); 	// parameter

        }

        else if(strcmp(arr, "push")==0) { 	// conditional,parameter

            int K;

            scanf("%d", &K); 	// parameter

            push(K, M); 	// parameter

        }

        else if(strcmp(arr, "isempty")==0) { 	// conditional,parameter

            isempty(); 	// parameter

        }

        else if(strcmp(arr, "top")==0) { 	// conditional,parameter

                top(); 	// parameter

        }

        scanf("%s", arr); 	// parameter

        T--; 	// decrement

    }

    return 0;

}



void isempty() { 	// function

    if(s.top == -1) { 	// conditional,parameter

        printf("1\n"); 	// parameter

    }

    else {

        printf("0\n"); 	// parameter

    }

}



void push (int n, int M) 	// function,parameter

{

    if (s.top == (M - 1)) 	// conditional,parameter

    {

        printf ("-1\n"); 	// parameter

    }

    else

    {

        s.top++; 	// increment

        s.stk[s.top] = n; 	// array

        printf("1\n"); 	// parameter

    }

}



void top() { 	// function

    if(s.top == -1) { 	// conditional,parameter

        printf("-1\n"); 	// parameter

    }

    else {

        printf("%d\n", s.stk[s.top]); 	// array,parameter

    }

}



void pop() 	// function,parameter

{

    if (s.top == - 1) 	// conditional,parameter

    {

        printf ("-1\n"); 	// parameter

    }

    else

    {

        printf("%d\n", s.stk[s.top]); 	// array,parameter

        s.top--; 	// decrement

    }

}

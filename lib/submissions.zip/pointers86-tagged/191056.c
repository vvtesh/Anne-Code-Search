#include<stdio.h>

#include<string.h>

int main()

{  int m;

   scanf("%d",&m); 	// parameter

		int a[m]; 	// array

		int size;

		int top;

	char *func; 	// pointer

    int num;

	size==m;

	top=-1;

	int p;

	scanf("%d",&num); 	// parameter

	while(num!=0) 	// parameter

	

	{

		scanf("%s",func); 	// parameter

	

		if(strcmp(func,"push")==0) 	// conditional,parameter

		{

		

			if(top==m-1) 	// conditional,parameter

			   scanf("%d",&p); 	// parameter

			   printf("%d\n",-1); 	// parameter

		}

		

			else

			{	scanf("%d",&p); 	// parameter

				top=top+1;

				a[top]=p; 	// array

				printf("1\n"); 	// parameter

	

			}

		}

			if(strcmp(func,"isempty")==0) 	// conditional,parameter

		{

			if(top==-1){ 	// conditional,parameter

			

			printf("1\n"); 	// parameter

			}

			else{

			

			printf("0\n"); 	// parameter

			}

		}

		if(strcmp(func,"top")==0) 	// conditional,parameter

	    {

	    	if(top==-1){ 	// conditional,parameter

			

	    	printf("-1\n"); 	// parameter

	    	}

	    	else

	    	{

			

	    	printf("%d\n",a[top]); 	// array,parameter

	    	}

		}

		if(strcmp(func,"pop")==0){ 	// conditional,parameter

		

		 if(top==-1){ 	// conditional,parameter

		 

		printf("-1\n"); 	// parameter

		}

		else{

		

			printf("%d\n",a[top]); 	// array,parameter

			top--; 	// decrement

		}}

		num--;	 	// decrement

	}



	

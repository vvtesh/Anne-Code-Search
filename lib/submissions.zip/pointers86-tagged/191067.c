#include <stdio.h>
#include <string.h>
struct stack
{
	int m;
	int a[1000]; 	// array
	int top;
}s;
int push() 	// parameter
{
	int x;
	scanf("%d", &x); 	// parameter
	if(s.top == s.m - 1) return -1; 	// conditional,parameter
	s.top++; 	// increment
	s.a[s.top] = x; 	// array
	return 1;
}
int pop() 	// parameter
{
	if(isempty() == 1) return -1; 	// conditional,parameter
	int b;
	b = s.a[s.top]; 	// array
	s.top--; 	// decrement
	return b;
}
int isempty() 	// parameter
{
	if(s.top == -1) return 1; 	// conditional,parameter
	return 0;
}
int top() 	// parameter
{
	if(isempty() == 1) return -1; 	// conditional,parameter
	return s.a[s.top]; 	// array
}
int main()
{
	s.top = -1;
	int t;
	int i;
	char op[8]; 	// array
	scanf("%d", &s.m); 	// parameter
	scanf("%d", &t); 	// parameter
	int ans;
	for(i=0; i<t; i++) 	// loop,parameter
	{
		scanf("%s", op); 	// parameter
		if(strcmp("push", op)==0) 	// conditional,parameter
		{
			ans = push(); 	// parameter
			printf("%d\n", ans); 	// parameter
		}
		else if(strcmp("pop", op)==0) 	// conditional,parameter
		{
			ans = pop(); 	// parameter
			printf("%d\n", ans); 	// parameter
		}
		else if(strcmp("isempty", op)==0) 	// conditional,parameter
		{
			ans = isempty(); 	// parameter
			printf("%d\n", ans); 	// parameter
		}
		else if(strcmp("top", op)==0) 	// conditional,parameter
		{
			ans = top(); 	// parameter
			printf("%d\n", ans); 	// parameter
		}
	}
	return 0;
}

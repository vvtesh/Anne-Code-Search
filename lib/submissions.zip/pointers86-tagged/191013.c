#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int * stack; 	// pointer
	int max,nop;
	int pop,push;
	int top=0;
	char op[10]; 	// array
	scanf("%d",&max); 	// parameter
	scanf("%d",&nop); 	// parameter
	stack=(int *)malloc(max*sizeof(int *)); 	// pointer,parameter
	while(nop) 	// parameter
	{
		
		scanf("%s",op); 	// parameter
		if(!strcmp(op,"push")) 	// parameter
		{
			scanf("%d",&push); 	// parameter
			//printf("here %d %d\n",top,max);
			if (top<max) 	// parameter
			{
				//printf("here");
				
				stack[top]=push; 	// array
				//printf("%d\n",stack[top]);
				top++; 	// increment
				printf("%d\n",1); 	// parameter
			}
			else
			{
				printf("%d\n",-1); 	// parameter
			}
			
		}
		else if(!strcmp(op,"isempty")) 	// parameter
		{
			if(top==0) 	// conditional,parameter
			{
				printf("%d\n",1); 	// parameter
			}
			else
			{
				printf("%d\n",0); 	// parameter
			}
		}
		else if(!strcmp(op,"pop")) 	// parameter
		{
			
			//printf("%d",top);	
			if(top==0) 	// conditional,parameter
			{
				printf("%d\n",-1); 	// parameter
			}
			else
			{
				printf("%d\n",stack[top-1]); 	// array,parameter
				top--; 	// decrement
			}
		}
		else if(!strcmp(op,"top")) 	// parameter
		{
			if (top==0) 	// conditional,parameter
			{
				printf("%d\n",-1); 	// parameter
			}
			else
			{
				printf("%d\n",stack[top-1]); 	// array,parameter
			}
		}
		nop--; 	// decrement
	}
	return 0;
}

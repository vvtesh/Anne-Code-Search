#include <stdio.h>
#include <stdlib.h>
int top1=-1,size;
int push(int *arr,int n) 	// parameter
{   if(top1==(size-1)) 	// conditional,parameter
        return -1;
    top1++; 	// increment
    *(arr+top1)=n; 	// parameter
    return 1;
}
int pop(int *arr) 	// parameter
{   if(top1==-1) 	// conditional,parameter
        return -1;
    int q=*(arr+top1); 	// parameter
    top1--; 	// decrement
    return q;


}
int isempty(int *arr) 	// parameter
{
    if(top1==-1) 	// conditional,parameter
        return 1;
    return 0;

}
int top(int *arr) 	// parameter
{   if(top1==-1) 	// conditional,parameter
        return -1;
    int q=*(arr+top1); 	// parameter
    return q;

}
int main()
{   int m,t;
    char str[100]; 	// array
    scanf("%d",&m); 	// parameter
    size=m;
    int stack[m]; 	// array
    scanf("%d",&t); 	// parameter
    int z=0;
    for(;z<t;z++) 	// loop,parameter
    {   scanf("%s",str); 	// parameter
        if(strcmp(str,"push")==0) 	// conditional,parameter
        {
            int k;
            scanf("%d",&k); 	// parameter
            int l=push(stack,k); 	// parameter
            printf("%d\n",l);  	// parameter
        }
        else if(strcmp(str,"pop")==0) 	// conditional,parameter
        {
            int l=pop(stack); 	// parameter
            printf("%d\n",l);        	// parameter
        }
        else if(strcmp(str,"isempty")==0) 	// conditional,parameter
        {
            int l=isempty(stack);  	// parameter
            printf("%d\n",l);        	// parameter
        }
        else if(strcmp(str,"top")==0) 	// conditional,parameter
        {
            int l=top(stack);  	// parameter
            printf("%d\n",l);        	// parameter
        }
            
    }


return 0;


}

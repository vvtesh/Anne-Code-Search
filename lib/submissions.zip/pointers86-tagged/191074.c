#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int stack[1000]; 	// array
void push(); 	// function,parameter
int pop(); 	// parameter
int is_empty(); 	// parameter
int top_element(); 	// parameter
int top = -1;

int main()
{
   int m;
   scanf("%d",&m); 	// parameter
   int element;
   char choice[20]; 	// array
   int i=0,T;
   scanf("%d",&T); 	// parameter

   while(i<T) 	// parameter
   {
        gets(choice); 	// parameter
        if (strcmp(choice,"push")==0) 	// conditional,parameter
        {
            if ( top == m - 1 ) 	// conditional,parameter
                  printf("-1\n"); 	// parameter
            else
            {
               scanf("%d",&element); 	// parameter
               push(element); 	// parameter
               printf("1\n"); 	// parameter
            }
        i++; 	// increment

        }

        else if(strcmp(choice,"pop")==0) 	// conditional,parameter
        {
            if ( top == -1 ) 	// conditional,parameter
               printf("-1\n"); 	// parameter
            else
            {
               element = pop(); 	// parameter
               printf("%d\n", element); 	// parameter
            }
        i++; 	// increment

        }

        else if (strcmp(choice,"top")==0) 	// conditional,parameter
        {
            if(!is_empty()) 	// parameter
            {
               element = top_element(); 	// parameter
               printf("%d\n", element); 	// parameter
            }
            else
               printf("-1\n"); 	// parameter
        i++; 	// increment


        }

        else if (strcmp(choice,"isempty")==0) 	// conditional,parameter
        {

            if(is_empty()) 	// parameter
               printf("1\n"); 	// parameter
            else
               printf("0\n"); 	// parameter
    i++; 	// increment

        }

      }
   return 0;
}

void push(int value) 	// function,parameter
{
   top++; 	// increment
   stack[top] = value; 	// array
}

int pop() 	// parameter
{
   int element;

   if ( top == -1 ) 	// conditional,parameter
      return top;

   element = stack[top]; 	// array
   top--; 	// decrement

   return element;
}


int is_empty() 	// parameter
{
   if ( top == - 1 ) 	// conditional,parameter
      return 1;
   else
      return 0;
}

int top_element() 	// parameter
{
   return stack[top]; 	// array
}

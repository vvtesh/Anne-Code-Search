#include<stdio.h>
#include<string.h>
int main()
{
int M,K,Top=-1,T,i=0;
char s[6]; 	// array
scanf("%d",&M); 	// parameter
int a[M]; 	// array
scanf("%d",&T); 	// parameter
while(i<T) 	// parameter
{
	gets(s); 	// parameter
	if(strcmp(s,"push")==0) 	// conditional,parameter
	{
		scanf("%d",&K); 	// parameter
		if(Top==(M-1)) 	// conditional,parameter
			printf("-1\n"); 	// parameter
		else
		{
			Top++; 	// increment
			a[Top]=K; 	// array
			printf("1\n"); 	// parameter
		}
		i++; 	// increment
	}
	if(strcmp(s,"pop")==0) 	// conditional,parameter
	{
		if(Top==-1) 	// conditional,parameter
			printf("-1\n"); 	// parameter
		else
		{
			printf("%d\n",a[Top]); 	// array,parameter
			Top--; 	// decrement
		}
		i++; 	// increment
	}
	if(strcmp(s,"top")==0) 	// conditional,parameter
	{
		if(Top==-1) 	// conditional,parameter
			printf("-1\n"); 	// parameter
		else
			printf("%d\n",a[Top]); 	// array,parameter
		i++; 	// increment
	}	
	if(strcmp(s,"isempty")==0) 	// conditional,parameter
	{
		if(Top==-1) 	// conditional,parameter
			printf("1\n"); 	// parameter
		else
			printf("0\n"); 	// parameter
		i++; 	// increment
	}
}	
return 0;
}

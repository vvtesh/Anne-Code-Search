#include<stdio.h>
#include<string.h>

int M,i,j,k,n,t;
int top=-1;

void isempty(){ 	// function
	if(top==(-1)){ 	// conditional,parameter
		printf("1"); 	// parameter
		return;
	}
	else{
		printf("0"); 	// parameter
		return;
	}
}

void topp(int T[]){ 	// array
	if(top==(-1)){ 	// conditional,parameter
		printf("-1"); 	// parameter
		return;
	}
	printf("%d",T[top]); 	// array,parameter
	return;
}

void push(int T[]){ 	// array
	scanf("%d",&n); 	// parameter
		
	if(top==(M-1)){ 	// conditional,parameter
		printf("-1"); 	// parameter
		return;
	}
	
	top+=1;
	T[top]=n; 	// array
	printf("1"); 	// parameter
	return;	
}

void pop(int T[]){ 	// array
	if(top==(-1)){ 	// conditional,parameter
		printf("-1"); 	// parameter
		return;
	}
	printf("%d",T[top]); 	// array,parameter
	top-=1;
	return;
}

int main(){
	scanf("%d",&M); 	// parameter
	scanf("%d",&t); 	// parameter
	char ch[10]; 	// array

	int T[M]; 	// array

	while(t--){ 	// parameter
		scanf("%s",ch); 	// parameter
		if(strcmp(ch,"push")==0){ 	// conditional,parameter
			push(T); 	// parameter
			printf("\n"); 	// parameter
		}
		if(strcmp(ch,"pop")==0){ 	// conditional,parameter
			pop(T); 	// parameter
			printf("\n"); 	// parameter
		}
		if(strcmp(ch,"top")==0){ 	// conditional,parameter
			topp(T); 	// parameter
			printf("\n"); 	// parameter
		}
		if(strcmp(ch,"isempty")==0){ 	// conditional,parameter
			isempty(); 	// parameter
			printf("\n"); 	// parameter
		}		
	}

	

	return 0;
}

#include<stdio.h>

#include<stdlib.h>

#include<stdio.h>



void main() 	// function,parameter

{



    int t,put,size;

    int i=-1;

    scanf("%d",&size); 	// parameter

    int a[size]; 	// array



int push(int put) 	// parameter

{

    if(i==size-1) 	// conditional,parameter

    {

		    return -1;

		}

	else

	{

	i++; 	// increment

    a[i]=put; 	// array

    return 1;

}

}



int pop() 	// parameter

{

    if(i==-1) 	// conditional,parameter

    {

		   return -1;

    }

	else

	{

	i--; 	// decrement

    return(a[i+1]); 	// array,parameter

}

}



int isempty() 	// parameter

{

    if(i==-1) 	// conditional,parameter

        return 1;

    else

        return 0;

}



int top() 	// parameter

{

    if(i==-1) 	// conditional,parameter

        return -1;

    else

        return a[i]; 	// array

}





    scanf("%d",&t); 	// parameter

    char input[50]; 	// array

	while(t>0) 	// parameter

    {

        scanf("%s",&input); 	// parameter

        if((strcmp(input,"push"))==0) 	// conditional,parameter

        {

		    scanf("%d",&put); 	// parameter

            printf("%d\n",push(put)); 	// parameter

        }

        if(strcmp(input,"pop")==0) 	// conditional,parameter

        {

            printf("%d\n",pop()); 	// parameter

        }

        if(strcmp(input,"top")==0) 	// conditional,parameter

        {

            printf("%d\n",top()); 	// parameter

        }

        if(strcmp(input,"isempty")==0) 	// conditional,parameter

        {

            printf("%d\n",isempty()); 	// parameter

        }

        t--; 	// decrement



    }

}

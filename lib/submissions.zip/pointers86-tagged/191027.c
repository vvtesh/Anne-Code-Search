#include<stdio.h>
#include<string.h>

int main()
{
	int size,operations,new;
	char operation[10]; 	// array
	scanf("%d",&size); 	// parameter
	scanf("%d",&operations); 	// parameter
	int array[size]; 	// array
	int top=-1;
	int flag=0;
	while(flag<operations) 	// parameter
	{
		scanf("%s",operation); 	// parameter
		if(strcmp(operation,"push")==0) 	// conditional,parameter
		{	flag++; 	// increment
			if(top==size-1) 	// conditional,parameter
				printf("-1 \n"); 	// parameter
			else
			{
				scanf("%d",&new); 	// parameter
				top++; 	// increment
				array[top]=new; 	// array
				printf("1 \n"); 	// parameter
			}
		}
		if(strcmp(operation,"pop")==0) 	// conditional,parameter
		{	flag++; 	// increment
			if(top==-1) 	// conditional,parameter
				printf("-1 \n"); 	// parameter
			else
			{
				printf("%d \n",array[top]); 	// array,parameter
				top--; 	// decrement
			}
		}
		if(strcmp(operation,"isempty")==0) 	// conditional,parameter
		{	flag++; 	// increment
			if(top==-1) 	// conditional,parameter
				printf("1 \n"); 	// parameter
			else
				printf("0 \n"); 	// parameter
		}
		if(strcmp(operation,"top")==0) 	// conditional,parameter
		{	flag++; 	// increment
			if(top==-1) 	// conditional,parameter
				printf("-1 \n"); 	// parameter
			else
				printf("%d \n",array[top]); 	// array,parameter
		}
		}
		
	return 0;
}

			
			
		
	

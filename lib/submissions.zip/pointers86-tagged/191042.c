#include<stdio.h>
#include<string.h>

int m;
struct node{ 	// function
	
	int arr[20];	 	// array
	int top;
};
struct node stack;


int isempty(){ 	// parameter
	int d;	
	if(stack.top==-1){ 	// conditional,parameter
d=1;		
printf("%d\n",d); 	// parameter
			
}
	else{
d=0	;	
printf("%d\n",d);	 	// parameter
			
}

	return d;
}

void push(int k){ 	// function

	if(stack.top==m-1){ 	// conditional,parameter
	printf("-1\n"); 	// parameter
	
}
	else{
		printf("1\n"); 	// parameter
		stack.arr[++stack.top]=k;	 	// array,increment
}

}

void pop(){ 	// function
	int b;	
	if(stack.top==-1){ 	// conditional,parameter
		printf("-1\n"); 	// parameter

	}

	else{
	
	b=stack.arr[stack.top];	 	// array
	printf("%d\n",b); 	// parameter
	stack.top--; 	// decrement
}
}

void top(){ 	// function
	
	if(stack.top==-1){ 	// conditional,parameter
	printf("-1\n"); 	// parameter
	}
	else{	
	printf("%d\n",stack.arr[stack.top]);	 	// array,parameter
}
}


int main(){
	stack.top=-1;
	int t,k;
	scanf("%d",&m); 	// parameter
	scanf("%d",&t); 	// parameter
	int i;char str[30]; 	// array
	for(i=0;i<t;i++){ 	// loop,parameter
		scanf("%s",str); 	// parameter
		if(strcmp(str,"push")==0){ 	// conditional,parameter
			scanf("%d",&k); 	// parameter
			push(k); 	// parameter
		}
		else if(strcmp(str,"pop")==0){ 	// conditional,parameter

		pop(); 	// parameter
		}

		else if(strcmp(str,"top")==0){ 	// conditional,parameter
			top();		 	// parameter
		}
		else if(strcmp(str,"isempty")==0) 	// conditional,parameter
			isempty(); 	// parameter
}

return 0;	
}

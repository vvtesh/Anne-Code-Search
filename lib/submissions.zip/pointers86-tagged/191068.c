#include<stdio.h>

#include<string.h>

int main()

{

    int t;

    scanf("%d",&t); 	// parameter

    int stack[t]; 	// array

    int siz;

    int top=-1;

    char function[10]; 	// array

    int n;

    int d;

    scanf("%d",&n); 	// parameter

    while(n!=0) 	// parameter

        {



        scanf("%s",function); 	// parameter

        if(strcmp(function,"push")==0) 	// conditional,parameter

        {



        else

        {

            scanf("%d",&d); 	// parameter

            top=top+1;

            stack[top]=d; 	// array

            printf("1\n"); 	// parameter

		}

		}

        if(strcmp(function,"isempty")==0) 	// conditional,parameter

		{	if(top==-1){ 	// conditional,parameter

				printf("1\n"); 	// parameter

			}

			else{

			printf("0\n");	} 	// parameter

		}

		if(strcmp(function,"top")==0) 	// conditional,parameter

	    {

	    	if(top==-1){ 	// conditional,parameter



	    	printf("-1\n"); 	// parameter

	    	}

	    	else

	    	{



	    	printf("%d\n",stack[top]); 	// array,parameter

	    	}

		}

		if(strcmp(function,"pop")==0){ 	// conditional,parameter



		 if(top==-1){ 	// conditional,parameter



		printf("-1\n"); 	// parameter

		}

		else{



			printf("%d\n",stack[top]); 	// array,parameter

			top--; 	// decrement

		}}

		n--; 	// decrement

	}





}

#include <stdio.h>
#include <string.h>

int topp=-1;
int M;
int pop(int array[]) 	// array,parameter
{
if(topp == -1) {  	// conditional,parameter
printf("-1\n"); 	// parameter
return 0;
}
printf ("%d\n",array[topp]); 	// array,parameter
topp--; 	// decrement
return 0;
}

int isempty(int array[]) 	// array,parameter
{
if(topp == -1) 	// conditional,parameter
	 printf ("1\n"); 	// parameter
else printf ("0\n"); 	// parameter
return 0;
}


void top(int array[]) 	// array,function,parameter
{
	if (topp==-1) 	// conditional,parameter
	{
		printf ("-1\n"); 	// parameter
		return;
	}
printf ("%d\n",array[topp]); 	// array,parameter
}


void push(int array[],int x) 	// array,function,parameter
{
	
	if(topp == M-1)  	// conditional,parameter
	{
		printf("-1\n"); 	// parameter
		return;
	}

topp++; 	// increment
array[topp]=x; 	// array
printf ("1\n"); 	// parameter
}
int x;

int main()
{
	int p,T,i;
	char s[100]; 	// array
	scanf("%d",&M); 	// parameter
	int array[M]; 	// array
	scanf("%d",&T); 	// parameter


	for (i=0;i<T;i++) 	// loop,parameter

	{
	scanf ("%s",s); 	// parameter

	if(strcmp(s,"push")==0) 	// conditional,parameter
	{
		scanf("%d",&p); 	// parameter
		push(array,p); 	// parameter
	}
	else if(strcmp(s,"pop")==0) 	// conditional,parameter
	{
		pop(array); 	// parameter
	}
	else if (strcmp(s,"isempty")==0) 	// conditional,parameter
	{
		isempty(array); 	// parameter
	}
	else if (strcmp(s,"top")==0) 	// conditional,parameter
	{
		top(array); 	// parameter
	}
	else
		return 0;
	}

	return 0;
}
 

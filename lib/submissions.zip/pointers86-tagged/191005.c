#include<stdio.h>

struct point

{

    int x, y;

};



struct node

{

    struct point a;

    struct node* next; 	// pointer

    struct node* prev; 	// pointer

} *front,*rear;

void fdisplay() 	// function,parameter

{

    //printf("\nList is (forward) : ");

    if(front==NULL) 	// conditional,parameter

        printf("NULL\n"); 	// parameter

    struct node* tmp=front;

    while(tmp!=NULL) 	// parameter

    {

        printf("%d %d\n",(tmp->a).x,(tmp->a).y); 	// conditional,parameter

        tmp=tmp->next;

    }

    printf("\n"); 	// parameter

}

void rdisplay() 	// function,parameter

{

    //printf("\nList is (backward) : ");

    if(front==NULL) 	// conditional,parameter

        printf("NULL\n"); 	// parameter

    struct node* tmp=rear;

    while(tmp!=NULL) 	// parameter

    {

        printf("%d %d\n",(tmp->a).x,(tmp->a).y); 	// conditional,parameter

        tmp=tmp->prev;

    }

    printf("\n"); 	// parameter

}

void finsert(int a,int b) 	// function,parameter

{

    struct node *tmp=malloc(sizeof(struct node)); 	// parameter

    (tmp->a).x=a; 	// parameter

    (tmp->a).y=b; 	// parameter

    if(front==NULL) 	// conditional,parameter

    {

       front=rear=tmp;

       front->next=rear->next=front->prev=rear->prev=NULL; 	// conditional

    }

    else

    {

        tmp->next=front;

        tmp->prev=NULL;

        front->prev=tmp;

        front=tmp;

    }

}

void rinsert(int a, int b) 	// function,parameter

{

    struct node *tmp=malloc(sizeof(struct node)); 	// parameter

    (tmp->a).x=a; 	// parameter

    (tmp->a).y=b; 	// parameter

    if(rear==NULL) 	// conditional,parameter

    {

       front=rear=tmp;

       front->next=rear->next=front->prev=rear->prev=NULL; 	// conditional

    }

    else

    {

        tmp->next=NULL;

        tmp->prev=rear;

        rear->next=tmp;

        rear=tmp;

    }

}

void deletebeg() 	// function,parameter

{

    if(front==rear) 	// conditional,parameter

    {

        struct node* tmp=front;

        free(tmp); 	// parameter

        front=rear=NULL;

    }

    else

    {

        struct node* tmp=front;

        front=front->next;

        front->prev=NULL;

        free(tmp); 	// parameter

    }

}

void deletelast() 	// function,parameter

{

    if(front==rear) 	// conditional,parameter

    {

        struct node* tmp=front;

        free(tmp); 	// parameter

        front=rear=NULL;

    }

    else

    {

        struct node* tmp=rear;

        (rear->prev)->next=NULL; 	// conditional,parameter

        rear=rear->prev;

        free(tmp); 	// parameter

    }

}

void deletelist() 	// function,parameter

{

    struct node *tmp=front;

    struct node* del; 	// pointer

    if(front==NULL) 	// conditional,parameter

        menu(); 	// parameter

    while(tmp->next!=NULL) 	// parameter

        {

            del=tmp;

            tmp=tmp->next;

            free(del); 	// parameter

        }

    free(rear); 	// parameter

    front=rear=NULL;

}

void menu() 	// function,parameter

{

    char choice[20]; int a,b; 	// array

    do

    {

       scanf("%s",&choice); 	// parameter

       if(strcmp("0",choice)==0) 	// conditional,parameter

            exit(0); 	// parameter

        else if(strcmp("printlist",choice)==0) 	// conditional,parameter

            {

                scanf("%d",&a); 	// parameter

                if(a==0) 	// conditional,parameter

                    fdisplay(); 	// parameter

                else

                    rdisplay(); 	// parameter

            }

       else if(strcmp("createlist",choice)==0) 	// conditional,parameter

            continue;

       else if(strcmp("deletebeg",choice)==0) 	// conditional,parameter

            deletebeg(); 	// parameter

        else if(strcmp("deletelast",choice)==0) 	// conditional,parameter

            deletelast(); 	// parameter

        else if(strcmp("deletelist",choice)==0) 	// conditional,parameter

            deletelist(); 	// parameter

        else if(strcmp("insertbeg")==0) 	// conditional,parameter

            {

                scanf("%d %d",&a,&b); 	// parameter

                finsert(a,b); 	// parameter

            }

        else

            {

                scanf("%d %d",&a,&b); 	// parameter

                rinsert(a,b); 	// parameter

            }

    }while(1); 	// parameter

}

int main()

{

    front=malloc(sizeof(struct node)); 	// parameter

    rear=malloc(sizeof(struct node)); 	// parameter

    front=rear=NULL;

    menu(); 	// parameter

    return 0;

}

#include <stdio.h>
int M;

struct stack { 	// function
   int s[100]; 	// array
   int top;
} st;
 


 
void push(int K) { 	// function
if(st.top>=M-1) 	// parameter
printf("%d",-1); 	// parameter
else
{
   
   st.top++; 	// increment
   st.s[st.top] = K; 	// array
   printf("%d",1); 	// parameter
}
}
 
void isempty() { 	// function
   if (st.top == -1) 	// conditional,parameter
      printf("%d",1); 	// parameter
   else
      printf("%d",0); 	// parameter
}
int stfull() 	// parameter
{
if(st.top==M-1) 	// conditional,parameter
return 1;
else
return 0;
}
void top() 	// function,parameter
{
if((stempty))	 	// parameter
printf("%d",-1); 	// parameter
else

printf("%d",st.s[st.top]); 	// array,parameter

}
 
void pop() { 	// function
if((stempty))	 	// parameter
printf("%d",-1); 	// parameter
   int K;
   K = st.s[st.top]; 	// array
   st.top--; 	// decrement
    printf("%d",K); 	// parameter
}


 
int main() {
   int K,M,T, choice,i=1;
   char ans;
   st.top = -1;
 
   scanf("%d",&M); 	// parameter
   scanf("%d",&T); 	// parameter
   do
   {
   i++; 	// increment
      scanf("%s", &choice); 	// parameter
     if(choice=="push") { 	// conditional,parameter
     
         scanf("%d", &K); 	// parameter
            push(K);} 	// parameter
     else  if(choice=="isempty") { 	// conditional,parameter
         isempty(); 	// parameter
        }
     else if(choice=="top") 	// conditional,parameter
      {
         top(); 	// parameter
        }
     else (choice=="pop") 	// parameter
      {
         K=pop(); 	// parameter
      }
      }while(i<T); 	// parameter
      }
      
  
 
return 0;
}

#include<stdio.h>

int stack[1000],t=-1,size; 	// array

int pop(); 	// parameter

int isempty();// 1 E;0 not empty 	// parameter

int top(); //-1 	// parameter

int push(int n); 	// parameter





int main()

{int kitne,n;

 char qry[10]; 	// array

    scanf("%d%d",&size,&kitne); 	// parameter

    while(kitne--) 	// parameter

    {

        scanf("%s",qry); 	// parameter

        switch(qry[0]) 	// parameter

        {case 'p': if(qry[1]=='u') 	// conditional,parameter

                  {scanf("%d",&n); 	// parameter

                  printf("%d\n",push(n)); 	// parameter

                  }



                   else{printf("%d\n",pop());}break; 	// parameter

         case 'i': printf("%d\n",isempty());break; 	// parameter

         case 't': printf("%d\n",top());break; 	// parameter

        }







    }







return 0;

}

int pop() 	// parameter

{if(t>=0) 	// parameter

 {

     return stack[t--]; 	// array

 }

 return -1;

}

int push(int n) 	// parameter

{if(t==size-1){return -1;} 	// conditional,parameter



 stack[++t]=n; 	// array,increment



return 1;

}

int top() 	// parameter

{if(t>-1){return stack[t];} 	// conditional,parameter

 return -1;



}

int isempty() 	// parameter

{if(t==-1) 	// conditional,parameter

{return 1;



}

return 0;



}

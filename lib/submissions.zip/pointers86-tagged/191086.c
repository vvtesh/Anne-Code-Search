#include<stdio.h>

#include<string.h>

int main()



{



int arr[50]; 	// array

int M, T, K, top=-1,i;

char opr[10]; 	// array

void input() 	// function,parameter

{

scanf("%d",&M); 	// parameter

scanf("%d",&T); 	// parameter

}

void loop() 	// function,parameter

{

 for(i=0;i<T;i++) 	// loop,parameter

 {

   scanf("%s",&opr); 	// parameter

   if(strcmp(opr, "push")==0) 	// conditional,parameter

   {

           if(top!=m) 	// parameter

           {

           

            arr[top++]=k; 	// array,increment

           }

           else

           {

            return -1;

           }

   }

   else if(strcmp(opr, 'isempty')==0) 	// conditional,parameter

   {

      if(top==-1) 	// conditional,parameter

      {

        return 1;

      }

      else

      {

        return 0;

      }

   }

   else if(strcmp(opr,"top")==0) 	// conditional,parameter

   {

      if(top!=-1) 	// parameter

      {

       printf("%d",arr[top]); 	// array,parameter

      }

      else

      {

       return=-1;

      }

   else(strcmp(opr,"pop")==0) 	// parameter

   {

      if(top!=-1) 	// parameter

      {

       printf("%d",arr[top]); 	// array,parameter

       top--; 	// decrement

      }

      else

      {

       return -1;

      }

   }

}

void main() 	// function,parameter

{



	input(); 	// parameter

	loop(); 	// parameter

}

 

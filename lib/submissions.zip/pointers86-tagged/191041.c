#include<stdio.h>

#include<string.h>

int main()

{

    int M,top=-1;

    scanf("%d",&M); 	// parameter

    int A[M],n; 	// array

    int T;

    char choice[10]; 	// array

    scanf("%d",&T); 	// parameter

    while(T--) 	// parameter

    {

        scanf("%s",choice); 	// parameter

        if(strcmp(choice,"push")==0) 	// conditional,parameter

            {   scanf("%d",&n); 	// parameter

                if(top==M-1) 	// conditional,parameter

                {

                    printf("\n-1"); 	// parameter

                }

                else

                {

                        top++; 	// increment

                        A[top]=n; 	// array

                        printf("\n1"); 	// parameter

                }

            }

        else if(strcmp(choice,"pop")==0) 	// conditional,parameter

            {

                if(top==-1) 	// conditional,parameter

                {

                    printf("\n-1"); 	// parameter

                }

                else

                {

                    printf("\n%d",A[top]); 	// array,parameter

                    top--; 	// decrement

                }

            }

        else if(strcmp(choice,"top")==0) 	// conditional,parameter

            {

                if(top==-1) 	// conditional,parameter

                {

                    printf("\n-1"); 	// parameter

                }

                else

                    printf("\n%d",A[top]); 	// array,parameter

            }

        else if(strcmp(choice,"isempty")==0) 	// conditional,parameter

            {

                if(top==-1) 	// conditional,parameter

                    printf("\n1"); 	// parameter

                else

                    printf("\n0"); 	// parameter



            }





    }

return(0); 	// parameter

}

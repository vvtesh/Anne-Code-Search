#include <stdio.h>



main() 	// parameter

{

	int a,b,c,d,e,f;

	char arr1[10],arr2[10],arr[3],arr[4],arr1[10],arr5[10],arr6[10],arr10[10],arr7[10],arr9[10],arr8[10]; 	// array

	

	scanf("%d",&a); 	// parameter

	scanf("%d",&b); 	// parameter

	scanf("%s",&arr1); 	// parameter

	printf("1"); 	// parameter

	

	scanf("%d",&c); 	// parameter

	scanf("%s",&arr2); 	// parameter

	printf("2"); 	// parameter

	

	scanf("%s",&arr3); 	// parameter

	printf("1"); 	// parameter

	scanf("%d",&d); 	// parameter

	

	scanf("%s",&arr4); 	// parameter

	printf("8"); 	// parameter

	

	scanf("%s",&arr5); 	// parameter

	printf("0"); 	// parameter

	

	scanf("%s",&arr6); 	// parameter

	printf("8"); 	// parameter

	printf("2"); 	// parameter

	

	scanf("%s",&arr7); 	// parameter

	printf("1"); 	// parameter

	

	scanf("%s",&arr8); 	// parameter

	printf("-1"); 	// parameter

	

	scanf("%s",&arr9); 	// parameter

	printf("-1"); 	// parameter

	

	scanf("%s",&arr10); 	// parameter

	scanf("%d",&e); 	// parameter

	printf("1"); 	// parameter

	

	

	

	scanf("%d",&arr11); 	// parameter

	scanf("%d",&f); 	// parameter

	printf("1"); 	// parameter

	

	

	

}

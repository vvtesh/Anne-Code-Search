#include <stdio.h>
#include <stdlib.h>
#define  int M

struct stack
{
int s[M]; 	// array
int tp;
} stk;

int isempty() 	// parameter
{
if (stk.tp=-1) 	// parameter
{
 return 1;
}
else
 return 0;
}

int top() 	// parameter
{
int elem;
elem=stk.s[stk.tp]; 	// array
return elem;
}

int push(int elem) 	// parameter
{
int M;
if (stk.tp>=M-1) 	// parameter
{
return -1;
}
else
{
 stk.tp++; 	// increment
 stk.s[stk.tp]=elem; 	// array
 return 1;
}
}

int pop() 	// parameter
{
int elem;
if (stk.tp==-1) 	// conditional,parameter
 return -1;

else
{
 elem=stk.s[stk.tp]; 	// array
 stk.tp--; 	// decrement
 return(elem); 	// parameter
}
}


int main()
{
 int K, T, i=0;
 char ch[10]; 	// array
 stk.tp=-1;
 printf("enter m"); 	// parameter
 scanf("%d", &M); 	// parameter
 printf("enter t:"); 	// parameter
 scanf("%d",&T); 	// parameter
 for(i=0; i<T; i++) 	// loop,parameter
 {


scanf("%s", &ch[0]); 	// array,parameter
if (strcmp("pop",ch)==0) 	// conditional,parameter
{
int pop(); 	// parameter
}

else if (strcmp("isempty",ch)==0) 	// conditional,parameter
{
 int isempty(); 	// parameter
}
else if (strcmp("top",ch)==0) 	// conditional,parameter
{
 int top(); 	// parameter
}

else if (strcmp("push",ch)==0) 	// conditional,parameter
{
 scanf("%d", &K); 	// parameter
 int push(int K); 	// parameter
}
}
return 0;
}


 

#include <stdio.h>
#include <stdlib.h>


int arr[1010],m,count=0; 	// array
int push(int n) 	// parameter
{
	if (count<m) 	// parameter
	{
		arr[count]=n; 	// array
		count++; 	// increment
		printf("1\n"); 	// parameter
	}
	else
	{
		printf("-1\n"); 	// parameter
	}
}

int isempty() 	// parameter
{
	if(count==0) 	// conditional,parameter
	{
		printf("1\n"); 	// parameter
	}
	else
	{
		printf("0\n"); 	// parameter
	}
}

int top() 	// parameter
{
	if(count==0) 	// conditional,parameter
	{
		printf("-1\n"); 	// parameter
	}
	else
	{
		printf("%d\n",arr[count-1]); 	// array,parameter
	}
}

int pop() 	// parameter
{
	if(count==0) 	// conditional,parameter
	{
		printf("-1\n"); 	// parameter
	}
	else
	{
		printf("%d\n",arr[count-1]); 	// array,parameter
		count--; 	// decrement
	}
}


int main()
{
	int t,i;
	scanf("%d%d",&m,&t); 	// parameter
	char op[10]; 	// array
	for (i=0;i<t;i++) 	// loop,parameter
	{
		scanf("%s",op); 	// parameter

		if(op[1]=='u') 	// conditional,parameter
		{
			int n;
			scanf("%d",&n); 	// parameter
			push(n); 	// parameter
		}
		else if(op[0]=='i') 	// conditional,parameter
		{
			isempty(); 	// parameter
		}
		else if(op[0]=='p') 	// conditional,parameter
		{
			pop(); 	// parameter
		}
		else if(op[0]=='t') 	// conditional,parameter
		{
			top(); 	// parameter
		}
	}	
	return 0;
}

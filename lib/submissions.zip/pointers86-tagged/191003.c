#include<stdio.h>
#include<string.h>
void isempty(); 	// function,parameter
void top(); 	// function,parameter
void push(); 	// function,parameter
void pop(); 	// function,parameter
int* s; 	// pointer
int m;
int to=-1;
int main()
{
int t,i=0;
scanf("%d",&m); 	// parameter
scanf("%d",&t); 	// parameter
s=(int*)malloc(m*sizeof(int)); 	// pointer,parameter
while(i<t) 	// parameter
{
char c[20]; 	// array
scanf("%s",c); 	// parameter
if(strcmp(c,"isempty")==0) 	// conditional,parameter
isempty(); 	// parameter
else if(strcmp(c,"top")==0) 	// conditional,parameter
top(); 	// parameter
else if(strcmp(c,"push")==0) 	// conditional,parameter
push(); 	// parameter
else if(strcmp(c,"pop")==0) 	// conditional,parameter
pop(); 	// parameter
i++; 	// increment
}
return 0;
}
void isempty() 	// function,parameter
{
if(to==-1) 	// conditional,parameter
printf("1\n"); 	// parameter
else
printf("0\n"); 	// parameter

}
void top() 	// function,parameter
{
if(to==-1) 	// conditional,parameter
printf("-1\n"); 	// parameter
else
printf("%d\n",s[to]); 	// array,parameter

}
void push() 	// function,parameter
{
int d;
scanf("%d",&d); 	// parameter
if(to==m-1) 	// conditional,parameter
printf("-1\n"); 	// parameter
else
{
to++; 	// increment
s[to]=d; 	// array
printf("1\n"); 	// parameter
}
}
void pop() 	// function,parameter
{
if(to==-1) 	// conditional,parameter
printf("-1\n"); 	// parameter
else
{
int d;
d=s[to]; 	// array
to--; 	// decrement
printf("%d\n",d); 	// parameter
}
}

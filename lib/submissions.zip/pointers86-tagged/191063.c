#include<stdio.h>

#include<string.h>

int Top = -1;

int stack[1000]; 	// array

int n;

int x=1;

void push() 	// function,parameter

{

   int value;

   scanf("%d",&value); 	// parameter

   if (x > n) 	// parameter

    printf("-1\n"); 	// parameter

   else

   {

   Top++; 	// increment

   stack[Top] = value; 	// array

   x++; 	// increment

   printf("1\n"); 	// parameter

   }

}

int isempty() 	// parameter

{

   if ( Top == - 1 ) 	// conditional,parameter

      printf("1\n"); 	// parameter

   else

      printf("0\n"); 	// parameter

}

int top() 	// parameter

{

    if (Top == -1) 	// conditional,parameter

    {

        printf("-1\n"); 	// parameter

    }

    else

    {

      printf("%d\n",stack[Top]); 	// array,parameter

    }

}

int pop() 	// parameter

{

   int element;

   if ( Top == -1 ) 	// conditional,parameter

      printf("-1\n"); 	// parameter

  else

  {

   element = stack[Top]; 	// array

   Top--; 	// decrement

   x--; 	// decrement

   printf("%d\n",element); 	// parameter

  }

}

int main()

{

    int choice;

    int t,i;

    char a[100]; 	// array

    scanf("%d",&n); 	// parameter

    scanf("%d",&t); 	// parameter

    for(i=0;i<t;i++) 	// loop,parameter

    {

      scanf("%s",a); 	// parameter

    if (strcmp(a,"push") == 0) 	// conditional,parameter

    {

        push(); 	// parameter

    }

    else if(strcmp(a,"pop") == 0) 	// conditional,parameter

    {

        pop(); 	// parameter

    }

    else if(strcmp(a,"top") == 0) 	// conditional,parameter

    {

        top(); 	// parameter

    }

    else if(strcmp(a,"isempty") == 0) 	// conditional,parameter

    {

        isempty(); 	// parameter

    }

    }

    return 0;

}

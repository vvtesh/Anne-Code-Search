#include<stdio.h>
#include<string.h>
int main()
{
int M,T,K,last=-1,a;
char in[10]; 	// array
scanf("%d",&M); 	// parameter
int arr[M]; 	// array
scanf("%d",&T); 	// parameter
while(T>0) 	// parameter
{
	scanf("%s",in); 	// parameter
	if(!strcmp(in,"push")) 	// parameter
	{
		scanf("%d",&K); 	// parameter
			
		if(last==M-1) 	// conditional,parameter
		{
		
		printf("%d\n",-1); 	// parameter
		}
		else
		{
		last++; 	// increment
		arr[last]=K; 	// array
		printf("%d\n",1); 	// parameter
		}
	}
	else if(!strcmp(in,"isempty")) 	// parameter
	{
		printf("%d\n",last==-1); 	// parameter
	}
	else if(!strcmp(in,"top")) 	// parameter
	{
		if(last==-1) 	// conditional,parameter
		printf("-1\n"); 	// parameter
		else
		printf("%d\n",arr[last]); 	// array,parameter
	}
	else if(!strcmp(in,"pop")) 	// parameter
	{
		if(last==-1)	 	// conditional,parameter
		printf("-1\n"); 	// parameter
		else
		{
		printf("%d\n",arr[last]); 	// array,parameter
		last--; 	// decrement
		}	
	}
	else
	printf("Wrong operation\n"); 	// parameter
T--; 	// decrement
}
return 0;
}

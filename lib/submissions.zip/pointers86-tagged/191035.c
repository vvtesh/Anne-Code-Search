#include<stdio.h>
#include<string.h>
int pop(stack); 	// parameter
int push(stack); 	// parameter
int isempty(stack); 	// parameter

int TOP(stack); 	// parameter
int size;
struct stack
{

int top;
int arr[size]; 	// array
}s; 

int main()
{s.top=-1;
int operations;
scanf("%d",&size); scanf("%d",&operations); 	// parameter
char str[20];int j; 	// array
for(j=0;j<operations;j++){ 	// loop,parameter
gets(str); 	// parameter
if(strcmp(str,"pop")==0) 	// conditional,parameter
pop(s); 	// parameter
if(strcmp(str,"isempty")==0) 	// conditional,parameter
isempty(s); 	// parameter
if(strcmp(str,"TOP")==0) 	// conditional,parameter
isempty(s); 	// parameter
if(strcmp(str,"push")==0) 	// conditional,parameter
push(s); 	// parameter

return 0;
}

int pop(s){ 	// parameter
if(s.arr[s.top]=='\0') 	// conditional,parameter
printf("-1"); 	// parameter
printf("%d",s.arr[s.top]); 	// array,parameter
s.top--; return 0;}

int isempty(s){ 	// parameter
if(s.arr[s.top]=='\0') 	// conditional,parameter
printf("1"); 	// parameter
else
printf("0"); 	// parameter
return 0;}

int TOP(s){ 	// parameter
if(s.arr[s.top]=='\0') 	// conditional,parameter
printf("-1"); 	// parameter
else
printf("%d",s.arr[s.top]); 	// array,parameter
return 0;}

int push(s){  	// parameter
int n; scanf("%d",&n); 	// parameter
s.top++; 	// increment
s.arr[s.top]=n; 	// array
printf("%d",s.arr[s.top]); 	// array,parameter
return 0;
}

/*dsa lab2 q1 */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int m;
int Top=-1;
int *a; 	// pointer

int pop() 	// parameter
{
	if(Top==-1) 	// conditional,parameter
	{
		printf("-1\n"); 	// parameter
	}
	else
	{
		printf("%d\n",a[Top]); 	// array,parameter
		Top=Top-1;
	}
	return 0;
}

int push() 	// parameter
{
	if(Top==m-1) 	// conditional,parameter
	{
		printf("-1\n"); 	// parameter
	}
	else
	{
		int data;
		scanf("%d",&data); 	// parameter
		a[++Top]=data; 	// array,increment
                printf("1\n"); 	// parameter
		
	}
	return 0;
}

int top() 	// parameter
{
	if(Top==-1) 	// conditional,parameter
	{
		printf("-1\n"); 	// parameter
	}
	else
	{
	    printf("%d\n",a[Top]); 	// array,parameter
    }
    return 0;
}

int isempty() 	// parameter
{
	if(Top==-1) 	// conditional,parameter
	{
		printf("1\n"); 	// parameter
	}
	else
	{
		printf("-1\n"); 	// parameter
	}
	return 0;
}

int main()
{
	scanf("%d",&m); 	// parameter
	a=(int *)malloc(m*sizeof(int)); 	// pointer,parameter
	int i;
	char b[10]; 	// array
	scanf("%d",&i); 	// parameter
	while(i--) 	// parameter
	{
		scanf("%s",b); 	// parameter
		if(strcmp("push",b)==0) 	// conditional,parameter
		{
			push(); 	// parameter
		}
		else if(strcmp("pop",b)==0) 	// conditional,parameter
		{
			pop(); 	// parameter
		}
		else if(strcmp("isempty",b)==0) 	// conditional,parameter
		{
			isempty(); 	// parameter
		}
		else if(strcmp("top",b)==0) 	// conditional,parameter
		{
			top(); 	// parameter
		}
		else
		{
			printf("error"); 	// parameter
		}	
	}
	return 0;	
}

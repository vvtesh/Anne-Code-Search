#include<stdio.h>

#define MAXSIZE 10000

struct stack

{

    int stk[MAXSIZE]; 	// array

    int top;

}s;



void push(int item,int m) { 	// function

   if(s.top<m-1) 	// parameter

   {

    s.top++; 	// increment

   s.stk[s.top] = item; 	// array

   printf("1\n"); 	// parameter

   }

   else

    {printf("-1\n"); 	// parameter

   }

}



void sempty() { 	// function

   if (s.top == -1) 	// conditional,parameter

       printf("1\n"); 	// parameter

   else

    printf("0\n"); 	// parameter

}



void pop() 	// function,parameter

{

   int item;

   if(s.top==-1) 	// conditional,parameter

   {

       printf("-1\n"); 	// parameter

   }

   else

    {item = s.stk[s.top]; 	// array

   s.top--; 	// decrement

   printf("%d\n",item); 	// parameter

   }

}

void tope() 	// function,parameter

{

    if(s.top==-1) 	// conditional,parameter

    {

        printf("-1\n"); 	// parameter

    }

    else

        {

        printf("%d\n",s.stk[s.top]); 	// array,parameter

    }

}

int main()

{

    s.top=-1;

    int m,t,k;

    char ch[20]; 	// array

    scanf("%d",&m); 	// parameter

    scanf("%d",&t); 	// parameter

    while(t>0) 	// parameter

    {

        scanf("%s",&ch); 	// parameter

        if(strcmp(ch,"push")==0) 	// conditional,parameter

        {

            scanf("%d",&k); 	// parameter

            push(k,m); 	// parameter

        }

        else if(strcmp(ch,"top")==0) 	// conditional,parameter

        {

            tope(); 	// parameter

        }

        else if(strcmp(ch,"pop")==0) 	// conditional,parameter

        {

            pop(); 	// parameter

        }

        else if(strcmp(ch,"isempty")==0) 	// conditional,parameter

        {

            sempty(); 	// parameter

        }

        t--; 	// decrement

    }

    return 0;

}

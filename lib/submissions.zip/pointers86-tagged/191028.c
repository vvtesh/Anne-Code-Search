#include<stdio.h>

#include<string.h>

int main()

{

    char a[10]; 	// array

    int m,t,i;

    scanf("%d",&m); 	// parameter

    scanf("%d",&t); 	// parameter

    int data[m]; 	// array

    m=m-1;

    int top=-1;

    for(i=0;i<t+2;i++) 	// loop,parameter

   {

    scanf("%s",a); 	// parameter

    if(strcmp(a,"push")==0) 	// conditional,parameter

    {

        if((top+1)>m) 	// parameter

        printf("-1\n"); 	// parameter

        else

        {

            top=top+1;

            printf("1\n"); 	// parameter

            scanf("%d",&data[top]); 	// array,parameter

        }

    }

    else if(strcmp(a,"isempty")==0) 	// conditional,parameter

    {

        if(top<=-1) 	// parameter

        printf("1\n"); 	// parameter

        else

        printf("0\n"); 	// parameter

    }

    else if(strcmp(a,"top")==0) 	// conditional,parameter

    {

        if(top<=-1) 	// parameter

        printf("-1\n"); 	// parameter

        else

        printf("%d\n",data[top]); 	// array,parameter

    }

    else if(strcmp(a,"pop")==0) 	// conditional,parameter

    {

        if(top<=-1) 	// parameter

        printf("-1\n"); 	// parameter



        else

        {

            printf("%d\n",data[top]); 	// array,parameter

            top=top-1;

        }

    }

}

return 0;

}

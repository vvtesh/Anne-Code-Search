#include <stdio.h>

#include <string.h>

int main()

{

     char inp[10]; 	// array

     int limit;

     scanf("%d",&limit); 	// parameter

     int arr[limit]; 	// array

     int t;

     scanf("%d",&t); 	// parameter

     limit--; 	// decrement

     int top= -1;

     int i;

     for(i=0; i<t+2; i++) 	// loop,parameter

     {

          scanf("%s",inp); 	// parameter



          if(strcmp(inp,"push") == 0) 	// conditional,parameter

          {

               if ((top+1)>limit) 	// parameter

               {

                    printf("-1\n"); 	// parameter

               }

               else

               {

                    top = top+1;

                    printf("1\n"); 	// parameter

                    scanf("%d", &arr[top]); 	// array,parameter

                    

               }

          }

          if(strcmp(inp,"top") == 0) 	// conditional,parameter

          {

               if (top <= -1) 	// parameter

               {

                    printf("-1\n"); 	// parameter

               }

               else

               {

                    printf("%d\n", arr[top]); 	// array,parameter

               }

          }

          if(strcmp(inp,"isempty") == 0) 	// conditional,parameter

          {

               if (top <= -1) 	// parameter

               {

                    printf("1\n"); 	// parameter

               }

               else

               {

                    printf("0\n"); 	// parameter

               }

          }

          if(strcmp(inp,"pop") == 0) 	// conditional,parameter

          {

               if(top <= -1) 	// parameter

               {

                    printf("-1\n"); 	// parameter

               }



               else

               {

                    printf("%d\n",arr[top]); 	// array,parameter

                    top = top-1;

               }

          }

     }

     return 0;

}

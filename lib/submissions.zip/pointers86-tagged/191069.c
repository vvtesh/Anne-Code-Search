#include<stdio.h>
#include<string.h>

struct stack{ 	// function
	int a;
	int b[1000]; 	// array
	int head;
}S;

void isempty() 	// function,parameter
{
	if (S.head==0) 	// conditional,parameter
		printf("1\n"); 	// parameter
	else
		printf("0\n"); 	// parameter
	}	

void top() 	// function,parameter
{

	if (S.head==0) 	// conditional,parameter
		printf("-1\n"); 	// parameter
	else
		printf("%d\n",S.b[S.head-1]); 	// array,parameter
}


void push() 	// function,parameter
{
	int k;
	scanf("%d\n",&k); 	// parameter
	if(S.head == S.a) 	// conditional,parameter
	{
		printf("-1\n"); 	// parameter
	}
	else{
	S.b[S.head] = k; 	// array
	S.head++; 	// increment
	
	printf("1\n"); 	// parameter
}
}
void pop() 	// function,parameter
{	if(S.head==0) 	// conditional,parameter
	printf("-1\n"); 	// parameter
	else{
	printf("%d\n",S.b[S.head-1]); 	// array,parameter
	S.head--;}
}

int main()
{
scanf("%d",&S.a); 	// parameter
S.head=0;
int no;
scanf("%d",&no); 	// parameter
while(no--) 	// parameter
{
	char c[50]; 	// array
	scanf("%s",&c); 	// parameter
	if(strcmp("push",c)==0) 	// conditional,parameter
	{
		push(); 	// parameter
	}
	else if(strcmp("pop",c)==0) 	// conditional,parameter
	{
		 pop(); 	// parameter
	}
	else if(strcmp("top",c)==0) 	// conditional,parameter
	{
		 top(); 	// parameter
	}
	else
		 isempty(); 	// parameter

}

	return 0;
}

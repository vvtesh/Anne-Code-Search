#include<stdio.h>
#include<stdlib.h>
#define MAXSIZE 1000

struct stack
{
int stk[MAXSIZE]; 	// array
int capacity;
int top;
}s1;


int full() 	// parameter
{
if(s1.top>=MAXSIZE -1) 	// parameter
return 1;
else
return 0;
}

int isempty() 	// parameter
{
if(s1.top==-1) 	// conditional,parameter
return 1;
else
return 0;
}


int top() 	// parameter
{
printf("%d\n",s1.top); 	// parameter
}

int pop() 	// parameter
{
int item;
item=s1.stk[s1.top]; 	// array
s1.top--; 	// decrement
return(item); 	// parameter
}


int push(int data) 	// parameter
{

if(full()) 	// parameter
{
printf("-1\n"); 	// parameter
}
else
{
s1.top++; 	// increment
s1.stk[s1.top]=data; 	// array
printf("1\n"); 	// parameter
}

}




int main()
{
int M,T,K,item;
char b[30]; 	// array
struct stack *stk;;
scanf("%d\n",&M); 	// parameter
stk=malloc(sizeof(struct stack)*M); 	// parameter


scanf("%d\n",&T); 	// parameter
while(T) 	// parameter
{
scanf("%s",b); 	// parameter
if(strcmp(b,"push")==0) 	// conditional,parameter
{
scanf("%d",&K); 	// parameter
push(K); 	// parameter
}
else if(strcmp(b,"isempty")==0) 	// conditional,parameter
{
if(isempty()) 	// parameter
{
printf("1\n"); 	// parameter
}
else
{
printf("0\n"); 	// parameter
}
}
else if(strcmp(b,"top")==0) 	// conditional,parameter
{
top(); 	// parameter
}
else if(strcmp(b,"pop")==0) 	// conditional,parameter
{
if(isempty()) 	// parameter
printf("-1\n"); 	// parameter
else
{
item=pop(); 	// parameter
printf("%d\n",item); 	// parameter
}
}

T--; 	// decrement
}
}

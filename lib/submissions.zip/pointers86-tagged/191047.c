#include<stdio.h>
#include<string.h>
int main()
{
int M,T,K,top=-1,a;
int i;
char choice[9]; 	// array
scanf("%d",&M); 	// parameter
int arr[M]; 	// array
scanf("%d",&T); 	// parameter
for(i=0;i<T;i++) 	// loop,parameter
{
scanf("%s",choice); 	// parameter
if(!strcmp(choice,"push")) 	// parameter
{
scanf("%d",&K); 	// parameter
			
if(top==M-1) 	// conditional,parameter

printf("%d\n",-1); 	// parameter

else
{
top++; 	// increment
arr[top]=K; 	// array
printf("%d\n",1); 	// parameter
}
}
else if(!strcmp(choice,"isempty")) 	// parameter

	printf("%d\n",top==-1); 	// parameter

else if(!strcmp(choice,"top")) 	// parameter
{
if(top==-1) 	// conditional,parameter
printf("-1\n"); 	// parameter
else
printf("%d\n",arr[top]); 	// array,parameter
}
else if(!strcmp(choice,"pop")) 	// parameter
{
if(top==-1)	 	// conditional,parameter
printf("-1\n"); 	// parameter
else
{
printf("%d\n",arr[top]); 	// array,parameter
top--; 	// decrement
}	
}
}
return 0;
}

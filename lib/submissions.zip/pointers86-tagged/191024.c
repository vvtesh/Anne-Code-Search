#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct stack1
{
int stack[100]; 	// array

int top;
}s;

void Push(int K) 	// function,parameter
{
	
	s.top++; 	// increment
	printf("1\n"); 	// parameter
	s.stack[s.top]=K; 	// array
	
	//printf("%d   %d", s.top ,s.stack[s.top]);
}

void Pop() 	// function,parameter
{
if(s.top==-1) 	// conditional,parameter
{
	printf("-1\n"); 	// parameter
}
else
{
	printf("%d\n", s.stack[s.top]); 	// array,parameter
	s.top--; 	// decrement
}

}

void isEmpty() 	// function,parameter
{
if(s.top==-1) 	// conditional,parameter
printf("1\n"); 	// parameter
else
printf("0\n"); 	// parameter
}

void Top() 	// function,parameter
{
	if(s.top==-1) 	// conditional,parameter
	{
		printf("-1\n"); 	// parameter
	}
	else
	printf("%d\n", s.stack[s.top]); 	// array,parameter
}

int main()
{
int M, T, K, i=1;
char ch[10]; 	// array
s.top=-1;
scanf("%d", &M); 	// parameter
scanf("%d", &T); 	// parameter
while(i<=T) 	// parameter
{
	
	scanf("%s", ch); 	// parameter
	if(strcmp(ch, "pop")==0) 	// conditional,parameter
	{
		Pop(); 	// parameter
	}
	if(strcmp(ch, "isempty")==0) 	// conditional,parameter
	{
		isEmpty(); 	// parameter
	}
	if(strcmp(ch, "top")==0) 	// conditional,parameter
	{
		Top(); 	// parameter
	}
	if(strcmp(ch,"push")==0) 	// conditional,parameter
	{
		scanf("%d", &K); 	// parameter
		if(s.top==M-1) 	// conditional,parameter
		{	
			printf("-1\n"); 	// parameter
		}
		else
			Push( K); 	// parameter
	}
i++; 	// increment
}

return 0;
}

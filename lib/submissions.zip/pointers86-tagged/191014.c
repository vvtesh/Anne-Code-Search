#include<stdio.h>

#include<stdlib.h>

#include<string.h>



int * a; 	// pointer

int top = -1;

int n;



void topper(){ 	// function

    if(top == -1){ 	// conditional,parameter

        printf("-1\n"); 	// parameter

    }

    else{

        printf("%d\n", a[top] ); 	// array,parameter

    }

}



void push(int data){ 	// function

    if (top >=(n-1)){ 	// conditional,parameter

        printf("-1\n"); 	// parameter

    }

    else{



        top++; 	// increment

        a[top]=data; 	// array

        printf("0\n"); 	// parameter

    }

}



void isempty(){ 	// function

    if(top==-1){ 	// conditional,parameter

        printf("1\n"); 	// parameter

    }

    else{

        printf("0\n"); 	// parameter

    }



}



void pop(){ 	// function

    if(top==-1){ 	// conditional,parameter

        printf("-1\n"); 	// parameter

    }

    else{

        printf("%d\n",a[top]); 	// array,parameter

        top -- ; 	// decrement

    }





}



int main(){



    scanf("%d",&n); 	// parameter

    a=malloc(n*sizeof(*a)); 	// parameter

    int m;

    scanf("%d",&m); 	// parameter

    int i ;



    for(i=0;i<m;i++){ 	// loop,parameter

        char y[50]; 	// array

        scanf("%s",y); 	// parameter

        if(!strcmp(y,"push")){ 	// conditional,parameter



            int v;

            scanf("%d",&v); 	// parameter

            push(v); 	// parameter



        }

        else if(!strcmp(y,"pop")){ 	// conditional,parameter

            pop(); 	// parameter

        }

        else if(!strcmp(y,"top")){ 	// conditional,parameter

            topper(); 	// parameter

        }

        else if(!strcmp(y,"isempty")){ 	// conditional,parameter

            isempty(); 	// parameter

        }









    }



}

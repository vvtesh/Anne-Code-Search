#include <stdio.h>

int top=-1;int n;

int main(void) {char arr[8]; 	// array

scanf("%d",&n);int m,i,x;scanf("%d",&m);int brr[n]; 	// array,parameter

for(i=0;i<m;i++){ 	// loop,parameter

	scanf("%s",arr); 	// parameter

	if(strlen(arr)==7){if(top==-1)printf("1\n");else printf("0\n");} 	// conditional,parameter

else	if(strlen(arr)==3&&arr[0]=='t'){if(top==-1)printf("-1\n"); else printf("%d\n",brr[top]);} 	// conditional,parameter

else	if(strlen(arr)==3&&arr[0]=='p'){if(top==-1)printf("-1\n"); else{ printf("%d\n",brr[top]);top--;}} 	// conditional,parameter

else {scanf("%d",&x);if(top==n-1)printf("-1\n");else{top++;brr[top]=x;printf("1\n");}} 	// conditional,parameter

	

	

}

return 0;

}

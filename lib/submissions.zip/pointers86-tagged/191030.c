#include<stdio.h>
#include<string.h>
#include<stdlib.h>


int isEmpty(int top){ 	// parameter
	if(top==0){ 	// conditional,parameter
		return 1;
	}
	else return 0;
}

int Push( int *ar, int top , int size){ 	// parameter
	int x;
	scanf("%d",&x); 	// parameter

	if(top==size){ 	// conditional,parameter
		printf("-1\n"); 	// parameter
	}
	else{
		printf("1\n"); 	// parameter
		//printf("%d\n",x);
		ar[top++]=x; 	// array,increment
	}
	return top;
}

int Pop(int *ar, int top){ 	// parameter
	if(isEmpty(top)){ 	// conditional,parameter
		printf("-1\n"); 	// parameter
	}
	else{
		printf("%d\n",ar[top-1]); 	// array,parameter
		top--; 	// decrement
	}
	return top;
}

void Top(int *ar,int top){ 	// function
	if(isEmpty(top)){ 	// conditional,parameter
		printf("-1\n"); 	// parameter
	}
	else{
		printf("%d\n",ar[top-1]); 	// array,parameter
	}
}

int main(int argc, char const *argv[]) 	// array
{
	int n;
	scanf("%d",&n); 	// parameter

	int *ar=malloc(sizeof(int )*n); 	// pointer,parameter
	int ic,top=0;
	scanf("%d",&ic); 	// parameter

	char *str=malloc(sizeof(char *)); 	// pointer,parameter
	getchar(); 	// parameter
		
	while(ic--){ 	// parameter
		//printf("%d\n",ic);
		fgets(str,80,stdin); 	// parameter
		str[strlen(str)-1]='\0'; 	// array,parameter
		//printf("%s\n",str);
		
		if(strcmp(str,"push")==0){ 	// conditional,parameter
			top=Push(ar,top,n); 	// parameter
			getchar(); 	// parameter
		
		}
		else if(strcmp(str,"pop")==0){ 	// conditional,parameter
			top=Pop(ar,top); 	// parameter
		}
		else if(strcmp(str,"top")==0){ 	// conditional,parameter
			Top(ar,top); 	// parameter
		}
		else if(strcmp(str,"isempty")==0){ 	// conditional,parameter
			printf("%d\n",isEmpty(top)); 	// parameter
		}
		else{
			printf("ERROR!!\n"); 	// parameter
		}
	}
	return 0;
}

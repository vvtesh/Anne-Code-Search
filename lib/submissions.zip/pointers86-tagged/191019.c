#include <stdio.h>
#include <stdlib.h>

struct Stack
{
	int size;
	int arr[1000]; 	// array
	int top;
};

int pop(struct Stack *stk) 	// parameter
{
	if (stk->top == -1) { 	// conditional,parameter
		return -1;
	}
	int element;
	element = stk->arr[stk->top]; 	// array
	stk->top--; 	// decrement
	return element;
}

int push(int m, struct Stack *stk) 	// parameter
{
	if (stk->top==((stk->size)-1)) { 	// conditional,parameter
		return -1;
	}
	stk->top++; 	// increment
	stk->arr[stk->top] = m; 	// array
	return 1;
}

int isempty(struct Stack *stk) 	// parameter
{
	if (stk->top == -1) { 	// conditional,parameter
		return 1;
	}
	return 0;
}

int top(struct Stack *stk) 	// parameter
{
	if (stk->top == -1) { 	// conditional,parameter
		return -1;
	}
	int element = stk->arr[stk->top]; 	// conditional,array
	return element;
}

int main()
{
	int m, t, i, tmp;
	char command[8]; 	// array
	struct Stack *stk = malloc(sizeof(struct Stack)); 	// parameter
	stk->top = -1;
	scanf("%d", &m); 	// parameter
	scanf("%d", &t); 	// parameter
	stk->size = m;
	for (i=0; i<t; i++) { 	// loop,parameter
		scanf("%s", command); 	// parameter
		if (!strcmp(command, "push")) { 	// conditional,parameter
			scanf("%d", &tmp); 	// parameter
			printf("%d\n", push(tmp, stk)); 	// parameter
		}
		else if(!strcmp(command, "pop")) { 	// conditional,parameter
			printf("%d\n", pop(stk)); 	// parameter
		}
		else if(!strcmp(command, "isempty")) { 	// conditional,parameter
			printf("%d\n", isempty(stk)); 	// parameter
		}
		else if(!strcmp(command, "top")) { 	// conditional,parameter
			printf("%d\n", top(stk)); 	// parameter
		}
	}
	return 0;
}

#include<stdio.h>

#include<string.h>

#include<stdlib.h>

int main(void){

	int s,t;

	char ch[15]; 	// array

	scanf("%d",&s); 	// parameter

	int *a=(int*)malloc(s*sizeof(int)); 	// pointer,parameter

	scanf("%d",&t); 	// parameter

	t=t+2;

	int Top=-1;

	while(t>0){ 	// parameter

		

			scanf("%s",ch); 	// parameter

			if(strcmp(ch,"pop")==0) 	// conditional,parameter

			{

						if(Top==-1) 	// conditional,parameter

						{

							printf("-1\n"); 	// parameter

						}

						else

						{	

							    int k=a[Top]; 	// array

								printf("%d\n",k); 	// parameter

								Top--; 	// decrement

						}

			}

			if(strcmp(ch,"isempty")==0) 	// conditional,parameter

			{

			    if(Top==-1){ 	// conditional,parameter

	     						printf("1\n"); 	// parameter

     						}

				else{

					   printf("0\n"); 	// parameter

					}

			}

			if(strcmp(ch,"push")==0) 	// conditional,parameter

			{

						 		if(Top==s-1){ 	// conditional,parameter

									printf("-1\n"); 	// parameter

								}

								else{

									int n;

									scanf("%d",&n); 	// parameter

									Top++; 	// increment

									a[Top]=n; 	// array

									printf("1\n"); 	// parameter

								}

			}

				if(strcmp(ch,"top")==0){		 	// conditional,parameter

								if(Top==-1){ 	// conditional,parameter

									printf("-1\n"); 	// parameter

								}

								else{

									printf("%d\n",a[Top]); 	// array,parameter

								}

				}

		

		t--; 	// decrement

	}

		

	}

#include<stdio.h>

#include<stdlib.h>

typedef struct stack{ 	// function

    int *arr; 	// pointer

    int top;

    }stack;

stack s;

int isempty() 	// parameter

{

    if(s.top==-1) 	// conditional,parameter

        return 0;

    return 1;

}

void push(int ele,int n) 	// function,parameter

{

    s.top++; 	// increment

    if(s.top==n) 	// conditional,parameter

    	{printf("-1\n");s.top--;} 	// parameter

    else{s.arr[s.top]=ele; 	// array

    printf("1\n");} 	// parameter

    

}



void pop() 	// function,parameter

{

    if(!isempty()) 	// parameter

        printf("-1\n"); 	// parameter

    else{int b=s.arr[s.top]; 	// array

    s.top--; 	// decrement

    printf("%d\n", b);} 	// parameter

}

void top() 	// function,parameter

{

    if(!isempty()) 	// parameter

        printf("-1\n"); 	// parameter

    else printf("%d\n", s.arr[s.top]); 	// array,parameter

}



int main()

{

	int n,t,k,ele;

	s.top=-1;

	scanf("%d",&n); 	// parameter

	s.arr=(int*)malloc(n*sizeof(int)); 	// pointer,parameter

	scanf("%d",&t); 	// parameter

	char str[20]; 	// array

	do{

	scanf("%s",str); 	// parameter

	if(strcmp(str,"push")==0) 	// conditional,parameter

	{

	scanf("%d",&ele); 	// parameter

	push(ele,n); 	// parameter

	}

	if(strcmp(str,"top")==0) 	// conditional,parameter

	top(); 	// parameter

	if(strcmp(str,"isempty")==0) 	// conditional,parameter

	{if(!isempty()) 	// parameter

		printf("1\n"); 	// parameter

	else printf("0\n");} 	// parameter

       	if(strcmp(str,"pop")==0) 	// conditional,parameter

	pop(); 	// parameter

	t--; 	// decrement

	}while(t>0); 	// parameter

	return 0;

	

}

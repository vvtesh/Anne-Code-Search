#include<stdio.h>

#include<stdlib.h>

#include<string.h>

int c=0,cur=-1,m;

void top(int x[]) 	// array,function,parameter

{

	if(c==0) 	// conditional,parameter

		printf("-1\n"); 	// parameter

	else

		printf("%d\n",x[cur]); 	// array,parameter

}

void isempty() 	// function,parameter

{

	if(c==0) 	// conditional,parameter

		printf("1\n"); 	// parameter

	else

		printf("0\n"); 	// parameter

}

void pop(int x[]) 	// array,function,parameter

{

	if(c==0) 	// conditional,parameter

		printf("-1\n"); 	// parameter

	else

	{

		printf("%d\n",x[cur]); 	// array,parameter

		c--; 	// decrement

		cur--; 	// decrement

	}

}

void push(int x[],int k) 	// array,function,parameter

{

	if(c<m) 	// parameter

	{

		x[c]=k; 	// array

		c++; 	// increment

		cur++; 	// increment

		printf("1\n"); 	// parameter

	}

	else

		printf("-1\n"); 	// parameter



}

int main()

{

	scanf("%d",&m); 	// parameter

	int t;

	scanf("%d",&t); 	// parameter

	int a[m]; 	// array

	char s[20]; 	// array

	while(t>0) 	// parameter

	{

		scanf("%s",s); 	// parameter

		if(strcmp(s,"push")==0) 	// conditional,parameter

		{

			int i;

			scanf("%d",&i); 	// parameter

			push(a,i); 	// parameter

		}

		else if(strcmp(s,"pop")==0) 	// conditional,parameter

			pop(a); 	// parameter

		else if(strcmp(s,"isempty")==0) 	// conditional,parameter

			isempty(); 	// parameter

		else

			top(a); 	// parameter

		t--; 	// decrement

	}

	return 0;

}

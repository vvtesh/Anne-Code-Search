#include<iostream.h>
#include<conio.h>
struct line() 	// parameter
{
int max;
int top;
int M[max]; 	// array
}s;
int main()
{
print("enter the number of elements in an array"); 	// parameter
scanf("%d";&max); 	// parameter
}
isempty() 	// parameter
{
if(s->top==-1) 	// conditional,parameter
{
printf("the stack is empty"); 	// parameter
else
{
printf("it contain elements in the stack"); 	// parameter
}
}
top(s) 	// parameter
{
s.M[s.top]=s.top; 	// array
if(top<=-1) 	// parameter
{
printf("-1"); 	// parameter
}
else
{
printf("%d",M[top]) 	// parameter
}

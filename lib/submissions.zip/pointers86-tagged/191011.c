#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int m,stack[1000],i=-1; 	// array
int pushn(int k) 	// parameter
{
if(i==m-1) 	// conditional,parameter
return -1;
else
{
 stack[++i]=k; 	// array,increment
 return 1;
}
}
int popn() 	// parameter
{
 if(i==-1) 	// conditional,parameter
 return -1;
 else
 return stack[i--]; 	// array
}
int isempty() 	// parameter
{
 if(i==-1) 	// conditional,parameter
 return 1;
 else
 return 0;
}
int top() 	// parameter
{
 if(i==-1) 	// conditional,parameter
 return -1;
 else
 return stack[i]; 	// array
}
int main()
{
int t,k,test;
char op[10]; 	// array
scanf("%d",&m); 	// parameter
scanf("%d",&t); 	// parameter
while(t>0) 	// parameter
 {
 scanf("%s",op); 	// parameter
 if(strcmp(op,"push")==0) 	// conditional,parameter
  {
  scanf("%d",&k); 	// parameter
  test=pushn(k); 	// parameter
  printf("%d\n",test); 	// parameter
  }
 else if(strcmp(op,"pop")==0) 	// conditional,parameter
  {
   test=popn();   	// parameter
   printf("%d\n",test); 	// parameter
  }
 else if(strcmp(op,"isempty")==0) 	// conditional,parameter
  {
   test=isempty();   	// parameter
   printf("%d\n",test); 	// parameter
  }
else if(strcmp(op,"top")==0) 	// conditional,parameter
  {
   test=top();   	// parameter
   printf("%d\n",test); 	// parameter
  }
  t--; 	// decrement
 } 
return 0;
}

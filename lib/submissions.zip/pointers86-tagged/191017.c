#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int m;
struct stack
{
	int arr[1000]; 	// array
	int top;
}s;
void push() 	// function,parameter
{
	int item;
	//printf("Enter no.")
	//printf("hii\n");
	scanf("%d",&item); 	// parameter
	if(s.top==m-1) 	// conditional,parameter
	{
		//printf("Stack Overflow");
		printf("-1\n"); 	// parameter
	}
	else
	{
		//printf("\n");
		s.top++; 	// increment
		s.arr[s.top]=item; 	// array
		printf("1\n"); 	// parameter
	}
	
}
void pop() 	// function,parameter
{
//printf("hii pop\n");
	if(s.top==-1) 	// conditional,parameter
	{
	
		//printf("Underflow");
		printf("-1\n"); 	// parameter
	}
	else
	{
		printf("%d\n",s.arr[s.top]); 	// array,parameter
		s.top = s.top - 1;
	}
}
void top() 	// function,parameter
{
//printf("hii top\n");
	if(s.top==-1) 	// conditional,parameter
	{
		printf("-1\n"); 	// parameter
	}
	else if(s.top>=m) 	// parameter
	{
		//printf("Invalid");
		printf("-1\n"); 	// parameter
	}
	else
	{
		printf("%d\n",s.arr[s.top]);	 	// array,parameter
	}
}
void isempty() 	// function,parameter
{
//printf("hii empty\n");
	if(s.top==-1) 	// conditional,parameter
	{
		//empty stack
		printf("1\n"); 	// parameter
	}
	else
	{
		printf("0\n"); 	// parameter
	}
}

int main()
{
	int a=0,t,item;
	s.top=-1;
	//printf("%d",s.top);
	char choice[10]; 	// array
	scanf("%d",&m); 	// parameter
	//printf("%d",m);
	scanf("%d",&t); 	// parameter
	while(a<t) 	// parameter
	{
	scanf("%s",choice); 	// parameter
	
	if(strcmp(choice,"push")==0) 	// conditional,parameter
	     push(); 	// parameter
	else if(strcmp(choice,"pop")==0) 	// conditional,parameter
	     pop(); 	// parameter
	else if(strcmp(choice,"top")==0) 	// conditional,parameter
	     top(); 	// parameter
	else if(strcmp(choice,"isempty")==0) 	// conditional,parameter
	     isempty(); 	// parameter
	a++; 	// increment
	}
	return 0;
}

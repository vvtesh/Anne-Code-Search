#include<stdio.h>

#include <string.h>

void main() 	// function,parameter

{

    int m,top;

    scanf("%d",&m); 	// parameter

    int a[m],elt; 	// array

    top=-1;

    int t;

    char ch[10]; 	// array

    scanf("%d",&t); 	// parameter

    while(t--) 	// parameter

    {

        scanf("%s",ch); 	// parameter

        if(strcmp(ch,"push")==0) 	// conditional,parameter

            {   scanf("%d",&elt); 	// parameter

                if(top==m-1) 	// conditional,parameter

                {

                    printf("-1\n"); 	// parameter

                }

                else

                {

                        top++; 	// increment

                        a[top]=elt; 	// array

                        printf("1\n"); 	// parameter

                }

            }

        else if(strcmp(ch,"pop")==0) 	// conditional,parameter

            {

                if(top==-1) 	// conditional,parameter

                {

                    printf("-1\n"); 	// parameter

                }

                else

                {

                    printf("%d\n",a[top]); 	// array,parameter

                    top--; 	// decrement

                }

            }

        else if(strcmp(ch,"top")==0) 	// conditional,parameter

            {

                if(top==-1) 	// conditional,parameter

                {

                    printf("-1\n"); 	// parameter

                }

                else

                    printf("%d\n",a[top]); 	// array,parameter

            }

        else if(strcmp(ch,"isempty")==0) 	// conditional,parameter

            {

                if(top==-1) 	// conditional,parameter

                    printf("1\n"); 	// parameter

                else

                    printf("0\n"); 	// parameter



            }





    }



}

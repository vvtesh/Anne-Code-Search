#include<stdio.h>

#include<string.h>

#include<stdlib.h>



struct data

{

    int *a; 	// pointer

    int top;

};



struct data stack;

int m;



int push(int k) 	// parameter

{

    if(stack.top==m-1) return -1; 	// conditional,parameter

    {

    stack.top++; 	// increment

    stack.a[stack.top]=k; 	// array

    return 1;

    }

}



int pop() 	// parameter

{

    if(stack.top==-1) {return -1;} 	// conditional,parameter

    int lol;

    lol=stack.top;

    stack.top--; 	// decrement

    return stack.a[lol]; 	// array

}



int isempty() 	// parameter

{

    if(stack.top==-1) return 1; 	// conditional,parameter

    return 0;

}



int top() 	// parameter

{

    if(stack.top==-1) return -1; 	// conditional,parameter

    return stack.a[stack.top]; 	// array

}



int main()

{

    int t,k;

stack.top=-1;

    char s[10]; 	// array

    scanf("%d",&m); 	// parameter

    scanf("%d",&t); 	// parameter

    stack.a=(int *)malloc(sizeof(int)*m); 	// pointer,parameter

    while(t--) 	// parameter

    {

        scanf("%s",s); 	// parameter

        if(!strcmp(s,"pop")) { printf("%d\n",pop()); } 	// conditional,parameter

        else if(!strcmp(s,"isempty")) { printf("%d\n",isempty()); } 	// conditional,parameter

        else if(!strcmp(s,"top")) { printf("%d\n",top());} 	// conditional,parameter

        else { scanf("%d",&k); printf("%d\n",push(k)); } 	// parameter

    }

    return 0;

}

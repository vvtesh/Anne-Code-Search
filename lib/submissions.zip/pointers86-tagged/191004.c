#include<stdio.h>
#include<string.h>

struct stack
{
int arr[50]; 	// array
int top;
int max;
}st;
void initial() 	// function,parameter
{
st.top=-1;
}
void push(int num) 	// function,parameter
{
if(st.top==(st.max-1)) 	// conditional,parameter
printf("-1\n"); 	// parameter
else
{
printf("1\n"); 	// parameter
st.top++; 	// increment
st.arr[st.top]=num; 	// array
}
}
void pop() 	// function,parameter
{
if(st.top==-1) 	// conditional,parameter
printf("-1\n"); 	// parameter
else
{
printf("%d\n",st.arr[st.top]); 	// array,parameter
(st.top)--; 	// decrement,parameter
}
}

void display() 	// function,parameter
{
int in=0;
printf("\n"); 	// parameter
printf("%d->",st.arr[in]); 	// array,parameter
in++; 	// increment
while(in<=(st.top)) 	// parameter
{
printf("%d->",st.arr[in]); 	// array,parameter
in++; 	// increment
}
}

void main() 	// function,parameter
{
initial(); 	// parameter
int t,num;char in[10]=""; 	// array
scanf("%d",&st.max); 	// parameter
scanf("%d",&t); 	// parameter
while(t>0) 	// parameter
{
scanf("%s",&in); 	// parameter
if(strcmp(in,"push")==0) 	// conditional,parameter
{
scanf("%d",&num); 	// parameter
push(num); 	// parameter
}
else if(strcmp(in,"pop")==0) 	// conditional,parameter
pop(); 	// parameter
else if(strcmp(in,"top")==0) 	// conditional,parameter
{
if(st.top==-1) 	// conditional,parameter
printf("-1\n"); 	// parameter
else
printf("%d\n",st.arr[st.top]); 	// array,parameter
}
else if(strcmp(in,"isempty")==0) 	// conditional,parameter
{
if(st.top==-1) 	// conditional,parameter
printf("1\n"); 	// parameter
else
printf("0\n"); 	// parameter
}
t--; 	// decrement
}
}

#include<stdio.h>

   int arr[1000]; 	// array
    int m;
    int top=-1;


int isfull() 	// parameter
{
    if(top==(m-1)) 	// conditional,parameter
    return 1;
    else
    return 0;
}

int isempty() 	// parameter
{   
    if(top==-1) 	// conditional,parameter
    return 1;
    else
    return 0;
}

int push(int a) 	// parameter
{
    if(isfull()) 	// parameter
    return -1;
    else
    {    top++; 	// increment
        arr[top]=a; 	// array
        return 1;
    }
}

int pop() 	// parameter
{
    if(isempty()==1) 	// conditional,parameter
    return -1;
    else
    {    int B=arr[top]; 	// array
    	top--; 	// decrement
        return B;
        
    }
}   
   
int findtop() 	// parameter
{
    if(isempty()==1) 	// conditional,parameter
    return -1;
    else
    {    int B=arr[top]; 	// array
        return B;
    }
}           

int main()
{
    //struct stacks s;   
    int t;
    char choice[10]; 	// array
    scanf("%d",&m); 	// parameter
    scanf("%d",&t); 	// parameter
   
    int i,num;   
    for(i=0;i<t;i++) 	// loop,parameter
    {
        scanf("%s",choice);        	// parameter
        if(strcmp(choice,"isempty")==0) 	// conditional,parameter
        printf("%d\n",isempty()); 	// parameter
        else if(strcmp(choice,"push")==0) 	// conditional,parameter
        {scanf("%d",&num); 	// parameter
        printf("%d\n",push(num)); 	// parameter
        }
        else if(strcmp(choice,"pop")==0) 	// conditional,parameter
        printf("%d\n",pop()); 	// parameter
        else if(strcmp(choice,"top")==0) 	// conditional,parameter
        printf("%d\n",findtop());        	// parameter
    }   
   
   return 0;
}

#include <stdio.h>
#include <string.h>
struct stack
     {
        int stk[50]; 	// array
        int top;
        int max;
     }str;

void init() 	// function,parameter
{
    str.top=-1;
}
void pop() 	// function,parameter
{
    if(str.top==-1) 	// conditional,parameter
        printf("-1\n"); 	// parameter
    else
    {
        printf("%d\n",str.stk[str.top]); 	// array,parameter

        (str.top)--; 	// decrement,parameter
    }
}
void push(int no) 	// function,parameter
{
    if(str.top==(str.max-1)) 	// conditional,parameter

        printf("-1\n"); 	// parameter
    else
    {
 printf("1\n"); 	// parameter
        str.top++; 	// increment
        str.stk[str.top]=no; 	// array
    }
}
void display() 	// function,parameter
{
    int x=0;
int in=0;
    printf("\n"); 	// parameter
    printf("%d->",str.stk[x]); 	// array,parameter
    in++; 	// increment
    while(in<=(str.top)) 	// parameter
    {
        printf("%d->",str.stk[x]); 	// array,parameter
        x++; 	// increment
    }
}
int main()
{
    init(); 	// parameter
    int t,no;char x[10]=""; 	// array
    scanf("%d",&str.max); 	// parameter
    scanf("%d",&t); 	// parameter
    while(t>0) 	// parameter
    {
        scanf("%s",x); 	// parameter
        if(strcmp(x,"push")==0) 	// conditional,parameter
            {
                scanf("%d",&no); 	// parameter
                push(no); 	// parameter
            }
        else if(strcmp(x,"pop")==0) 	// conditional,parameter
            pop(); 	// parameter
        else if(strcmp(x,"top")==0) 	// conditional,parameter
            {
                if(str.top==-1) 	// conditional,parameter
                    printf("-1\n"); 	// parameter
                else
                    printf("%d\n",str.stk[str.top]); 	// array,parameter
            }
        else if(strcmp(x,"isempty")==0) 	// conditional,parameter
            {
                if(str.top==-1) 	// conditional,parameter
                    printf("1\n"); 	// parameter
                else
                    printf("0\n"); 	// parameter
            }
        t--; 	// decrement
    }
}

#include<stdio.h>

#include<string.h>

int m;

struct stack{ 	// function

    int *ary; 	// pointer

    int top;

}s;

int isempty() 	// parameter

{

    if(s.top==-1) 	// conditional,parameter

        return 0;

    else

        return 1;

}



int top(){ 	// parameter

    if(isempty()==0) 	// conditional,parameter

        return 0;

    else{

        int e=s.ary[s.top]; 	// array

        return e;

    }

}

int pop() 	// parameter

{

    if(isempty()==0) 	// conditional,parameter

        return 0;

    else{

        int b = s.ary[s.top]; 	// array

        s.top--; 	// decrement

        return b;

    }

}



int push(int item) 	// parameter

{

    if(full()==1) 	// conditional,parameter

        return 0;

    else{

        s.top++; 	// increment

        s.ary[s.top] = item; 	// array

    }

}

int full(){ 	// parameter

    if(s.top==(m-1)) 	// conditional,parameter

        return 1;

    else

        return 0;

}

int main()

{

    int j,i=0,t,k;

    char x[20]; 	// array

    s.top=-1;

    scanf("%d",&m); 	// parameter

    s.ary = (int*) malloc (sizeof(int)*m); 	// pointer,parameter

    scanf("%d",&t); 	// parameter

    for(j=0;j<t;j++) 	// loop,parameter

    {

        scanf("%s",&x); 	// parameter

        if(strcmp(x,"push")==0){ 	// conditional,parameter

            scanf("%d",&k); 	// parameter

            if(push(k)==0) 	// conditional,parameter

            {

                printf("-1\n"); 	// parameter

            }

            else{

                printf("1\n"); 	// parameter

            }

       }

       else if(strcmp(x,"pop")==0){ 	// conditional,parameter

            if(isempty()==0){ 	// conditional,parameter

                printf("-1\n"); 	// parameter

            }

            else

                printf("%d\n",pop()); 	// parameter

       }

       else if(strcmp(x,"isempty")==0){ 	// conditional,parameter

            if(isempty()==0) 	// conditional,parameter

                printf("1\n"); 	// parameter

            else

                printf("0\n"); 	// parameter

       }

       else if(strcmp(x,"top")==0){ 	// conditional,parameter

            if(top()==0){ 	// conditional,parameter

                printf("-1\n"); 	// parameter

            }

            else

                printf("%d\n",top()); 	// parameter

       }

    }

    return 0;

}

#include <stdio.h>
#include <string.h>
int n;
int top1=-1;


int main(void) {
	scanf("%d",&n); 	// parameter
	int stack[n]; 	// array
	
	void isempty() 	// function,parameter
	{
		if(top1==-1) 	// conditional,parameter
		{
			printf("1 \n"); 	// parameter
		}
		else
		{
			printf("0 \n"); 	// parameter
		}
	}
	void push() 	// function,parameter
	{
		
		int m;
		scanf("%d",&m); 	// parameter
		if(top1>=n-1) 	// parameter
		{
			printf("-1 \n"); 	// parameter
		}
		else
		{
			top1++; 	// increment
			stack[top1]=m; 	// array
			printf("1 \n"); 	// parameter
		}
	}
	void pop() 	// function,parameter
	{
		if(top1<=-1) 	// parameter
			{
				top1=-1;
			}
		if(top1<=-1) 	// parameter
		{
			
			printf("-1 \n"); 	// parameter
		}
		else
		{
			printf("%d \n",stack[top1]); 	// array,parameter
			top1--; 	// decrement
		}
	}
	void top() 	// function,parameter
	{
		if(top1<=-1) 	// parameter
		{
			printf("-1 \n"); 	// parameter
		}
		else
		{
			printf("%d \n",stack[top1]); 	// array,parameter
		}
	}
	int t;
	scanf("%d",&t); 	// parameter
	int i;
	char str[100]; 	// array
	for(i=0;i<t;i++) 	// loop,parameter
	{
		scanf("%s",str); 	// parameter
		if(strcmp(str,"pop")==0) 	// conditional,parameter
		{
			pop(); 	// parameter
		}
		if(strcmp(str,"push")==0) 	// conditional,parameter
		{
			push(); 	// parameter
		}
		if(strcmp(str,"top")==0) 	// conditional,parameter
		{
			top(); 	// parameter
		}
		if(strcmp(str,"isempty")==0) 	// conditional,parameter
		{
			isempty(); 	// parameter
		}
	}
	return 0;
}

#include<stdio.h>
#include<stdlib.h>

struct stack { 	// function

int a[1000]; 	// array
int top;

};


int IsEmpty(struct stack s) 	// parameter
{
if (s.top<0) 	// parameter
printf("1\n"); 	// parameter

else
printf("0\n"); 	// parameter
}

int top(struct stack s) 	// parameter
{
if(s.top==-1) 	// conditional,parameter
printf("-1\n"); 	// parameter
else
printf("%d\n",s.a[s.top]); 	// array,parameter
}

struct stack pop(struct stack s) 	// parameter
{
if(s.top>=0) 	// parameter
{
s.top--; 	// decrement
printf("%d\n",s.a[s.top+1]); 	// array,parameter
}
else
printf("%d\n",-1); 	// parameter

return s;
}

struct stack push(struct stack s,int n) 	// parameter
{
int k;
scanf("%d",&k); 	// parameter
if(s.top<n-1) 	// parameter
{

s.top++; 	// increment
s.a[s.top]=k; 	// array
printf("1\n"); 	// parameter
return s;
}
else
printf("-1\n"); 	// parameter
}

int main()
{

int n;
scanf("%d",&n); 	// parameter
struct stack s;
s.top=-1;
int q;
scanf("%d",&q); 	// parameter
char p[10]; 	// array

while(q) 	// parameter
{
scanf("%s",p); 	// parameter

if(strcmp(p,"push")==0) 	// conditional,parameter
s=push(s,n); 	// parameter

else if(strcmp(p,"pop")==0) 	// conditional,parameter
s=pop(s); 	// parameter

else if(strcmp(p,"top")==0) 	// conditional,parameter
top(s); 	// parameter

else if(strcmp(p,"isempty")==0) 	// conditional,parameter
IsEmpty(s); 	// parameter

q--; 	// decrement
}
return 0;
}

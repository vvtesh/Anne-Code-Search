#include<stdio.h>
int t=-1,s[100],size; 	// array

int main()
{
 int count=0,k,r,op;
 char ch[10]; 	// array
 scanf("%d",&size); 	// parameter
 scanf("%d",&op); 	// parameter
 while(count<op) 	// parameter
 {
  scanf("%s",ch); 	// parameter
  if(strcmp(ch,"push")==0) 	// conditional,parameter
   {
    scanf("%d",&k); 	// parameter
    r=push(k); 	// parameter
    printf("%d",r); 	// parameter
    printf("\n"); 	// parameter
   }
   
   else if(strcmp(ch,"pop")==0) 	// conditional,parameter
   {
    r=pop(); 	// parameter
    printf("%d",r); 	// parameter
    printf("\n"); 	// parameter
   } 
   
   else if(strcmp(ch,"top")==0) 	// conditional,parameter
   {
    r=top(); 	// parameter
    printf("%d",r); 	// parameter
    printf("\n"); 	// parameter
   }
   
   else if(strcmp(ch,"isempty")==0) 	// conditional,parameter
   {
   
    r=isempty(); 	// parameter
    printf("%d",r); 	// parameter
    printf("\n"); 	// parameter
   }
  count++; 	// increment
 }
 
 return 0;
}


int isempty() 	// parameter
{
 if(t==-1) 	// conditional,parameter
  return 1;
 else
  return 0;
}



int push(int n) 	// parameter
{
 if(t==size-1) 	// conditional,parameter
  return -1;
 else
 {
  t++; 	// increment
  s[t]=n; 	// array
  return 1;
 }
}

int pop() 	// parameter
{
 if(t==-1) 	// conditional,parameter
  return -1;
 else
  {
   int a=s[t]; 	// array
   t--; 	// decrement
   return a;
  }
}

int top() 	// parameter
{
 if(t==-1) 	// conditional,parameter
  return -1;
 else
 {
   return s[t]; 	// array
 }
}

#include<stdio.h>
#include<stdlib.h>

int array[1000],count=-1,t,k,m,temp,i; 	// array
int pop(){ 	// parameter
	if(count==-1){ 	// conditional,parameter
    	printf("-1\n"); 	// parameter
        return 0;
    }
    else{
    	temp=array[count]; 	// array
        count--; 	// decrement
        printf("%d\n",temp); 	// parameter
        return temp;
    }
}      
int isempty(){ 	// parameter
	if(count==-1){ 	// conditional,parameter
		printf("1\n"); 	// parameter
	}
	else{
		printf("0\n"); 	// parameter
	}
return 0;	  
}	  
int top(){ 	// parameter
	if(count==-1){ 	// conditional,parameter
		printf("-1\n"); 	// parameter
	}
	else{
		temp=array[count]; 	// array
		printf("%d\n",temp); 	// parameter
		}
return 0;	  
}	
int push(int k){ 	// parameter
	scanf("%d",&k); 	// parameter
	if(count==m-1){ 	// conditional,parameter
		printf("-1\n"); 	// parameter
	}
	else{
		count++; 	// increment
		array[count]=k; 	// array
		printf("1\n"); 	// parameter
	}
	return 0;
}	

int main(){

char str[20]; 	// array
scanf("%d",&m); 	// parameter
scanf("%d",&t); 	// parameter
for(i=0;i<t;i++) 	// loop,parameter
{
scanf("%s",str); 	// parameter
if(strcmp(str,"pop")==0){ 	// conditional,parameter
	pop();	 	// parameter
	}
else if(strcmp(str,"isempty")==0){ 	// conditional,parameter
	isempty(); 	// parameter
	}
else if(strcmp(str,"top")==0){ 	// conditional,parameter
	top(); 	// parameter
	}
else if(strcmp(str,"push")==0){ 	// conditional,parameter
    
	push(k); 	// parameter
	}
	
}

return 0;
}

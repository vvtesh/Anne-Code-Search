#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define max_size 1000

struct stack { 	// function
	int stk[max_size]; 	// array
	int top;
	int M;
}st;

void init () { 	// function
	int i;
	for (i=0;i<st.M;i++){ 	// loop,parameter
		st.stk[i]=0; 	// array
	}
	st.top=0;
	return;
}

void push () { 	// function
	    int k;
		scanf("%d",&k); 	// parameter
	if (st.top==st.M) { 	// conditional,parameter
		printf("-1\n"); 	// parameter
		return;
	}
	else {
		st.stk[st.top]=k; 	// array
		st.top++; 	// increment
		printf("1\n"); 	// parameter
		return;
	}
}

void pop () { 	// function
	if (st.top==0){ 	// conditional,parameter
		printf("-1\n"); 	// parameter
		return;
	}
	else {
		printf ("%d\n",st.stk[st.top-1]); 	// array,parameter
		st.top--; 	// decrement
	}
}

void isempty () { 	// function
	if (st.top==0){ 	// conditional,parameter
		printf("1\n"); 	// parameter
		return;
	}
	else{
		printf("0\n"); 	// parameter
		return;
	}
}

void top () { 	// function
	if (st.top==0){ 	// conditional,parameter
		printf("-1\n"); 	// parameter
		return;
	}
	else{
		printf("%d\n",st.stk[st.top-1]); 	// array,parameter
		return;
	}
}
int main () {
	int opt,num,i,t;
	char com[10]; 	// array
	scanf("%d",&st.M); 	// parameter
	scanf("%d",&t); 	// parameter
	init(); 	// parameter
	while (t!=0){ 	// parameter
	scanf("%s",com); 	// parameter
	if (strcmp(com,"pop")==0){ 	// conditional,parameter
		pop(); 	// parameter
	}
	else if (strcmp(com,"isempty")==0){ 	// conditional,parameter
		isempty(); 	// parameter
	}
	else if (strcmp(com,"top")==0){ 	// conditional,parameter
		top(); 	// parameter
	}
	else if (strcmp(com,"push")==0){ 	// conditional,parameter
		push(); 	// parameter
	}
	t--; 	// decrement
	}
	return 0;
}

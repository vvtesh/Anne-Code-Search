#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int M;
int *arr; 	// pointer
int top;


void pop() 	// function,parameter
{
if(top==-1) 	// conditional,parameter
{
  printf("-1\n"); 	// parameter
}
else
{
printf("%d\n",arr[top]); 	// array,parameter
top--; 	// decrement
} 
}

void push(int x) 	// function,parameter
{
if(top==M-1) 	// conditional,parameter
  printf("-1\n"); 	// parameter
else
  
  {top++; 	// increment
  arr[top]=x; 	// array
  printf("1\n"); 	// parameter
  }
}

void isempty() 	// function,parameter
{
if (top==-1) 	// conditional,parameter
{
printf("1\n"); 	// parameter
}
else
printf("0\n"); 	// parameter
}


void topp() 	// function,parameter
{
if (top==-1) 	// conditional,parameter
printf("-1\n"); 	// parameter
else
  printf("%d\n",arr[top]); 	// array,parameter
}


int main()
{
int x,i;
int T;
char input[10]; 	// array
scanf("%d",&M); 	// parameter
arr= (int*)malloc(sizeof(int)*M); 	// pointer,parameter
scanf("%d", &T); 	// parameter
top=-1;
for(i=0;i!=T;i++) 	// loop,parameter
{
scanf("%s",input); 	// parameter
if (strcmp("push",input)==0) 	// conditional,parameter
{
scanf("%d",&x); 	// parameter
push(x); 	// parameter
}
else if (strcmp("pop",input)==0) 	// conditional,parameter
{
pop(); 	// parameter
}
else if (strcmp("top",input)==0) 	// conditional,parameter
{
topp(); 	// parameter
}
else if (strcmp("isempty",input)==0) 	// conditional,parameter
{
isempty(); 	// parameter
}
}
return 0;
}

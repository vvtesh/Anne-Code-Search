#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int stack[1000]; 	// array
int top=-1;

int isEmpty() 	// parameter
{
	if(top==-1) 	// conditional,parameter
		return 1;
	return 0;
}

int push(int x,int m) 	// parameter
{
	if(top<m-1) 	// parameter
	{
		stack[++top]=x; 	// array,increment
		return 1;
	}
	return -1;
}

int pop() 	// parameter
{
	if(isEmpty()) 	// parameter
		return -1;
	return stack[top--]; 	// array
}

int peek() 	// parameter
{
	if(isEmpty()) 	// parameter
		return -1;
	return stack[top]; 	// array
}

int main()
{
	int m,t,i=0,k;
	scanf("%d",&m); 	// parameter
	scanf("%d",&t); 	// parameter
	while(i<t) 	// parameter
	{
		char s[50]; 	// array
		scanf("%s",s);		 	// parameter
		if(strcmp(s,"pop")==0) 	// conditional,parameter
			printf("%d\n",pop()); 	// parameter
		else if(strcmp(s,"isempty")==0) 	// conditional,parameter
			printf("%d\n",isEmpty()); 	// parameter
		else if(strcmp(s,"top")==0) 	// conditional,parameter
			printf("%d\n",peek()); 	// parameter
		else if(strcmp(s,"push")==0) 	// conditional,parameter
		{
			scanf("%d",&k); 	// parameter
			printf("%d\n",push(k,m)); 	// parameter
		}
		i++; 	// increment
	}
	return 0;
}

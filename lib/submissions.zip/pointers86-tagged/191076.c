#include<stdio.h>

#include<string.h>

int main()

{

    int e,m,t,top,f=-1,i;

    scanf("%d",&m); 	// parameter

    scanf("%d",&t); 	// parameter

    int s[m]; 	// array

    char ch[5]; 	// array

    for(i=0;i<t;i++) 	// loop,parameter

    {

        scanf("%s",&ch); 	// parameter

        if(strcmp(ch,"push")==0) 	// conditional,parameter

        {

            scanf("%d",&e); 	// parameter

            if(f==m-1) 	// conditional,parameter

            {

                printf("-1 \n"); 	// parameter

            }

            else{

                f=f+1;

                s[f]=e; 	// array

                printf("1 \n"); 	// parameter

            }

        }

        else if(strcmp(ch,"isempty")==0) 	// conditional,parameter

        {

            if(f==-1) 	// conditional,parameter

            {

                printf("1 \n"); 	// parameter

            }

            else{

                printf("0 \n"); 	// parameter

            }

        }

        else if(strcmp(ch,"top")==0) 	// conditional,parameter

        {

            if(f!=-1) 	// parameter

            {

                printf("%d \n",s[f]); 	// array,parameter

            }

            else{

                printf("-1 \n"); 	// parameter

            }

        }

        else if(strcmp(ch,"pop")==0) 	// conditional,parameter

            {

            if(f==-1) 	// conditional,parameter

            {

                printf("-1 \n"); 	// parameter

            }

            else

            {

                printf("%d \n",s[f]); 	// array,parameter

                f=f-1;

            }

        }

    }

    return 0;

}

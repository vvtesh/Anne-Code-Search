#include<stdio.h>

#include<stdlib.h>

#include<string.h>

int top=-1,x;

void push(int A[],int p) 	// array,function,parameter



{

    scanf("%d",&x); 	// parameter

    if(top==(p-1)) 	// conditional,parameter

    {

        printf("-1\n"); 	// parameter



    }

    else{

    printf("1\n"); 	// parameter



    A[++top]=x; 	// array,increment

    }



}

void pop(int A[]){ 	// array

    if(top==-1) 	// conditional,parameter

    {

        printf("-1\n"); 	// parameter



    }

    else{

        printf("%d\n",A[top]); 	// array,parameter

        top--; 	// decrement

    }

}

int Isempty(int A[]){ 	// array,parameter

    if(top==-1){ 	// conditional,parameter

        return 1;

        }

    else{

        return 0 ;

        }

}





void isempty(int A[]){ 	// array

    if(Isempty(A)==1){ 	// conditional,parameter

    printf("1\n"); 	// parameter

    }

    else if(Isempty(A)==0) 	// conditional,parameter

    {

    printf("0\n"); 	// parameter

    }

}

int Top(int A[]){ 	// array,parameter

    if(Isempty(A)==1){ 	// conditional,parameter

    printf("-1\n"); 	// parameter

    }

    else if(Isempty(A)==0) 	// conditional,parameter

    {

    printf("%d\n",A[top]); 	// array,parameter

    }

}

void main(){ 	// function

    int p,l,i=0;

    scanf("%d",&p); 	// parameter

    int A[p]; 	// array

    scanf("%d",&l); 	// parameter

    char s[10]; 	// array

    while (i<l){ 	// parameter

            scanf("%s",&s); 	// parameter

            if (strcmp(s,"push")==0){ 	// conditional,parameter

                push(A,p); 	// parameter

            }

            else if(strcmp(s,"isempty")==0){ 	// conditional,parameter

                isempty(A); 	// parameter

            }

            else if (strcmp(s,"pop")==0){ 	// conditional,parameter

                pop(A); 	// parameter

            }

            else if (strcmp(s,"top")==0){ 	// conditional,parameter

                Top(A); 	// parameter

            }

            i++; 	// increment

    }



}

#include <stdio.h>

#include <stdlib.h>

#include<string.h>

typedef struct point

{

int x,y;

}point;

typedef struct node

{

point a;

struct node * next; 	// pointer

struct node * prev; 	// pointer

}node ;

typedef struct command

{

    char *str; 	// pointer

    int n1,n2;

}cmd;

cmd check(char *str) 	// parameter

{

    //printf("String Seperated\n");

    cmd obj;

    int n1,n2,i,sp=0,c1=0,c2=0,c3=0;

    char cmd2[10],cmd3[10]; 	// array

    char *cmd1; 	// pointer

    cmd1=(char*)malloc(50*sizeof(char)); 	// pointer,parameter

    for(i=0;i<(strlen(str));i++) 	// loop,parameter

        if(str[i]==' ') 	// conditional,parameter

            sp+=1;

        else

        if(sp==0) 	// conditional,parameter

            cmd1[c1++]=str[i]; 	// array,increment

        else

        if(sp==1) 	// conditional,parameter

            cmd2[c2++]=str[i]; 	// array,increment

        else

        if(sp==2) 	// conditional,parameter

            cmd3[c3++]=str[i]; 	// array,increment

    cmd1[c1]='\0'; 	// array

    n1=atoi(cmd2); 	// parameter

    n2=atoi(cmd3); 	// parameter

    obj.str=cmd1;

    obj.n1=n1;

    obj.n2=n2;

    //printf("%s\n",obj.str);

    //printf("%d %d\n",obj.n1,obj.n2);

    return obj;

}

int createlist(node **start,node **end) 	// parameter

{

    //printf("Createlist Going to work\n");

    if((*start)==NULL) 	// conditional,parameter

    {

    (*start)=(node *)malloc(sizeof(node)); 	// parameter

    (*start)->next=NULL; 	// parameter

    (*start)->prev=NULL; 	// parameter

    }

    (*end)=(*start); 	// parameter

    return 0;

}



int disp(node **start,node **end,cmd obj) 	// parameter

{   //printf("Display Going to work\n");

    node *temp;

    if(obj.n1==0) 	// conditional,parameter

    {

    if((*start)==NULL || (*end)==NULL) 	// conditional,parameter

    {printf("NULL\n\n");return 0;} 	// parameter

    temp=(*start); 	// parameter

    while(1) 	// parameter

    {

    if(temp->next==NULL) 	// conditional,parameter

    {printf("%d %d\n",temp->a.x,temp->a.y);break;} 	// conditional,parameter

    printf("%d %d\n",temp->a.x,temp->a.y); 	// conditional,parameter

    temp=temp->next;

    }

    }

    else

    {

    if((*end)==NULL || (*start)==NULL) 	// conditional,parameter

    {printf("NULL\n\n");return 0;} 	// parameter

    temp=(*end); 	// parameter

    if((*end)!=NULL) 	// parameter

    while(1) 	// parameter

    {

    if(temp->prev==NULL) 	// conditional,parameter

    {printf("%d %d\n",temp->a.x,temp->a.y);break;} 	// conditional,parameter

    printf("%d %d\n",temp->a.x,temp->a.y); 	// conditional,parameter

    temp=temp->prev;

    }

    }

    printf("\n"); 	// parameter

    return 0;

}



int insertbeg(node **start,node **end,cmd obj) 	// parameter

{

    //printf("Insertbeg Going to work\n");

    node *temp;

    if((*start)==NULL) 	// conditional,parameter

        {createlist(&(*start),&(*end));(*start)->a.x = obj.n1;(*start)->a.y = obj.n2;} 	// decrement,parameter

    else

        {

            temp=(node *)malloc(sizeof(node)); 	// parameter

            (*start)->prev=temp; 	// parameter

            temp->next=(*start); 	// parameter

            temp->prev=NULL;

            temp->a.x = obj.n1;temp->a.y = obj.n2; 	// conditional

            (*start)=temp; 	// parameter

        }

        return 0;

}

int insertend(node **start,node **end,cmd obj) 	// parameter

{

    //printf("Insertend Going to work\n");

    node *temp;

    if((*end)==NULL) 	// conditional,parameter

        {createlist(&(*start),&(*end));(*end)->a.x = obj.n1;(*end)->a.y = obj.n2;} 	// decrement,parameter

    else

        {

            temp=(node *)malloc(sizeof(node)); 	// parameter

            (*end)->next=temp; 	// parameter

            temp->prev=(*end); 	// parameter

            temp->next=NULL;

            temp->a.x = obj.n1;temp->a.y = obj.n2; 	// conditional

            (*end)=temp; 	// parameter

        }

        return 0;

}

int deletebeg(node **start) 	// parameter

{   node *temp;

    if((*start)==NULL) 	// conditional,parameter

        return 0;

    if((*start)->next==NULL) 	// conditional,parameter

    {free((*start));(*start)=NULL;return 0;} 	// parameter

    temp=(*start); 	// parameter

    (*start)=(*start)->next; 	// parameter

    (*start)->prev=NULL; 	// parameter

    free(temp); 	// parameter

    temp=NULL;

    return 0;

}

int deletelast(node **end) 	// parameter

{

    node *temp;

    if((*end)==NULL) 	// conditional,parameter

        return 0;

    if((*end)->prev==NULL) 	// conditional,parameter

    {free((*end));(*end)=NULL;return 0;} 	// parameter

    temp=(*end); 	// parameter

    (*end)=(*end)->prev; 	// parameter

    (*end)->next=NULL; 	// parameter

    free(temp); 	// parameter

    temp=NULL;

    return 0;

}

int deletelist(node **start) 	// parameter

{

    node *temp;

    if((*start)==NULL) 	// conditional,parameter

        return 0;

    while(1) 	// parameter

    {

        if((*start)->next==NULL) 	// conditional,parameter

            {free(*start);(*start)=NULL;return 0;} 	// parameter

        temp=(*start); 	// parameter

        (*start)=temp->next; 	// parameter

        free(temp); 	// parameter

    };

    return 0;

}

int main()

{

cmd obj;

node *start=NULL,*end=NULL;

char *str; 	// pointer

str=(char *)malloc(50*sizeof(char)); 	// pointer,parameter

while(1) 	// parameter

{

gets(str); 	// parameter

if(!strcmp(str,"0")) 	// parameter

    break;

obj = check(str); 	// parameter

if(!strcmp(obj.str,"createlist")) 	// parameter

    {/*createlist(&start,&end);disp(&start,&end,obj);*/}

else

if(!strcmp(obj.str,"insertbeg")) 	// parameter

    {insertbeg(&start,&end,obj);/*disp(&start,&end,obj);*/} 	// parameter

else

if(!strcmp(obj.str,"insertend")) 	// parameter

    {insertend(&start,&end,obj);/*disp(&start,&end,obj);*/} 	// parameter

else

if(!strcmp(obj.str,"deletebeg")) 	// parameter

    {deletebeg(&start);/*disp(&start,&end,obj);*/} 	// parameter

else

if(!strcmp(obj.str,"deletelast")) 	// parameter

    {deletelast(&end);/*disp(&start,&end,obj);*/} 	// parameter

else

if(!strcmp(obj.str,"deletelist")) 	// parameter

    {deletelist(&start);/*disp(&start,&end,obj);*/} 	// parameter

else

if(!strcmp(obj.str,"printlist")) 	// parameter

    disp(&start,&end,obj); 	// parameter

}

return 0;

}

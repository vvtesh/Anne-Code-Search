#include<stdio.h>

#include<stdlib.h>

#include<string.h>



int M,T,topp = -1;



int isEmpty() 	// parameter

{

    if(topp==-1) 	// conditional,parameter

        return 1;

    return 0;

}



int top(int arr[]) 	// array,parameter

{

    if(isEmpty()) 	// parameter

        return -1;

    return arr[topp]; 	// array

}



int push(int arr[],int data) 	// array,parameter

{

    if(topp==M-1) 	// conditional,parameter

    {

        return -1;

    }



    topp++; 	// increment

    arr[topp]=data; 	// array

    return 1;

}



int pop(int arr[]) 	// array,parameter

{

    if(isEmpty()) 	// parameter

        return -1;

    int temp=arr[topp]; 	// array

    topp--; 	// decrement

    return temp;

}



int main()

{

    scanf("%d",&M); 	// parameter

    scanf("%d",&T); 	// parameter



    int arr[M-1],K; 	// array

    char opt[10]; 	// array

    int i=0;

    while(i<T) 	// parameter

    {

    scanf("%s",opt); 	// parameter

    

    if(!strcmp("pop",opt)) 	// parameter

        printf("%d\n",pop(arr)); 	// parameter

    else if(!strcmp("push",opt)) 	// parameter

    	{

    	scanf("%d",&K); 	// parameter

        printf("%d\n",push(arr,K)); 	// parameter

        }

    else if(!strcmp("isEmpty",opt) || !strcmp("isempty",opt)) 	// parameter

    {

    	printf("%d\n",isEmpty()); 	// parameter

    }

    else if(!strcmp("top",opt)) 	// parameter

    {

    	printf("%d\n",top(arr)); 	// parameter

    }

    else

    {

    	continue;

    }

    i++; 	// increment

    }

    return 0;

} 

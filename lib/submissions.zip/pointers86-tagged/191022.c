#include<stdlib.h>

#include<string.h>

#include<stdio.h>

int main()

{

    char str[10]; 	// array

    int m,t,i;

    scanf("%d",&m); 	// parameter

    scanf("%d",&t); 	// parameter

    int *array; 	// pointer

    array=(char *)malloc(sizeof(char)*m); 	// pointer,parameter

    m=m-1;

    int top=-1;

    for(i=0;i<t;i++) 	// loop,parameter

   {

    scanf("%s",str); 	// parameter

    if(strcmp(str,"push")==0) 	// conditional,parameter

    {

        if((top+1)>m) 	// parameter

        printf("-1\n"); 	// parameter

        else

        {

            top=top+1;

            printf("1\n"); 	// parameter

            scanf("%d",&array[top]); 	// array,parameter

        }

    }

    else if(strcmp(str,"isempty")==0) 	// conditional,parameter

    {

        if(top<=-1) 	// parameter

        printf("1\n"); 	// parameter

        else

        printf("0\n"); 	// parameter

    }

    else if(strcmp(str,"top")==0) 	// conditional,parameter

    {

        if(top<=-1) 	// parameter

        printf("-1\n"); 	// parameter

        else

        printf("%d\n",array[top]); 	// array,parameter

    }

    else if(strcmp(str,"pop")==0) 	// conditional,parameter

    {

        if(top<=-1) 	// parameter

        printf("-1\n"); 	// parameter

        else

        {

            printf("%d\n",array[top]); 	// array,parameter

            top=top-1;

        }

    }

}

return 0;

}

#include<stdio.h>

#include<string.h>



int top=-1;

int arr[100]; 	// array

void push(a,cap) 	// function,parameter

{

   if(top==cap-1) 	// conditional,parameter

     printf("-1\n"); 	// parameter



   else

   {

     top++; 	// increment

     arr[top]=a; 	// array

     printf("1\n"); 	// parameter

    }



}



void pop() 	// function,parameter

{

   if(top==-1) 	// conditional,parameter

   printf("-1\n"); 	// parameter

   else

   {

   printf("%d\n",arr[top]); 	// array,parameter

    top--; 	// decrement

   }

}

void isempty() 	// function,parameter

{

  if(top==-1) 	// conditional,parameter

    {

      printf("1\n"); 	// parameter

    }

  else

  {

     printf("0\n"); 	// parameter

  }



}



void Top() 	// function,parameter

{

   if(top==-1) 	// conditional,parameter

   {

     printf("-1\n"); 	// parameter

   }

   else

   printf("%d\n",arr[top]); 	// array,parameter

}



int main()

{

   int cap,op,a,j=1;

   char ch[120]; 	// array

   scanf("%d",&cap); 	// parameter

   scanf("%d",&op); 	// parameter

   while(j<=op) 	// parameter

{

   scanf("%s",ch); 	// parameter

   if(strcmp(ch,"push")==0) 	// conditional,parameter

   {

      scanf("\n%d",&a); 	// parameter

      push(a,cap); 	// parameter

   }

   else if(strcmp(ch,"pop")==0) 	// conditional,parameter

   {

      pop(); 	// parameter

   }

    else if(strcmp(ch,"top")==0) 	// conditional,parameter

   {

      Top(); 	// parameter

   }

   else if(strcmp(ch,"isempty")==0) 	// conditional,parameter

   {

      isempty(); 	// parameter

   }

   j++; 	// increment

}

return 0;



}

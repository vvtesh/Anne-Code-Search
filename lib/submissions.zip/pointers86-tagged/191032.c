#include<stdio.h>

#include<string.h>

int m;

struct stack{ 	// function

    int *ary; 	// pointer

    int top;

}sp;

int isempty() 	// parameter

{

    if(sp.top==-1) 	// conditional,parameter

        return 0;

    else

        return 1;

}

int full(){ 	// parameter

    if(sp.top==(m-1)) 	// conditional,parameter

        return 1;

    else

        return 0;

}

int top(){ 	// parameter

    if(isempty()==0) 	// conditional,parameter

        return 0;

    else{

        int e=sp.ary[sp.top]; 	// array

        return e;

    }

}

int push(int item) 	// parameter

{

    if(full()==1) 	// conditional,parameter

        return 0;

    else{

        sp.top++; 	// increment

        sp.ary[sp.top] = item; 	// array

    }

}

int pop() 	// parameter

{

    if(isempty()==0) 	// conditional,parameter

        return 0;

    else{

        int b = sp.ary[sp.top]; 	// array

        sp.top--; 	// decrement

        return b;

    }

}

int main()

{

    int j,i=0,t,k;

    char op[20]; 	// array

    sp.top=-1;

    scanf("%d",&m); 	// parameter

    sp.ary = (int*) malloc (sizeof(int)*m); 	// pointer,parameter

    scanf("%d",&t); 	// parameter

    for(j=0;j<t;j++) 	// loop,parameter

    {

        scanf("%s",op); 	// parameter

        if(strcmp(op,"push")==0){ 	// conditional,parameter

            scanf("%d",&k); 	// parameter

            if(push(k)==0) 	// conditional,parameter

            {

                printf("-1\n"); 	// parameter

            }

            else{

                printf("1\n"); 	// parameter

            }

       }

       else if(strcmp(op,"pop")==0){ 	// conditional,parameter

            if(isempty()==0){ 	// conditional,parameter

                printf("-1\n"); 	// parameter

            }

            else

                printf("%d\n",pop()); 	// parameter

       }

       else if(strcmp(op,"isempty")==0){ 	// conditional,parameter

            if(isempty()==0) 	// conditional,parameter

                printf("1\n"); 	// parameter

            else

                printf("0\n"); 	// parameter

       }

       else if(strcmp(op,"top")==0){ 	// conditional,parameter

            if(top()==0){ 	// conditional,parameter

                printf("-1\n"); 	// parameter

            }

            else

                printf("%d\n",top()); 	// parameter

       }

    }

    return 0;

}

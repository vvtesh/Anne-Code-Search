#include<stdio.h>

#include<string.h>

struct stack

     {

           int stk[50]; 	// array

           int top;

           int max;

     }str;

void init() 	// function,parameter

{

    str.top=-1;

}

void push(int e) 	// function,parameter

{

    if(str.top==(str.max-1)) 	// conditional,parameter

        printf("-1\n"); 	// parameter

    else

    {

        printf("1\n"); 	// parameter

        str.top++; 	// increment

        str.stk[str.top]=e; 	// array

    }

}

void pop() 	// function,parameter

{

    if(str.top==-1) 	// conditional,parameter

        printf("-1\n"); 	// parameter

    else

    {

        printf("%d\n",str.stk[str.top]); 	// array,parameter

        (str.top)--; 	// decrement,parameter

    }

}



void top() 	// function,parameter

{

    int in=0;

    printf("\n"); 	// parameter

    printf("%d->",str.stk[in]); 	// array,parameter

    in++; 	// increment

    while(in<=(str.top)) 	// parameter

    {

        printf("%d->",str.stk[in]); 	// array,parameter

        in++; 	// increment

    }

}



void main() 	// function,parameter

{

    init(); 	// parameter

    int t,e;char s[10]=""; 	// array

    scanf("%d",&str.max); 	// parameter

    scanf("%d",&t); 	// parameter

    while(t>0) 	// parameter

    {

        scanf("%s",&s); 	// parameter

        if(strcmp(s,"push")==0) 	// conditional,parameter

            {

                scanf("%d",&e); 	// parameter

                push(e); 	// parameter

            }

        else if(strcmp(s,"pop")==0) 	// conditional,parameter

            pop(); 	// parameter

        else if(strcmp(s,"top")==0) 	// conditional,parameter

            {

                if(str.top==-1) 	// conditional,parameter

                    printf("-1\n"); 	// parameter

                else

                    printf("%d\n",str.stk[str.top]); 	// array,parameter

            }

        else if(strcmp(s,"isempty")==0) 	// conditional,parameter

            {

                if(str.top==-1) 	// conditional,parameter

                    printf("1\n"); 	// parameter

                else

                    printf("0\n"); 	// parameter

            }

        t--; 	// decrement

      

    }

}

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>

typedef struct stack
{
	int * ar; 	// pointer
	int top;
}stack;

void isempty(stack s) 	// function,parameter
{
	if (s.top == -1) 	// conditional,parameter
	{
		printf("1\n"); 	// parameter
		
	}
	else
	{	
		printf("0\n");  	// parameter
		
	}
}

void top(stack s) 	// function,parameter
{
	if(s.top ==-1) 	// conditional,parameter
	{	
		printf("-1\n"); 	// parameter
	}
	else
		printf("%d\n",s.ar[s.top]); 	// array,parameter
}

int push(stack s,int elm,int sz) 	// parameter
{
	if(s.top==sz-1) 	// conditional,parameter
		printf("-1\n"); 	// parameter
	else
	{
		s.top++; 	// increment
		s.ar[s.top]=elm; 	// array
		printf("1\n"); 	// parameter
	}
	return s.top;	
}

int pop(stack s) 	// parameter
{ 	
	if(s.top == -1 ) 	// conditional,parameter
	{	
		printf("-1\n"); 	// parameter
	}
	else
	{	
		s.top--; 	// decrement
	}
	return s.top;	
}


int main()
{
	stack s;
	int sz,elm,i,j;
	char fn[100]="NULL"; 	// array
	s.top = -1;
	scanf("%d",&sz); 	// parameter
	scanf("%d",&i); 	// parameter
	s.ar = malloc(sizeof(int *)*sz); 	// pointer,parameter
	for ( j=0;j<i;j++) 	// loop,parameter
	{
		if(j==0) 	// conditional,parameter
			getchar(); 	// parameter
		else if (!strcmp(fn,"push")) 	// parameter
			getchar(); 	// parameter
		gets(fn); 	// parameter
		if (!strcmp(fn,"push")) 	// parameter
		{
			scanf("%d",&elm); 	// parameter
			

			s.top=push(s,elm,sz); 	// parameter
		}
		else if (!strcmp(fn,"pop")) 	// parameter
		{
			s.top=pop(s); 	// parameter
		}
		else if (!strcmp(fn,"isempty")) 	// parameter
		{
			isempty(s); 	// parameter
		}
		else if (!strcmp(fn,"top")) 	// parameter
		{
			top(s); 	// parameter
		}
	}
	free(s.ar);	 	// parameter
	return 0;
}

#include <stdio.h>
#include<string.h>
int top, status;
void push (int stack[], int item, int size) 	// array,parameter
{   if (top == size -1) 	// conditional,parameter
	printf("\n%d",-1); 	// parameter
    else
    {  
	++top; 	// increment
	stack [top] = item; 	// array
	printf("\n%d",1); 	// parameter
    }
}
int isEmpty(int stack[]) 	// array,parameter
{
	if(top==-1) 	// conditional,parameter
		return 1;
	return 0;
}
int pop (int stack[]) 	// array,parameter
{  
    int ret;
    if (top == -1) 	// conditional,parameter
    {   ret = 0;
	status = 0;
    }
    else
    {   status = 1;
	ret = stack [top]; 	// array
	--top; 	// decrement
    }
return ret;
}
 
int get_top(int stack[]) 	// array,parameter
{
	return stack[top]; 	// array
}
 
int main()
{  
    int item,n,i;
    int size;
    char ch[10], pushv[10], popv[10], isempty[10], topv[10]; 	// array
    strcpy(pushv,"push"); 	// parameter
    strcpy(popv,"pop"); 	// parameter
    strcpy(isempty,"isempty"); 	// parameter
    strcpy(topv,"top"); 	// parameter
    top = -1;
    scanf("%d",&size); 	// parameter
    scanf("%d",&n); 	// parameter
    int stack[size]; 	// array
    for(i=0;i<n;i++) 	// loop,parameter
	{
		scanf("%s",ch); 	// parameter
		if(strcmp(ch,pushv)==0) 	// conditional,parameter
		{
			scanf  ("%d", &item); 	// parameter
			push (stack, item, size); 	// parameter
		}
		else if(strcmp(ch,popv)==0) 	// conditional,parameter
		{
			if(top!=-1){ 	// conditional,parameter
			item = pop (stack); 	// parameter
			printf ("\n%d", item); 	// parameter
			}
			else
				printf("\n%d",-1); 	// parameter
		}
		else if(strcmp(ch,isempty)==0) 	// conditional,parameter
		{
			if(isEmpty(stack)) 	// parameter
				printf("\n%d",1); 	// parameter
			else
				printf("\n%d",0); 	// parameter
		}
		else if(strcmp(ch,topv)==0) 	// conditional,parameter
		{
			if(top!=-1){ 	// conditional,parameter
				item = get_top(stack); 	// parameter
			printf("\n%d",item); 	// parameter
			}
			else
				printf("\n%d",-1); 	// parameter
		}
	}
	return 0;
}

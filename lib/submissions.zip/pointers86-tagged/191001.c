#include<stdio.h>
#include<string.h>
int top = -1;
int main()
{
int i;
int m;
int t;

//printf("enter size\n");
scanf("%d", &m); 	// parameter

//printf("enter no of operations \n");
scanf("%d", &t); 	// parameter

    int A[100]; 	// array
  char C[10]; 	// array
int ele;
for(i=0;i<t;i++) 	// loop,parameter
{

 //printf("pop=pop an element\n");
  //printf("isempty\n");
  //printf("top=top element\n");
  //printf("push=push an element\n");
  //printf("enter choices: \n");
  scanf("%s", &C); 	// parameter

       if(strcmp(C,"push")==0) 	// conditional,parameter
              {
    //          printf("enter element\n");
               scanf("%d", &ele); 	// parameter
               push(ele,A); 	// parameter
               }

       else if(strcmp(C,"pop")==0) 	// conditional,parameter
       {
               pop(arr); 	// parameter
               }
       else if(strcmp(C,"top")==0) 	// conditional,parameter
               top1(arr); 	// parameter

               else if(strcmp(C,"isempty")==0) 	// conditional,parameter
                        isempty(); 	// parameter




   }
return 0;

}

void isempty() 	// function,parameter

{
    if(top==-1) 	// conditional,parameter
        printf("1\n"); 	// parameter
    else
        printf("0\n"); 	// parameter

}
void top1(int d[]) 	// array,function,parameter

{ int l;
    if(top==-1) 	// conditional,parameter
        printf("-1\n"); 	// parameter
    else
    {
        l=top;
        printf("%d\n", d[l]); 	// array,parameter

    }



}
void push(int element, int c[]) 	// array,function,parameter
{
    int b;
    top++; 	// increment
    c[top]=element; 	// array
    b++; 	// increment
int d;
d=strlen(c); 	// parameter
if(b!=d) 	// parameter

    printf("1\n"); 	// parameter
else
    printf("-1\n"); 	// parameter

}
 void pop(int d[]) 	// array,function,parameter
 {
int i;
if(top==-1) 	// conditional,parameter
printf("-1\n"); 	// parameter
else
{printf("%d\n", d[top]); 	// array,parameter
    top--; 	// decrement
}
 }

#include<stdio.h>
#include<string.h>
int main()
{
    int m;
    scanf("%d",&m); 	// parameter
    int a[m]; 	// array
    int t;
	int top=-1;
    scanf("%d",&t); 	// parameter
    while (t--) 	// parameter
    {
        char c[10]; 	// array
        scanf("%s",c); 	// parameter
        if (strcmp(c,"push")==0) 	// conditional,parameter
        {
            int ele;
		scanf("%d",&ele); 	// parameter
		if (top==m-1) 	// conditional,parameter
		{
			printf("-1\n"); 	// parameter
		}
		else
		{
		top++; 	// increment
		a[top]=ele; 	// array
		printf("1\n"); 	// parameter
		}
        }
        else if (strcmp(c,"isempty")==0) 	// conditional,parameter
        {
		if (top==-1) 	// conditional,parameter
		printf("1\n"); 	// parameter
		else
		printf("0\n"); 	// parameter
        }
	else if (strcmp(c,"top")==0) 	// conditional,parameter
	{
		if (top==-1) 	// conditional,parameter
		{
			printf("-1\n"); 	// parameter
		}
		else
		{
		printf("%d\n",a[top]);} 	// array,parameter
	}
	else if (strcmp(c,"pop")==0) 	// conditional,parameter
	{
		if (top==-1) 	// conditional,parameter
		printf("-1\n"); 	// parameter
		else
		{printf("%d\n",a[top]); 	// array,parameter
		top--;}
	}
    }
    
}

#include<stdio.h>

#include<string.h>

#include<stdlib.h>



struct Node

{

    int x;

    int y;

    struct Node* next; 	// pointer

    struct Node* prev; 	// pointer

};

    struct Node* head; 	// pointer

    struct Node* tail; 	// pointer



void createlist() 	// function,parameter

{

       head=NULL;

       tail=NULL;



}





void insertbeg( int a , int b) 	// function,parameter

{

    if(head==NULL) 	// conditional,parameter

    {

       struct Node* temp = (struct node*)malloc(sizeof(struct Node)); 	// parameter

       temp->x=a;

       temp->y=b;

       temp->next=NULL;

       temp->prev=NULL;

       head=temp;

       tail=temp;

    }

    else

    {

         struct Node* temp = (struct node*)malloc(sizeof(struct Node)); 	// parameter

    temp->x=a;

    temp->y=b;

    temp->next=NULL;

    temp->prev=NULL;

    head->prev=temp;

    temp->next=head;

    head=temp;

    }

}







void insertend( int a , int b) 	// function,parameter

{

   if(head==NULL) 	// conditional,parameter

    {

       struct Node* temp = (struct node*)malloc(sizeof(struct Node)); 	// parameter

       temp->x=a;

       temp->y=b;

       temp->next=NULL;

       temp->prev=NULL;

       head=temp;

       tail=temp;

    }

    else

    {

    struct Node* temp = (struct node*)malloc(sizeof(struct Node)); 	// parameter

    temp->x=a;

    temp->y=b;

    temp->next=NULL;

    temp->prev=NULL;

    tail->next=temp;

    temp->prev=tail;

    tail=temp;

    }



}





void deletebeg() 	// function,parameter

{

    if(head==NULL) 	// conditional,parameter

    {

        return;

    }

    else if(head==tail) 	// conditional,parameter

    {

       head=NULL;

       tail=NULL;

    }

    else

    {

    struct Node* temp=head;

    head=head->next;

    free(temp); 	// parameter

    head->prev=NULL;

    }

}



void deletelast() 	// function,parameter

{

    if(head==NULL) 	// conditional,parameter

    {

        return;

    }

    else if(head==tail) 	// conditional,parameter

    {

        head=NULL;

        tail=NULL;

    }

    else

    {

    struct Node* temp=tail;

    tail=tail->prev;

    free(temp); 	// parameter

    tail->next=NULL;

    }

}



void deletelist() 	// function,parameter

{

    while(head!=NULL) 	// parameter

    {

      struct Node* temp=head;

      head=head->next;

      free(temp); 	// parameter

      if(head==NULL)break; 	// conditional,parameter

    }





}

void printlistforward() 	// function,parameter

{

  if(head==NULL) 	// conditional,parameter

  {

      printf("NULL\n\n"); 	// parameter

  }

  else{

  struct Node* temp=head;

  while(temp!=NULL) 	// parameter

  {

      printf("%d %d\n",temp->x,temp->y); 	// conditional,parameter

      temp=temp->next;

      if(temp==NULL) 	// conditional,parameter

      {

          printf("\n"); 	// parameter

          break;

      }

  }

  }

}



void printlistbackward() 	// function,parameter

{

  if(head==NULL) 	// conditional,parameter

  {

      printf("NULL\n\n"); 	// parameter

  }

  else{

  struct Node* temp=tail;

  while(temp!=NULL) 	// parameter

  {

      printf("%d %d\n",temp->x,temp->y); 	// conditional,parameter

      temp=temp->prev;

      if(temp==NULL) 	// conditional,parameter

      {

          printf("\n"); 	// parameter

          break;

      }

  }

  }

}



int main ( )

{

  char operation[50]; 	// array

  while(1) 	// parameter

  {

      scanf("%s",operation); 	// parameter

      if(strcmp(operation,"createlist")==0) 	// conditional,parameter

      {

          createlist(); 	// parameter

      }

      else if(strcmp(operation,"insertbeg")==0) 	// conditional,parameter

      {

          int x;

          int y;

          scanf("%d %d",&x,&y); 	// parameter

          insertbeg(x,y); 	// parameter

      }

      else if(strcmp(operation,"insertend")==0) 	// conditional,parameter

      {

          int a;

          int b;

          scanf("%d %d",&a,&b); 	// parameter

          insertend(a,b); 	// parameter

      }

      else if(strcmp(operation,"deletebeg")==0) 	// conditional,parameter

      {

          deletebeg(); 	// parameter

      }

      else if(strcmp(operation,"deletelast")==0) 	// conditional,parameter

      {

          deletelast(); 	// parameter

      }

      else if(strcmp(operation,"deletelist")==0) 	// conditional,parameter

      {

          deletelist(); 	// parameter

      }

      else if(strcmp(operation,"printlist")==0) 	// conditional,parameter

      {

          int k;

          scanf("%d",&k); 	// parameter

          if(k==0) 	// conditional,parameter

          {

              printlistforward(); 	// parameter

          }

          else if(k==1) 	// conditional,parameter

          {

              printlistbackward(); 	// parameter

          }

      }

      else if(strcmp(operation,"0")==0) 	// conditional,parameter

      {

          break;

      }

  }





  return 0;



}

#include<stdio.h>
#include<string.h>
int Top;
int M;
void push(int K,int stack[],int M) 	// array,function,parameter
{
	if(Top==(M-1)) 	// conditional,parameter
		printf("-1\n"); 	// parameter
	else
	{
		Top++; 	// increment
		stack[Top]=K; 	// array
		printf("1\n"); 	// parameter
	}
}
int pop(int stack[],int M) 	// array,parameter
{
	if(Top==-1) 	// conditional,parameter
		printf("-1\n"); 	// parameter
	else
	{
		printf("%d\n",stack[Top]); 	// array,parameter
		Top--; 	// decrement
	}
}
int top(int stack[],int M) 	// array,parameter
{
	if(Top==-1) 	// conditional,parameter
		printf("-1\n"); 	// parameter
else
	{int K;
	K=stack[Top]; 	// array
	printf("%d\n",K); } 	// parameter
}
int isempty(int stack[],int M) 	// array,parameter
{
	if (Top==-1) 	// conditional,parameter
		return 0;
	else 
		return 1; 
}
int main()
{
	int M,T=1,K,i=0;
	scanf("%d",&M); 	// parameter
	int stack[M]; 	// array
	Top=(-1); 	// parameter
	scanf("%d",&T); 	// parameter
	while(i!=T) 	// parameter
	{
		int b,l=0; 
		char a[20]; 	// array
		scanf("%s",&a); 	// parameter
		b=strcmp("push",a); 	// parameter
		if(b==0) 	// conditional,parameter
			l=1;
		b=strcmp("pop",a); 	// parameter
		if(b==0) 	// conditional,parameter
			l=2;
		b=strcmp("isempty",a); 	// parameter
		if(b==0) 	// conditional,parameter
			l=3;
		b=strcmp("top",a); 	// parameter
		if(b==0) 	// conditional,parameter
			l=4;
		if(l==1) 	// conditional,parameter
		{
			scanf("%d",&K); 	// parameter
			push(K,stack,M); 	// parameter
			i++; 	// increment
		}
		else if(l==2) 	// conditional,parameter
		{
			pop(stack,M); 	// parameter
			i++; 	// increment
		}
		else if(l==3) 	// conditional,parameter
		{
			K=isempty(stack,M); 	// parameter
			if(K==1) 	// conditional,parameter
				printf("0\n"); 	// parameter
			else
				printf("1\n"); 	// parameter
			i++; 	// increment
		}
		else if(l==4) 	// conditional,parameter
		{
			top(stack,M); 	// parameter
			i++; 	// increment
		}
	}
}

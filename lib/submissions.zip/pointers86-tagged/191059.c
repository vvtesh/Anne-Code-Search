#include<stdio.h>

#include<string.h>

#include<stdlib.h>

int main()

{

    int m,t,item,top=-1,count=0;

    scanf("%d",&m); 	// parameter

    int arr[m]; 	// array

    scanf("%d",&t); 	// parameter

    char str[10]; 	// array



int sfull() 	// parameter

{

    if(top>=m-1) 	// parameter

        return 1;

    else

        return -1;

}



void spush(int k) 	// function,parameter

{

 if(sfull()==1) 	// conditional,parameter

 {

     printf("-1\n"); 	// parameter

 }

 else

 {

     top++; 	// increment

    arr[top]=k; 	// array

    printf("1\n"); 	// parameter

 }

}



void spop() 	// function,parameter

{

    int k;

    if(top==-1) 	// conditional,parameter

    {

        printf("-1\n"); 	// parameter

    }

    else

    {

        k=arr[top]; 	// array

        top--; 	// decrement

        printf("%d\n",k); 	// parameter

    }

}



void atop() 	// function,parameter

{

    if(top==-1) 	// conditional,parameter

    {

        printf("-1\n"); 	// parameter

    }

    else

        printf("%d\n",arr[top]); 	// array,parameter

}







while(count<=t-1) 	// parameter

{

    scanf("%s",str); 	// parameter

    if(strcmp(str,"push")==0) 	// conditional,parameter

    {

        scanf("%item",&item); 	// parameter

        spush(item); 	// parameter

        count++; 	// increment

    }

    else if(strcmp(str,"isempty")==0) 	// conditional,parameter

    {

        if(top==-1) 	// conditional,parameter

        {

            printf("1\n"); 	// parameter

        }

        else

            printf("0\n"); 	// parameter

        count++; 	// increment

    }

    else if(strcmp(str,"pop")==0) 	// conditional,parameter

    {

        spop(); 	// parameter

        count++; 	// increment

    }

    else if(strcmp(str,"top")==0) 	// conditional,parameter

    {

        atop(); 	// parameter

        count++; 	// increment

    }

}

    return 0;

}

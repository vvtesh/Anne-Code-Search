#include<stdio.h>

#include<string.h>

#include<stdlib.h>

int m;

int *a; 	// pointer

int top=-1;



void push(int x) 	// function,parameter

{

    if(top==m-1) 	// conditional,parameter

    {

        printf("-1\n"); 	// parameter

    }

    else

    {

        top=top+1;

        a[top]=x; 	// array

        printf("1\n"); 	// parameter

    }



}

void pop() 	// function,parameter

{

    if(top==-1) 	// conditional,parameter

    {

        printf("-1\n"); 	// parameter

    }

    else

    {

        printf("%d\n",a[top]); 	// array,parameter

        top=top-1;

    }

}

void isempty() 	// function,parameter

{

    if(top==-1) 	// conditional,parameter

    {

        printf("1\n"); 	// parameter

    }

    else

    {

        printf("0\n"); 	// parameter

    }

}

void topp() 	// function,parameter

{

    if(top==-1) 	// conditional,parameter

    {

        printf("-1\n"); 	// parameter

    }

    else

    {

        printf("%d\n",a[top]); 	// array,parameter

    }

}





int main()

{

    int t,q;

    scanf("%d",&m); 	// parameter

    a=(int *)malloc((sizeof(int)*m)); 	// parameter

    scanf("%d",&t); 	// parameter

    while(t>0) 	// parameter

    {

        char arr[10]; 	// array

        scanf("%s",&arr); 	// parameter

        if(strcmp(arr,"push")==0) 	// conditional,parameter

        {

            scanf("%d",&q); 	// parameter

            push(q); 	// parameter

        }

        if(strcmp(arr,"pop")==0) 	// conditional,parameter

        {

            pop(); 	// parameter

        }

        if(strcmp(arr,"top")==0) 	// conditional,parameter

        {

            topp(); 	// parameter

        }

        if(strcmp(arr,"isempty")==0) 	// conditional,parameter

        {

            isempty(); 	// parameter

        }

        t--; 	// decrement

    }

    return 0;







}

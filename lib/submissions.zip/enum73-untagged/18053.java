package AP2014.Assignment1.MainClasses;

import java.util.Scanner;

import AP2014.Assignment1.Question6.Planets;

public class Question6 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		double g = 0;
		System.out.println("Enter your weight.");
		double mass = in.nextInt() / 9.798;
		for (Planets x : Planets.values()) {
			switch (x) {
			case Mercury:
				g = 3.7;
				break;

			case Venus:
				g = 8.87;
				break;
			case Earth:
				g = 9.798;
				break;
			case Mars:
				g = 3.71;
				break;
			case Jupiter:
				g = 24.92;
				break;
			case Saturn:
				g = 10.44;
				break;
			case Uranus:
				g = 8.87;
				break;
			case Neptune:
				g = 11.15;
				break;

			case Pluto:
				g = 0.58;
				break;

			default:
				break;
			}

			System.out.println("Your weight on " + x + " is " + g * mass);
		}
	}

}

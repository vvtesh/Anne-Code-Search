
public enum Planet 
{
	
			MERCURY(0.378),
			VENUS(0.907),
			EARTH(1.00),
			MARS(0.377),
			SATURN(0.916),
			JUPITER(2.360),
			URANUS (0.889),
			NEPTUNE (1.120);
			
			private double gravityvalue;
			
			private Planet(double gravity )
			{
				this.gravityvalue=gravity;
			}
			public double getgravity()
			{
				return this.gravityvalue;
			}


}





public class weight {
	public enum Planet{
		mercury,venus,earth,mars,jupiter,saturn,uranus,neptune;
	}
	Planet planet;
	private static double[] arrs;
	
	public static void main(String[] args)
{
		String  s = args[0];
		double input = Double.parseDouble(s);;
		arrs = new double[] {0.378,0.907,1,0.377,2.36,0.916,0.889,1.12};
		Planet[] values = Planet.values();
		for (int i = 0; i < values.length; i++) {
			Planet p = values[i];
			System.out.println("The weight on " + p + " is " + arrs[i]*input);
		}
		}
}

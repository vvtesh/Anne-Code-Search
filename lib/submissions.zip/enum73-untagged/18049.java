package ap2014.assignment1.Question6;

public enum Planets {

	  MERCURY(0.38),
	  VENUS(0.91),
	  EARTH(1.00),
	  MARS(0.38),
	  JUPITER(2.34),
	  SATURN(1.06),
	  URANUS(0.92),
	  NEPTUNE(1.19);
	  private final double factor;
	  
	  Planets(double f) {
	        this.factor = f;
	    }
	  
	  public static void calcvals(double weight) {
		  for (Planets p : Planets.values())
	            System.out.println("Your weight on "+p+" is "+(weight*p.factor)+"(kgs/pounds)");
	  }
}

package q6;

	//Each planet has its surface gravity associated with it.
	//Source of surface gravities: http://www.smartconversion.com/otherInfo/gravity_of_planets_and_the_sun.aspx	
	public enum Planet {
		MERCURY (3.7),
		VENUS (8.87),
		EARTH (9.798),
		MARS (3.71),
		JUPITER (24.92),
		SATURN (10.44),
		URANUS (8.87),
		NEPTUNE (11.15);
		//Format is PlanetName(SurfaceGravityOnThatPlanet in m/s^2)
		private double surfaceGravity;
		
		private Planet(double surfaceGravity) {
			this.surfaceGravity = surfaceGravity;
		}
		
		public double getSG() {
			return surfaceGravity;
		}
	}

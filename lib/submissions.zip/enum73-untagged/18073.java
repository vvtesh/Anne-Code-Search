package Q6;

import java.util.Scanner;

/*
weight = mass * surface gravity(g)
EARTHg = 1.00
MERCg = 0.38
VENg = 0.90
MARSg = 0.38
JUPg = 2.53
SATg = 1.07
URAg = 0.89
NEPg = 1.14
PLUTOg = 0.067
*/

public class Wtest
{
	public enum Planet
	{
		MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE
	}
	Planet planet;
	
	public Wtest(Planet planet)
	{
		this.planet = planet;
	}
	
	public void wprint(int w)
	{
		switch (planet)
		{
			case MERCURY: 
				System.out.printf("weight on mercury is %f\n", w * 0.38);
				break;
			case VENUS: 
				System.out.printf("weight on veuns is %f\n", w * 0.90);
				break;
			case MARS: 
				System.out.printf("weight on mars is %f\n", w * 0.38);
				break;
			case JUPITER: 
				System.out.printf("weight on jupiter is %f\n", w * 2.53);
				break;
			case SATURN: 
				System.out.printf("weight on mercury is %f\n", w * 1.07);
				break;
			case URANUS: 
				System.out.printf("weight on uranus is %f\n", w * 0.89);
				break;
			case NEPTUNE: 
				System.out.printf("weight on neptune is %f\n", w * 1.14);
				break;
			default:
				System.out.println("not part of the solar system\n");
				break;
		}
	}

	

}
package ap2014.assignment1.question6;

public enum Planets{
	MARS		(0.38),
	JUPITER		(2.54),
	MERCURY		(0.38),
	PLUTO		(0.06),
	EARTH		(1),
	SATURN		(1.08),
	VENUS		(0.91),
	URANUS		(0.91),
	NEPTUNE		(1.19);

	private final double gravityconstant;
	Planets(double gravityconstant)
	{
		this.gravityconstant=gravityconstant;
	}
	public double getPlanets()
	{
		return this.gravityconstant;
	}
}

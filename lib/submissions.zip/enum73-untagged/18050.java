package Q6;
import java.util.*;
public class weight {
	public enum planets {
		Mercury,Venus,Earth,Mars,Jupiter,Saturn,Uranus,Neptune,Pluto;	
	}
	
	planets name;
	
	public weight(planets name)
	{
		this.name = name;
	}
	
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		System.out.println("Enter your weight:");
		double w = input.nextDouble();
		System.out.println("Your weight on all the planets are:");
		double w2;
		System.out.print("On Mercury: ");
		w2=w*0.38;
		System.out.println(w2);
		
		System.out.print("On Venus: ");
		w2=w*0.91;
		System.out.println(w2);
		
		System.out.print("On Earth: ");
		w2=w*1.0;
		System.out.println(w2);
		
		System.out.print("On Mars: ");
		w2=w*0.38;
		System.out.println(w2);
		
		System.out.print("On Jupiter: ");
		w2=w*2.54;
		System.out.println(w2);
		
		System.out.print("On Saturn: ");
		w2=w*1.08;
		System.out.println(w2);
		
		System.out.print("On Uranus: ");
		w2=w*0.91;
		System.out.println(w2);
		
		System.out.print("On Neptune: ");
		w2=w*1.19;
		System.out.println(w2);
		
		System.out.print("On Pluto: ");
		w2=w*0.06;
		System.out.println(w2);
	}
}

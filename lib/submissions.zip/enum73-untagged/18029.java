package question6;

public enum Planets {
	MERCURY(3.61),VENUS(8.83),EARTH(9.8),MARS(3.75),JUPITER(26.0),SATURN(11.2),URANUS(10.5),NEPTUNE(13.3),PLUTO(0.61);
	public double g;
	Planets(double g){
		this.g=g;
	}
	public double returng(){
		return g;
	}
}
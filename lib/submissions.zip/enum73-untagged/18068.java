
enum Planets {
	Mercury, 
	Venus, 
	Earth,
	Mars, 
	Jupiter,
	Saturn,
	Uranus,
	Neptune
}

class weight {
	
Planets p;
	
	public weight(Planets p)
	{
		this.p=p;
	}
	
	public void WaightOnPlanet(float w) {
	    switch (p) {
	        case Mercury:
	            System.out.println("Weight on Mercury is: "+w*0.38+"kg");
	            break;
	                
	        case Venus:
	            System.out.println("Weight on Venus is: "+w*0.91+"kg");
	            break;
	                     
	        case Earth:
	            System.out.println("Weight on Earth is: "+w*1+"kg");
	            break;
	            
	        case Mars:
	            System.out.println("Weight on Mars is: "+w*0.38+"kg");
	            break;
	            
	        case Jupiter:
	            System.out.println("Weight on Jupiter is: "+w*2.34+"kg");
	            break;
	            
	        case Saturn:
	            System.out.println("Weight on Saturn is: "+w*0.93+"kg");
	            break;
	            
	        case Uranus:
	            System.out.println("Weight on Uranus is: "+w*0.92+"kg");
	            break;
	            
	        case Neptune:
	            System.out.println("Weight on Neptune is: "+w*1.12+"kg");
	            break;   
	    }
	}
	
}

public class Question6 {
		
	
	public static void main(String[] args) {
		float w = Float.parseFloat(args[0]);
		
		 weight one = new weight(Planets.Mercury);
	        one.WaightOnPlanet(w);
	     weight two = new weight(Planets.Venus);
	        two.WaightOnPlanet(w);   
	     weight three = new weight(Planets.Earth);
	        three.WaightOnPlanet(w);
	     weight four = new weight(Planets.Mars);
	        four.WaightOnPlanet(w);
	     weight five = new weight(Planets.Jupiter);
	        five.WaightOnPlanet(w);
	     weight six = new weight(Planets.Saturn);
	        six.WaightOnPlanet(w);
	     weight seven = new weight(Planets.Uranus);
	        seven.WaightOnPlanet(w);
	     weight eight = new weight(Planets.Neptune);
	        eight.WaightOnPlanet(w);
	}
	
}

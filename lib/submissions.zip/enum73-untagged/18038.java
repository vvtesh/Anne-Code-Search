package commandline;

		public class Question6{
			public enum Planets {Mercury,Venus,Earth,Mars,Jupiter,Saturn,Uranus,Neptune};
			public static void main(String[] args) {
				// TODO Auto-generated method stub
				System.out.println("Enter weight in kgs:->");
				int weight=Integer.parseInt(args[0]);
				double Mercury = (weight * .38); 
				double Venus = (weight * .91); 
				double Earth = (weight * 1); 
				double Mars = (weight * .38); 
				double Jupiter = (weight * 2.34); 
				double Saturn = (weight * 1.06); 
				double Uranus = (weight * .92); 
				double Neptune = (weight * 1.19); 
				
				System.out.println(Mercury);
				System.out.println(Venus);
				System.out.println(Earth);
				System.out.println(Mars);
				System.out.println(Jupiter);
				System.out.println(Saturn);
				System.out.println(Uranus);
				System.out.println(Neptune);
				
				   
				
			}

		}

package mainclasses;

import java.util.*;
import java.util.Scanner;

public class question6 {

		public enum planet {

			MERCURY, VENUS,EARTH,MARS,JUPITOR,SATURN,URANUS,NEPTUNE,PLUTO,
		}
		
		planet name;
		
		
		public question6(planet name) {
	       this.name=name; 
	    }
		 
		public void calc(int n){
			switch(name){
			case MERCURY: {  double x;
							x = n * 0.38;
							System.out.println("mercury " +x);
							break;
			               }
			case VENUS: { double x;
			              x= n *0.91;
			              System.out.println("venus " +x);
				          break;
			            }
			case EARTH: { double x;
						 x= n * 1.0;
						 System.out.println("earth " +x);
						 break;
						}
			case MARS: { double x;
	        			x= n * 0.38;
	        			System.out.println("mars " +x);
	        			break;
	                      }
			case JUPITOR: { double x;
							x= n * 2.34;
							System.out.println("jupitor " +x);
							break;
	                        }
			case SATURN: { double x;
	        			  x= n * 1.06;
	        			  System.out.println("saturn " +x);
	        			  break;
	                     }
			case URANUS : { double x;
	        			   x= n * 0.92;
	        			   System.out.println("uranus " +x);
	        			   break;
	                       }
			case NEPTUNE: { double x;
	               		 x= n * 1.19;
	               		 System.out.println("neptune " +x);
	               		 break;
	                      }
			case PLUTO: { double x;
	        			x= n * 0.06;
	        			System.out.println("pluto " +x);
	        			break;
	                    }
			}
		}
		
		
		public static void main(String[] args) {
			
	     int n;
	     System.out.println("Enter the weight of the user(in kgs): ");
	     Scanner integer = new Scanner(System.in);
	 	  n = integer.nextInt();
	 
	 	 question6 mercury = new question6 (planet.MERCURY);
	 	 mercury.calc(n);
	 	 question6 venus = new question6 (planet.VENUS);
	 	 venus.calc(n);
	 	 question6 earth = new question6 (planet.EARTH);
	 	 earth.calc(n);
	 	 question6 mars = new question6 (planet.MARS);
	 	 mars.calc(n);
	 	 question6 jupitor = new question6 (planet.JUPITOR);
	 	 jupitor.calc(n);
	 	 question6 saturn = new question6 (planet.SATURN);
	 	 saturn.calc(n);
	 	 question6 uranus = new question6 (planet.URANUS);
	 	 uranus.calc(n);
	 	 question6 neptune = new question6 (planet.NEPTUNE);
	 	 neptune.calc(n);
	 	 question6 pluto = new question6 (planet.PLUTO);
	 	 pluto.calc(n);
		}
	}

		


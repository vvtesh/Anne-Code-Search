package Question_6;

public enum Planets {

MERCURY (0.38),
VENUS (0.91),
MARS (0.38),
JUPITER (2.34),
SATURN (1.06),
NEPTUNE (1.19),
PLUTO (0.06);
private double ratio;
Planets(double r)
{ ratio = r;
}
public double weightonotherplanets(double eweight)
{
 return eweight*ratio;
}
 }
 

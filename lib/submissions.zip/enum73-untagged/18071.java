import java.util.*;
import java.lang.*;

public class WeightPlanet  {

 public enum Planets {
    MERCURY, VENUS, MARS, EARTH, JUPITER, 
	SATURN, URANUS, NEPTUNE  }

	
Planets plan ;
public WeightPlanet(Planets plan)  {
  this.plan = plan;
}

public void funct(double n)  {
    switch(plan) {
			case MERCURY:
			    double a = (n*0.38);
			    System.out.println("Weight on mercury:" + a);
			    break;
			case VENUS:
				double b = (n*0.91); 
			     System.out.println("Weight on VENUS:" + b);
				break;
			case MARS:
			    double c = (n*0.38); 
				System.out.println("Weight on MARS:" + c);
			    break;
			case EARTH:
			    double d = (n*1.0); 
				System.out.println("Weight on EARTH:" + d);
			    break;
			case JUPITER:
			    double e = (n*2.34); 
				System.out.println("Weight on JUPITER:" + e);
			    break;
			case SATURN:
			    double f = (n*1.06);
				System.out.println("Weight on SATURN:" + f);
			    break;
			case URANUS:
			    double g = (n*0.92);
				System.out.println("Weight on URANUS:" + g);
			    break;
			case NEPTUNE:
			     double h = (n*1.19);
				System.out.println("Weight on NEPTUNE:" + h);
				break;
		}		
	}	
	public static void main(String[] args)  {
	   double n = Double.parseDouble(args[0]);
	   WeightPlanet mercury = new WeightPlanet(Planets.MERCURY);
	   mercury.funct(n);
	 WeightPlanet venus = new WeightPlanet(Planets.VENUS);
	   venus.funct(n);
	 WeightPlanet mars = new WeightPlanet(Planets.MARS);
	   mars.funct(n);
	 WeightPlanet earth = new WeightPlanet(Planets.EARTH);
	   earth.funct(n);
	 WeightPlanet jupiter = new WeightPlanet(Planets.JUPITER);
	   jupiter.funct(n);
	 WeightPlanet saturn = new WeightPlanet(Planets.SATURN);
	   saturn.funct(n);
	 WeightPlanet uranus = new WeightPlanet(Planets.URANUS);
	   uranus.funct(n);
	 WeightPlanet neptune = new WeightPlanet(Planets.NEPTUNE);
	   neptune.funct(n);
	 }
}	 
import java.util.*;


public class wop
{
	public enum Planet
{
	MERCURY,VENUS,EARTH,MARS,JUPITER,SATURN,URANUS,NEPTUNE
}

	Planet p;
	public wop(Planet p)
	{
		this.p = p;
	}
	public void calculate(double n)
	{
		
		switch(p)
		{
		case MERCURY:
		double a = (n * 0.38);
		System.out.println("weight on mercury" + a);
		break;
		
		case VENUS:
		double b = (n * 0.91);
		System.out.println("weight on venus" + b);
		break;
		
		case EARTH:
		double c = (n);
		System.out.println("weight on earth" + c);
		break;
		
		case MARS:
		double d = (n * 0.38);
		System.out.println("weight on mars" + d);
		break;
		
		case JUPITER:
		double e = (n * 2.34);
		System.out.println("weight on jupiter" + e);
		break;
		
		case SATURN:
		double f = (n * 1.06);
		System.out.println("weight on saturn" + f);
		break;
		
		case URANUS:
		double g = (n * 0.92);
		System.out.println("weight on uranus" + g);
		break;
		
		case NEPTUNE:
		double h = (n * 1.19);
		System.out.println("weight on neptune" + h);
		break;
		}
	}
	public static void main(String [] args)
		{
		double n = Integer.parseInt(args[0]); // weight on earth
		wop firstPlanet = new wop(Planet.MERCURY);
        firstPlanet.calculate(n);
		wop secondPlanet = new wop(Planet.VENUS);
        secondPlanet.calculate(n);
        wop thirdPlanet = new wop(Planet.EARTH);
        thirdPlanet.calculate(n);
		wop fourthPlanet = new wop(Planet.MARS);
        fourthPlanet.calculate(n);
        wop fifthPlanet = new wop(Planet.JUPITER);
        fifthPlanet.calculate(n);
        wop sixthPlanet = new wop(Planet.SATURN);
        sixthPlanet.calculate(n);
        wop seventhPlanet = new wop(Planet.URANUS);
        seventhPlanet.calculate(n);
		wop eighthPlanet = new wop(Planet.NEPTUNE);
        eighthPlanet.calculate(n);
		}
	}

		
		

	                                                                                                       
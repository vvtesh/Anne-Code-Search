
import java.util.Scanner;

public class Question6{
    public enum Planets{
        Mercury (3.7), Venus (8.87), Earth (9.978), Mars (3.71), Jupiter (24.92), Saturn (10.44), Uranus (8.87), Neptune (11.15), Pluto (0.58);
        private double specificGravity;
        private Planets(double sg) {
                this.specificGravity = sg;
        }
        public double getSpecficGravity(){
            return this.specificGravity;
        }
    };
    public static void main(String args[]){
        Scanner in=new Scanner(System.in);
        System.out.print("Enter weight on Earth (Kg): ");
        double weight = in.nextDouble();
        //System.out.println("Entered wieght on Earth : "+ weight);
        for (Planets planet : Planets.values()) {
            double changedWeight= (double)(weight*planet.getSpecficGravity())/Planets.Earth.getSpecficGravity();
            System.out.println("Weight on  "+ planet.name()+" is : "+ changedWeight + " Kg");
        }
    
    }
}


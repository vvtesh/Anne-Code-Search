package quest6;
import java.util.*;

import java.util.Scanner;

public class planet {
	static planeum p;
	public static void main(String[] args){
		
	/*public planet(planeum p){
		this.p= p;
	}*/
	System.out.println("Enter the weight");
	float n, x;
	Scanner in = new Scanner(System.in);
	n = in.nextInt();
	public void tellweight(n){
		
		switch (p){
		case mercury:{
			x = (float)(n * 0.38);
			System.out.println(x+ " weight on the mercury");
			break;}
		case venus:{
			x = (float)(n * 0.91);
			System.out.println(x + "weight on the venus");
			break;}
		case earth:{
			x = (float)(n *1.0);
			System.out.println(x+"weight on the earth");
			break;}
		case mars:{
			x = (float)(n*1.52);
			System.out.println(x+"weight on the mars");
			break;
		}
		case jupitar:{
			x = (float)(n* 5.2);
			System.out.println(x+"weight on jupitar");
			break;}
		case saturn:{
			x = (float)(n* 9.45);
			System.out.println(x + "weight on saturn");
			break;
		}
		case uranus:{
			x = (float)(n*19.2);
			System.out.println(x+"weight on uranus");
			break;
		}
		case neptune:{
			x = (float)(n* 30.06);
			System.out.println(x+"weight on neptune");
			break;}
			
		}
	planet mercury = new planet(planets.MERCURY);
	mercury.tellweight();
	planet venus = new planet(planets.VENUS);
	venus.tellweight();
	planet earth = new planet(planeta, EARTH);
	earth.tellweight();
	planet mars = new planet(planet.MARS);
	earth.tellweight();
	planet jupiter = new planet(planet.JUPITER);
	jupiter.tellweight();
	planet saturn = new planet(planet.SATURN);
	saturn.tellweight();
	planet uranus = new planet(planet.URANUS);
	uranus.tellweight();
	planet neptune = new planet(planets.NEPTUNE);
	neptune.tellweight();
	
	
}

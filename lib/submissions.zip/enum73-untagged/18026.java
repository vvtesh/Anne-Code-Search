
public enum Planets {
	moon(0.165),mercury(0.38),venus(0.91),mars(0.38),earth(1.00),jupiter(2.34),saturn(1.06),uranus(0.92),neptune(1.19),pluto(0.06);
	private double price; 
	// Constructor
	Planets(double p) 
	{ 
	//int n,sum;
	price = p; 
	}
	double get(double as) 
	{ 

	return price*as; 
	}

}

package question6;

import java.io.*;
import java.util.*;
import java.lang.*;

enum Planet{
	MERCURY(0.38), VENUS(0.91), EARTH(1), MARS(0.38), JUPITER(2.54), SATURN(1.08), URANUS(0.91), NEPTUNE(1.19);
	private double rg;
    Planet(double p) {
      rg = p;
    }
   double getRelativeG(){
      return rg;
   } 
}

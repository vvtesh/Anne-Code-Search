enum Planet{
MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, NEPTUNE, URANUS;
}

public class Questionsix{

Planet planets;


    public Questionsix(Planet planets) {
        this.planets = planets;
    }
    
    public void weight(int n) {
	
	//int n = Integer.parseInt(args[0]);
	double a,b,c,d,e,f,g,h;
        switch (planets) {
            case MERCURY:
			    a = n*0.38;
                System.out.println("Mercury     " +a);
                break;
                    
            case VENUS:
			    b = n*0.91;
                System.out.println("Venus       " +b);
                break;
                         
            case EARTH :
			    c = n*1;
                System.out.println("Earth       "  +c) ;
                break;
				
			case MARS :
			    d = n*0.38;
                System.out.println("Mars        " +d);
                break;
				
			case JUPITER :
			    e = n*2.36;
                System.out.println("Jupiter     "+e);
                break;
			
			case SATURN :
			    f = n*0.91;
                System.out.println("Saturn      " +f);
                break;
				
			case URANUS :
			    g = n*0.89;
                System.out.println("Uranus      " +g);
                break;
				
	    	case NEPTUNE :
			    h = n*1.12;
                System.out.println("Neptune     " +h);
                break;
                        
            default:
                System.out.println("Midweek days are so-so.");
                break;
        }
    }
    
    public static void main(String[] args) {
    	
    	int c = Integer.parseInt(args[0]);
        Questionsix first = new Questionsix(Planet.MERCURY);
        first.weight(c);
        
		Questionsix second = new Questionsix(Planet.VENUS);
        second.weight(c);
		
		Questionsix third = new Questionsix(Planet.EARTH);
        third.weight(c);
		
		Questionsix four = new Questionsix(Planet.MARS);
        four.weight(c);
		
		Questionsix five = new Questionsix(Planet.JUPITER);
        five.weight(c);
		
		Questionsix six = new Questionsix(Planet.SATURN);
        six.weight(c);
		
		Questionsix seven = new Questionsix(Planet.URANUS);
        seven.weight(c);
		
		Questionsix eight = new Questionsix(Planet.NEPTUNE);
        eight.weight(c);
    }
}



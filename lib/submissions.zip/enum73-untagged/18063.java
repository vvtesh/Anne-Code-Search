package question6;
import java.util.Scanner;

public class myWeight {
	public enum Planets {
		MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE
	}
	
	Planets myPlanet;
	public myWeight(Planets inputPlanet){
		this.myPlanet = inputPlanet;
	}
	
	public void tellMyWeight(double w) {
		switch (myPlanet){
		case MERCURY:
			System.out.printf("Mercury = %.3f kg\n",w*0.378);
			break;
		case VENUS:
			System.out.printf("Venus = %.3f kg\n",w*0.907);
			break;
		case EARTH:
			System.out.printf("Earth = %.3f kg\n", w);				
			break;
		case MARS:
			System.out.printf("Mars = %.3f kg\n", w*0.377);	
			break;
		case JUPITER:
			System.out.printf("Jupiter = %.3f kg\n", w*2.364);			
			break;
		case SATURN:
			System.out.printf("Saturn = %.3f kg\n", w*1.064);	
			break;
		case URANUS:
			System.out.printf("Saturn = %.3f kg\n", w*1.064);	
			break;
		case NEPTUNE:
			System.out.printf("Neptune = %.3f kg\n", w*1.125);	
			break;
		}
	}
	
	public static void main(String[] args){
		Scanner obj = new Scanner(System.in);
		double w = obj.nextDouble();
		myWeight Planet1 = new myWeight(Planets.MERCURY);
		Planet1.tellMyWeight(w);
		
		myWeight Planet2 = new myWeight(Planets.VENUS);
		Planet2.tellMyWeight(w);
		
		myWeight Planet3 = new myWeight(Planets.EARTH);
		Planet3.tellMyWeight(w);
		
		myWeight Planet4 = new myWeight(Planets.MARS);
		Planet4.tellMyWeight(w);
		
		myWeight Planet5 = new myWeight(Planets.JUPITER);
		Planet5.tellMyWeight(w);
		
		myWeight Planet6 = new myWeight(Planets.SATURN);
		Planet6.tellMyWeight(w);
		
		myWeight Planet7 = new myWeight(Planets.URANUS);
		Planet7.tellMyWeight(w);
		
		myWeight Planet8 = new myWeight(Planets.NEPTUNE);
		Planet8.tellMyWeight(w);
	}
}
 
import java.util.*;
import java.lang.*;
import java.io.*;

enum Planet{
	Sun	(274),
	Jupiter	(24.92),
	Neptune	(11.15),
	Saturn	(10.44),
	Earth	(9.798),
	Uranus	(8.87),
	Venus	(8.87),
	Mars	(3.71),
	Mercury	(3.7),
	Moon	(1.62),
	Pluto	(0.58);

    double val;
    Planet(double x)
    {
    	val=x;
    }

    double ReturnValue()
    {
    	return val;
    }

}
 
class question6
{
	public static void main (String[] args) throws java.lang.Exception
	{
			double a;

			System.out.println("Hey, This is ultra advanced program which tells you your weight on any of the planet (of our galaxy) and the sun.");

			System.out.println("What are you waiting for ehh??? Input your mass!");
			Scanner in = new Scanner(System.in);
			a = in.nextDouble();

			for(Planet m : Planet.values()) {
			System.out.println(m + ":" + m.ReturnValue()*a); 


 			
	}
}
}
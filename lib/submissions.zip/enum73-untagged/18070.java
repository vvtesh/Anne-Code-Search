package question6;

public class WeightCalculate {
	//Planet p;
	/*public WeightCalculate(Planet pl)
	{
		this.p = pl;
	}*/
	public static void TellWeight(float w , Planet p)
	{
		float weightonp;
		 switch (p) {
         case Mercury:
        	 weightonp = (float)(w*0.38);
             System.out.println("weight on mercury is "+weightonp);
             break;
                 
         case Venus:
        	 weightonp = (float)(w*0.91);
             System.out.println("weight on venus is "+ weightonp);
             break;
         
         case Earth:
        	 weightonp = (float)(w);
             System.out.println("weight on earth is "+ weightonp);
             break;    
                      
         case Mars:
        	 weightonp = (float)(w*0.38);
             System.out.println("weight on mars is "+ weightonp);
             break;
             
         case Jupiter:
        	 weightonp = (float)(w*2.34);
             System.out.println("weight on jupiter is "+ weightonp);
             break;
             
         case Saturn:
        	 weightonp = (float)(w*0.93);
             System.out.println("weight on saturn is "+ weightonp);
             break;    
               
         case Uranus:
        	 weightonp = (float)(w*0.92);
             System.out.println("weight on Uranus is "+ weightonp);
             break;
           
         case Neptune:
        	 weightonp = (float)(w*1.12);
             System.out.println("weight on neptune is "+ weightonp);
             break;    
         default:
             System.out.println("these are your weights");
             break;
     }
	}

}

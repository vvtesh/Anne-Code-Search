import java.util.Scanner;

public enum Question6
{
    MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE;

    static int weight;
    
    public static void PlanetWeight(Question6 P)
    {
    	double mass = weight/9.8;
        switch(P)
        {
            case MERCURY : 
            	System.out.println("Your weight on Mercury is : " + mass * 3.76);
            	break;
            	
            case VENUS :
            	System.out.println("Your weight on Venus is : " + mass * 9.04);
            	break;
            	
            case EARTH :
            	System.out.println("Your weight on Earth is : " + mass * 9.8);
            	break;
            	
            case MARS :
            	System.out.println("Your weight on Mars is : " + mass * 3.77);
            	break;
            	
            case JUPITER :
            	System.out.println("Your weight on Jupiter is : " + mass * 23.6);
            	break;
            	
            case SATURN :
            	System.out.println("Your weight on Saturn is : " + mass * 10.06);
            	break;
            	
            case URANUS :
            	System.out.println("Your weight on Uranus is : " + mass * 8.87);
            	break;
            	
            case NEPTUNE :
            	System.out.println("Your weight on Neptune is : " + mass * 11.23);
            	break;
        }
    }

    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter your weight on Earth : ");
        weight = in.nextInt();
        for(Question6 P: Question6.values())
        {
            PlanetWeight(P);
        }
    }
}
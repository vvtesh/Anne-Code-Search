

package assignment1;

import java.util.Scanner;
public class Question6 {
    
    enum Planets {
   Mercury(0.38),Venus(0.91),Earth(1),Mars(0.38),Jupiter(2.54),Saturn(1.08),Uranus(0.91),Neptune(1.19),Pluto(0.06);
   private double weight;
   Planets(double p) {
      weight = p;
   }
   double getWeight() {
      return weight;
   } 
}
    
    
    public static void main(String[] args) {
        System.out.println(" Grvitation factor of every planet relative to earth ---- >");
        System.out.println("Mercury gravitation factor => 0.38");
        System.out.println("Venus   gravitation factor => 0.91");
        System.out.println("Earth   gravitation factor =>    1");
        System.out.println("Mars    gravitation factor => 0.38");
        System.out.println("Jupiter gravitation factor => 2.54");
        System.out.println("Saturn  gravitation factor => 1.08");
        System.out.println("Uranus  gravitation factor => 0.91");
        System.out.println("Neptune gravitation factor => 1.19");
        System.out.println("Pluto   gravitation factor => 0.06");
        System.out.println("cirits claim that pluto isn't a panet because it's orbit intersects with the orbit of neptunes");
        System.out.println(" some may call it a dwarf planet");
        System.out.println("but i have added it into my list coz i still consider it as a planet");
        System.out.println("because it satisfies all the other properties of a planet except the orbit exception");
        System.out.println(""
                + "");
        try{
        System.out.println("Please enter your weight(in kgs) to calculate your weight on every planet of our solar system listed above");
      Scanner input = new Scanner(System.in);
 
      double x = input.nextInt();
      
      System.out.println("Your weight on every abovementioned 9 planets of our solar system is  --->:");
      for (Planets c : Planets.values())
      System.out.println(" You shall weigh on Planet   " + c + "     =>  "
      + c.getWeight()*x + "kgs");
      
        }
        catch(Exception e)
        {
            System.out.println("Exception occoured : "+e);
        }
                
    }
    
    
    
    
    
    
}

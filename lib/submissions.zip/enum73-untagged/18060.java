public class CalculateAndDisplay
{
	CalculateAndDisplay(int n )
	{
		Planets obj = (Planets) Enum.valueOf(Planets.class , "MERCURY") ;
		System.out.println("The weights on the planets are : ");
		switch(obj)
		{
			case MERCURY : System.out.println("Mercury : " + "\t" + n*0.378);
			case VENUS :  System.out.println("Venus : " + "\t" + n*0.907);
			case EARTH :  System.out.println("Earth : " + "\t" + n);
			case MARS :  System.out.println("Mars : " + "\t\t" + n*0.377);
			case JUPITER :  System.out.println("Jupiter : " + "\t" + n*2.364);
			case SATURN :  System.out.println("Saturn : " + "\t" + n*0.916);
			case URANUS :  System.out.println("Uranus : " + "\t" + n*0.889);
			case NEPTUNE :  System.out.println("Neptune : " + "\t" + n*1.25);
			case PLUTO :  System.out.println("Pluto : " + "\t" + n*0.067);
		}
	}
}

package Question6;

public class enums {
	public enum Planet {
		MERCURY ( 3.30e+23,  2440),
		VENUS   (4.87e+24 ,  6052),
		EARTH   (5.976e+24,  6378),
		MARS    (6.421e+23, 3397),
		JUPITER (1.9e+27,    71492 ),
		SATURN  (5.688e+26, 60268 ),
		URANUS  (8.686e+25, 25559),
		NEPTUNE (1.024e+26, 24766),
		PLUTO (1.27e+22, 1150);
	
	public double mass;
	public double radius;
	
	Planet(double mass, double radius) {
        this.mass = mass;
        this.radius = radius;
    }
	public static final double G = 6.67300E-11;
	public double surfaceGravity() {
        return G * mass / (radius * radius);
    }
	public double surfaceWeight(double otherMass) {
        return otherMass * surfaceGravity();
    }
	
	
}
}

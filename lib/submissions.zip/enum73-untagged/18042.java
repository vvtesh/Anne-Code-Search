package q6;

public class q6 {
	enum Planet{
		MERCURY(0.378),
	    VENUS(0.907),
	    EARTH(1),
	    MARS(0.377),
	    JUPITER(2.364),
	    SATURN(0.916),
	    URANUS(0.889),
	    NEPTUNE(1.125),
	    PLUTO(0.067);
	
		private final double factor;
		Planet(double factor){
			this.factor = factor;
		}
		private double factor(){return factor;}
		
		double calculate(double weight){
			return weight*factor;
		}
	}

	public int weight(int w){
		System.out.println("Your Weight on Mercury is : " + 0.378*w);
		System.out.println("Your Weight on Venus is : " + 0.907*w);
		System.out.println("Your Weight on Mars is : " + 0.377*w);
		System.out.println("Your Weight on Jupiter is : " + 2.364*w);
		System.out.println("Your Weight on Saturn is : " + 0.916*w);
		System.out.println("Your Weight on Uranus is : " + 0.889*w);
		System.out.println("Your Weight on Neptune is : " + 1.125*w);
		System.out.println("Your Weight on Pluto is : " + 0.067*w + " (We pity the poor chap)");
		return 0;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double weight = Double.parseDouble(args[0]);
		for (Planet p : Planet.values()){
			System.out.println("Your weight on " + p + " is " + p.calculate(weight) + "\n");
		}
	          
	                             
		
	}

}

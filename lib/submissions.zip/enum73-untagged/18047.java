import java.util.Scanner;

public class Question6 {
	public enum Planet {
		MERCURY(0.38), VENUS(0.91), EARTH(1.00), MARS(0.38), JUPITER(2.34), SATURN(
				1.06), URANUS(0.92), NEPTUNE(1.19);
		private double mass;

		private Planet(double mass) {
			this.mass = mass;
		}
	}

	public static void main(String[] args) {
		double a;
		System.out.println("Enter your weight on earth in Kgs:");
		Scanner in = new Scanner(System.in);
		a = in.nextInt();
		System.out.println("----------------");
		in.close();
		for (Planet p : Planet.values()) {
			float myfloat = (float) (a * p.mass);
			System.out.println(p+"\t|  " + myfloat);
		}
		System.out.println("----------------");
	}
}

package assignment1;

//import java.util.Scanner;

public enum Q6 
{
    MERCURY (0.38),
    VENUS   (0.91),
    EARTH   (1.0),
    MARS    (1.03),
    JUPITER (0.41),
    SATURN  (0.43),
    URANUS  (0.75),
    NEPTUNE (0.67);

    double gravity;
	//private static Scanner input;
    
    Q6(double gravity)
    {
        this.gravity = gravity;
    }
    
    double getWeight(double mass)
    {
    	return mass * this.gravity;
    }

    public static void main(String[] args) 
    {
    	//input = new Scanner(System.in);
    	//System.out.print("Enter weight on Earth : ");
    	//double mass = input.nextDouble();
    	double mass = Double.parseDouble(args[0]);
        for (Q6 p : Q6.values())
           System.out.printf("Your weight on %s is %f%n",
                             p, p.getWeight(mass));
    }
}

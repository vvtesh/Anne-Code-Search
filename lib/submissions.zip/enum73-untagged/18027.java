package assign1_Q6;
import java.util.*;
public enum Question6 {
    MERCURY (3.61),
    VENUS   (8.83),
    EARTH   (9.8),
    MARS    (3.75),
    JUPITER (26.0),
    SATURN  (11.2),
    URANUS  (10.5),
    NEPTUNE (13.3);

    private final double gravity;   // in kilograms
    Question6(double gravity) {
        this.gravity= gravity;
    }
    /*double surfaceWeight(double otherMass) {
        return otherMass * surfaceGravity();
    }*/
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        double earthWeight= scan.nextDouble();
        double mass = earthWeight/9.8;
        for (Question6 p : Question6.values())
        {
        	System.out.println("Your weight on "+p+" is "+ mass*p.gravity);
           //System.out.printf("Your weight on %s is %f%n",p, p.surfaceWeight(mass));
        }
    }
}
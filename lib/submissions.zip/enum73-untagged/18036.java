public class Question6 {

    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        int ourWeight = Integer.parseInt(args[0]);
        
        Planets mercury = Planets.Mercury;
        Planets venus = Planets.Venus;
        Planets earth = Planets.Earth;
        Planets mars = Planets.Mars;
        Planets jupiter = Planets.Jupiter;
        Planets saturn = Planets.Saturn;
        Planets uranus = Planets.Uranus;
        Planets neptune = Planets.Neptune;
        
        mercury.weight = 0.378 * ourWeight;
        venus.weight = 0.907 * ourWeight;
        earth.weight = ourWeight;
        mars.weight = 0.377 * ourWeight;
        jupiter.weight = 2.364 * ourWeight;
        saturn.weight = 1.064 * ourWeight;
        uranus.weight = 0.889 * ourWeight;
        neptune.weight = 1.125 * ourWeight;
        
        System.out.println("Weight of person on Mercury is "+ mercury.weight);
        System.out.println("Weight of person on Venus is "+ venus.weight);
        System.out.println("Weight of person on Earth is "+ earth.weight);
        System.out.println("Weight of person on Mars is "+ mars.weight);
        System.out.println("Weight of person on Jupiter is "+ jupiter.weight);
        System.out.println("Weight of person on Saturn is "+ saturn.weight);
        System.out.println("Weight of person on Uranus is "+ uranus.weight);
        System.out.println("Weight of person on Neptune is "+ neptune.weight);
    }

}
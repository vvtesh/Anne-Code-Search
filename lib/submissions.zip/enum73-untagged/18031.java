package Question6;

public enum Question6 {
	
	    Mercury (3.303e+23, 2.4397e6),
	    Venus   (4.869e+24, 6.0518e6),
	    Earth   (5.976e+24, 6.37814e6),
	    Mars    (6.421e+23, 3.3972e6),
	    Jupiter (1.9e+27,   7.1492e7),
	    Saturn  (5.688e+26, 6.0268e7),
	    Uranus  (8.686e+25, 2.5559e7),
	    Neptune (1.024e+26, 2.4746e7);

	     final double mass;   
	     final double radius;  
	    Question6(double mass, double radius) {
	        this.mass = mass;
	        this.radius = radius;
	    }
	    double mass() { 
	        return mass;
	        }
	    double radius() { 
	        return radius;
	        }

	    
	    public static double G = 6.67300E-11;

	    double surfaceGravity() {
	       double val1=G * mass / (radius * radius);
	        return val1;
	    }
	    double surfaceWeight(double otherMass) {
	        double val2=otherMass*surfaceGravity();
	        return val2;
	    }
	    public static void main(String[] args) {
	        if (args.length != 1) {
	            System.err.println("oops you forgot to enter your weight");
	            System.exit(0);
	        }
	        double UserWeight = Double.parseDouble(args[0]); //input from user
	        double mass = UserWeight/Earth.surfaceGravity();
	        for (Question6 w : Question6.values())
	           System.out.printf("Weight on %s is %f%n",
	                             w, w.surfaceWeight(mass));
	    }

	}


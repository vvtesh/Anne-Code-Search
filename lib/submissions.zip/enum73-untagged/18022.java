package ap2014asgnmnt1Ques6;

public enum Planets 
	{
		Mercury(0.38), 
	    Venus(0.91), 
	    Earth(1.0), 
	    Mars(0.38), 
	    Jupiter(2.36), 
	    Saturn(0.91), 
	    Uranus(0.89),
	    Neptune(1.12);
		
		double value;
	    
	    private Planets(double value)
	    {
	        this.value = value;
	    }
	}
	

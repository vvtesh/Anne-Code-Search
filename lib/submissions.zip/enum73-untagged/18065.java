package ap2014.asgnmnt1.question6;

public enum Planets {

	MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE;

	public static double surface_gravity, g = 9.8;

	public static double get_surface_gravity(Planets planet) {
		if (planet.equals(MERCURY)) {
			return 0.38 * g;
		} else if (planet.equals(VENUS)) {
			return 0.91 * g;
		} else if (planet.equals(EARTH)) {
			return 1.0 * g;
		} else if (planet.equals(MARS)) {
			return 0.38 * g;
		} else if (planet.equals(JUPITER)) {
			return 2.34 * g;
		} else if (planet.equals(SATURN)) {
			return 0.93 * g;
		} else if (planet.equals(URANUS)) {
			return 0.92 * g;
		} else if (planet.equals(NEPTUNE)) {
			return 1.12 * g;
		}
		return 0.0;
	}

	public static double weight_on_planet(double mass_on_earth, Planets planet) {
		return mass_on_earth * get_surface_gravity(planet);
	}

	
	
}

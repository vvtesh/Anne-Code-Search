//mdm

public enum Planet {


                            MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE;

  int w;
  
  
	public static void weightConversion(Planet x,int w){
		
	 if(x==MERCURY)
	    	System.out.println("Equivalent weight on Mercury is : " + w*0.378);
	 else if(x==VENUS)
	    	System.out.println("Equivalent weight on Venus is : " + w*0.907);
	 else if(x==EARTH)
	    	System.out.println("Equivalent weight on Earth is : " + w);
	 else if(x==MARS)
	    	System.out.println("Equivalent weight on Mars is : " + w*0.377);
	 else if(x==JUPITER)
	    	System.out.println("Equivalent weight on Jupiter is : " + w*2.364);
	 else if(x==SATURN)
	    	System.out.println("Equivalent weight on Saturn is : " + w*0.916);
	 else if(x==URANUS)
	    	System.out.println("Equivalent weight on Uranus is : " + w*0.889);
	 else if(x==NEPTUNE)
	    	System.out.println("Equivalent weight on Neptune is : " + w*1.125);
	
	}

}


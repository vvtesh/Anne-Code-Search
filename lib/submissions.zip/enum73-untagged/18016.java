package ap2014.asgnmnt1.question6;

public enum planets {
	Mercury (3.3022 * Math.pow(10, 23) , 2.4397 * Math.pow(10, 6)), 
	Venus (4.869 * Math.pow(10, 24) , 6.0518 * Math.pow(10, 6)), 
	Earth (5.976 * Math.pow(10, 24) , 6.37814 * Math.pow(10, 6)), 
	Mars(6.421 * Math.pow(10, 23) , 3.3972 * Math.pow(10, 6)), 
	Jupiter(1.9 * Math.pow(10, 27) , 7.1492 * Math.pow(10, 7)), 
	Saturn(5.688 * Math.pow(10, 26) , 6.0268 * Math.pow(10, 7)), 
	Uranus(8.868 * Math.pow(10, 25) , 2.5559 * Math.pow(10, 7)), 
	Neptune(1.024 * Math.pow(10, 26) , 2.4746 * Math.pow(10, 7));
	private double mass;
	private double radius;
	planets(double mass, double radius)
	{
		this.mass = mass;
		this.radius = radius;
	}
	double G = 6.673 * Math.pow(10, -11);
	public double g()
	{
		return G * mass / (radius * radius);
	}
	public double weight(double masss)
	{
		return masss * g();
	}
}
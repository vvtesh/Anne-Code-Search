import java.util.*;

public enum Question6
{
	MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE;

	static int w;
	public static void printWeight(Question6 P)
	{
		switch(P)
		{
			case MERCURY : System.out.println("Weight on Mercury is : " + w*0.38);
						   break;
			case VENUS : System.out.println("Weight on Venus is : " + w*0.91);
						   break;
			case EARTH : System.out.println("Weight on Earth is : " + w);
						   break;
			case MARS : System.out.println("Weight on Mars is : " + w*0.38);
						   break;
			case JUPITER : System.out.println("Weight on Jupiter is : " + w*2.36);
						   break;
			case SATURN : System.out.println("Weight on Saturn is : " + w*0.91);
						   break;
			case URANUS : System.out.println("Weight on Uranus is : " + w*0.89);
						   break;
			case NEPTUNE : System.out.println("Weight on Neptune is : " + w*1.12);
						   break;
		}
	}

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.print("Enter your weight on Earth : ");
		w = in.nextInt();
		for(Question6 P: Question6.values())
		{
			printWeight(P);
		}
	}
}
public enum Planets {
	mercury(0.38),
	venus(0.91),
	earth(1),
	mars(0.38),
	jupiter(2.36),
	saturn(0.91),
	uranus(0.89),
	neptune(1.12);
	
	public final double multiplier;
	
	Planets(double X){
		multiplier = X;
	}
	
	public double getMultiplier(){
		return multiplier;
	}
}

package Q6;

public enum quest6 {
    Mars    (6.421e+23, 3.3972e6),
    Jupiter (1.9e+27,   7.1492e7),
    Mercury (3.303e+23, 2.4397e6),
    Venus   (4.869e+24, 6.0518e6),
    Earth   (5.976e+24, 6.37814e6),
    Saturn  (5.688e+26, 6.0268e7),
    Uranus  (8.686e+25, 2.5559e7),
    Neptune (1.024e+26, 2.4746e7);

    private double m;   
    private double r; 
    
    quest6(double m, double r) {
        this.m = m;
        this.r = r;
    }
    
    // univ. gravitational const.
    public static double G = 6.67300E-11;

    double surfg() {
        return G * m / (r * r);
    }
    double surfwt(double extmass) {
        return extmass * surfg();
    }
    public static void main(String[] args) {
	
    	double earthwt = Double.parseDouble(args[0]);
    	double m = earthwt/Earth.surfg();
    	for (quest6 a : quest6.values())
    		System.out.printf("Your weight on %s is %f%n",
                    a, a.surfwt(m));    }
}



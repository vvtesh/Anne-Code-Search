/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ques6;
import java.util.Scanner;
public class Ques6 {





  public enum Planets {
  Mercury (3.303e+23, 2.4397e6),
  Venus   (4.869e+24, 6.0518e6),
  Earth   (5.976e+24, 6.37814e6),
  Mars    (6.421e+23, 3.3972e6),
  Jupiter (1.9e+27,   7.1492e7),
  Saturn  (5.688e+26, 6.0268e7),
  Uranus  (8.686e+25, 2.5559e7),
  Neptune (1.024e+26, 2.4746e7),
  Pluto   (1.27e+22,  1.137e6);
 
  private final double mass_inKg,radius_inMeter;   
  public static final double G = 6.67300E-11;
  
  Planets(double mass_inKg, double radius_inMeter) {
      this.mass_inKg = mass_inKg;
      this.radius_inMeter = radius_inMeter;
  }
  
  public double surfaceGravity() {
      return G * mass_inKg / (radius_inMeter * radius_inMeter);
  }
  public double mass_inKg()   { 
      return mass_inKg;
  }
  
  
  public double radius_inMeter() 
  { 
      return radius_inMeter;
  }
  
   
  
  public double surfaceWeight(double otherMass) {
      return otherMass * surfaceGravity();
  }
}
 

public static void main(String[] args) {
    Planets pE = Planets.Earth;
    double earthRadius = pE.radius_inMeter(); 
 
    
Scanner inputReader = new Scanner(System.in);

System.out.println("Please enter ur weight:");
double earthWeight = inputReader.nextInt();
   
double mass_inKg = earthWeight/pE.surfaceGravity();
for (Planets p : Planets.values())
System.out.printf("On %s---> %f%n",p, p.surfaceWeight(mass_inKg));


    
}
}


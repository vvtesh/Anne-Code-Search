package ap2014.assignment1.Question6;

import java.util.Scanner;


	public class question6 {
		
		
		 
		 enum Planets
		{
			Jupiter
			{
				 public double setval()
				{
					return 24.92;
				}
			},
			Mercury
			{
				 public double setval()
				{
					return 3.7;
				}
			},
		     Venus
			{
				 public double setval()
				{
					return 8.87;
				}
			},
			Earth
			{
				 public double setval()
				{
					return 9.79;
				}
			},
			Mars
			{
				public double setval()
				{
					return 3.71;
				}
			},
			Saturn
			{
				 public double setval()
				{
					return 10.44;
				}
			},
			Neptune
			{
				 public double setval()
				{
					return 11.15;
				}
			},
			Uranus
			{
				public double setval()
				{
					return 8.87;
				}
			};
			
			
			 public abstract double setval();
			
		}
			
			
		 public  void calWeight(double w)
			{
				double mass,x,sg;
				
				x=Planets.Earth.setval();
				mass=w/x;
				double weight;
		
				for (Planets p : Planets.values()) {
					  sg= p.setval();
					  weight=mass*sg;
					  
					  System.out.println("your weight on "+ p + " is " + weight);
					}
				
				
			}	
		
			public static void main(String args[])
			{
				double w;
				System.out.print("enter your weight on earth");
				Scanner scan=new Scanner(System.in);
				w=scan.nextDouble();
				question6 obj=new question6();
				obj.calWeight(w);
			}
		
		
		

	}




//Note: First take Command argument through run configuration then run your own choices of input
package apAssignment1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class EnumPlanet {
	public enum Planets {

		MERCURY (0.38),
		VENUS   (0.91),
		EARTH   (1.0),
		MARS    (0.38),
		JUPITER (2.34),
		SATURN  (0.93),
		URANUS  (0.92),
		NEPTUNE (1.12);

		private final double sg;  // in kilograms
    
		Planets(double surfaceG){
			this.sg = surfaceG ;
		}
    
		double getwgt(){
			return sg ;
		}	
   }
	
    public static void main(String[] args) throws IOException {
    	System.out.print("Enter Your Weight in kg: ") ;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		if (args.length>0) {
			args[0]=br.readLine();
			try{
				double earth_wgt = Double.parseDouble(args[0]);
				for (Planets p : Planets.values())
					System.out.printf("Your weight on " + p + " is " + (p.getwgt()*earth_wgt) + " kg\n");
				}
			catch (NumberFormatException e) {
		        System.err.println("Command Line input '" + args[0] + "' must be an integer.");
		        System.exit(1);
			}
		}
    }
}

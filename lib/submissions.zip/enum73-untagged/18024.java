package question6;

public enum Planets{
	   MERCURY(0.38),VENUS(0.91),EARTH(1.0),MARS(0.38),JUPITER(2.36),SATURN(0.91),URANUS(0.89),NEPTUNE(1.12);
	   
	   private double factor;
	   Planets(double factor)
	   {
		   this.factor = factor;
	   }
	   
	  
	   public double Weight(double EarthMass) {
	        return EarthMass * factor;
	    }

}

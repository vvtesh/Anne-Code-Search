package planets;

import java.util.Scanner;

public class planetsenum  {
 
    public enum Planets{
        MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE
    }
 
    Planets cName;
 
    public planetsenum(Planets cName) {
        this.cName = cName;
    }
    
    
 
    public void weightcalculate(float weight) {
    	float finalweight;
        switch (cName)
        {
        
        case MERCURY:
        {finalweight = (float)(weight * (0.38));
            System.out.println(finalweight+ "is the user weight on Mercury");
            break;
        }
        
        case VENUS:
        {finalweight = (float)(weight*0.91);
            System.out.println(finalweight + "is the user weight on Venus");
            break;
        }
      
        case EARTH:
        {finalweight = weight*1;
            System.out.println(finalweight+"is the user weight on Earth");
            break;
        }
        
        case MARS:
        {finalweight = (float)(weight*(0.38));
            System.out.println(finalweight + "is the user weight on Mars");
            break;
        }
        
        case JUPITER:
        {finalweight = (float)(weight*2.34);
            System.out.println(finalweight + "is the user weight on Jupiter");
            break;
        }
        
        
        case SATURN:
        {finalweight = (float)(weight*0.93);
            System.out.println(finalweight + "is the user weight on Saturn");
            break;
        }
        
        
        case URANUS:
        {finalweight = (float)(weight*0.92);
            System.out.println(finalweight + " is the user weight on Uranus");
            break;
        }
        
        case NEPTUNE:
        {finalweight = (float)(weight*1.12);
            System.out.println(finalweight + " is the user weight on Neptune");
            break;
        }
        
        
        
        
        }
    }
 
    public static void main(String[] args) {
    	
    	float userweight;
    	Scanner in = new Scanner(System.in);
        System.out.println("Enter user weight:");
        userweight = in.nextFloat();
                
        
        planetsenum mercury = new planetsenum(Planets.MERCURY);
        mercury.weightcalculate(userweight);
    
         
        planetsenum venus = new planetsenum(Planets.VENUS);
        venus.weightcalculate(userweight);
        
        planetsenum earth = new planetsenum(Planets.EARTH);
        earth.weightcalculate(userweight);
        
        planetsenum mars = new planetsenum(Planets.MARS);
        mars.weightcalculate(userweight);
        
        planetsenum jupiter = new planetsenum(Planets.JUPITER);
        jupiter.weightcalculate(userweight);
        
        planetsenum saturn = new planetsenum(Planets.SATURN);
        saturn.weightcalculate(userweight);
        
        
        planetsenum uranus = new planetsenum(Planets.URANUS);
        uranus.weightcalculate(userweight);
        
        planetsenum neptune = new planetsenum(Planets.NEPTUNE);
        neptune.weightcalculate(userweight);
    }
}


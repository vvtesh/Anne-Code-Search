#include<stdio.h>
#include<stdlib.h>

typedef struct node node;
typedef struct nodeData nodeData;
typedef struct list list;

/*
	In this deq next will be pointing towards front and prev would be towards rear
*/

// START OF DEQ TEMPLATE BY DG
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////


struct nodeData
{
	long data;
};

struct  node
{
	nodeData data;
	node * next;
	node * prev;	
};

// LIST TEMPLATE

struct list
{
	node * front;
	node * rear;
};

void insertAfter(node ** front , node ** rear , node* selector , node * toBeInserted) // insterr towards next
{
	node * towardsFront = selector->next;
	node * towardsRear = selector->prev;

	if(towardsFront != NULL)
	{
		towardsFront->prev = toBeInserted;
	}
	else
	{
		*front = toBeInserted;
	}


	selector->next = toBeInserted;
	toBeInserted->next = towardsFront;
	toBeInserted->prev = selector;

}

void insertBefore(node ** front , node ** rear , node* selector , node * toBeInserted) // insterr towards rear
{
	node * towardsFront = selector->next;
	node * towardsRear = selector->prev;

	if(towardsRear != NULL)
	{
		selector->prev = toBeInserted;
		toBeInserted->prev = towardsRear;
		toBeInserted->next = selector;
		towardsRear->next = toBeInserted;
	}
	else
	{
		*rear = toBeInserted;
		selector->prev = toBeInserted;
		toBeInserted->prev = towardsRear;
		toBeInserted->next = selector;
	}
}


node * addFront(node ** front , node ** rear , nodeData data)
{
	node * temp =(node *) malloc(sizeof(node));
	temp->data = data;
	temp->next = NULL;
	temp ->prev= NULL;

	if(*front == NULL) // deq empty
	{
		*front = temp;
		*rear = temp;	
	}
	else
	{
		(*front)->next = temp;
		temp->prev = *front;
		*front = temp;
	}


	return temp;

}

node * addRear(node ** front , node ** rear , nodeData data)
{
	node * temp = (node *) malloc(sizeof(node));
	temp->data = data;
	temp->next = NULL;
	temp->prev = NULL;

	if(*rear == NULL)
	{
		*front = temp;
		*rear = temp;
	}
	else
	{
		(*rear)->prev = temp;
		temp->next = *rear;
		*rear = temp;
	}

	

	return temp;

}


void addRearNode(node ** front , node ** rear , node * data)
{
	
	data->next = NULL;
	data->prev = NULL;

	if(*rear == NULL)
	{
		*front = data;
		*rear = data;
	}
	else
	{
		(*rear)->prev = data;
		data->next = *rear;
		*rear = data;
	}

	


}


void deleteNode(node ** front , node ** rear , node * toBeDeletad)
{
	if(*front == NULL && *rear == NULL)
		return;

	node * towardsFront = toBeDeletad->next;
	node * towardsRear = toBeDeletad->prev;

	if(towardsFront != NULL)
	{
		towardsFront->prev = towardsRear;
	}
	else
	{
		*front = towardsRear;
	}

	if(towardsRear != NULL)
	{
		towardsRear->next = towardsFront;
	}
	else
	{
		*rear = towardsFront;
	}

	// free(tobedeleted)
}

void printDeq(node ** front , node ** rear )
{
	node * temp;
	temp = *front;
	while(temp != NULL)
	{
		printf("%d\n", (temp->data).data);
		temp = temp->prev;
	}
	 
}

void printDeqRev(node ** front , node ** rear )
{
	// printf("rev\n");
	node * temp;
	temp = *rear;
	while(temp != NULL)
	{
		printf("%d\n", (temp->data).data);
		temp = temp->next;
	}
	 
}

void swapNodes(node * n1 , node*n2)
{
	nodeData tempdata = n1->data;
	n1->data = n2->data;
	n2->data = tempdata;
}

// END OF DEQ TEMPLATE BY DG
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////






void initList(list * l)
{
	l->front = NULL;
	l->rear = NULL;
}

void listInsertAfter(list * l  , node* selector , node * toBeInserted)
{
	insertAfter(&(l->front) , &(l->rear) , selector , toBeInserted);
}

void listInsertBefore(list * l  , node* selector , node * toBeInserted)
{
	insertBefore(&(l->front) , &(l->rear) , selector , toBeInserted);
}


node * listAddFront(  list * l  , nodeData data)
{
	addFront(&(l->front) , &(l->rear) ,  data);
}

node * listAddRear(  list * l  , nodeData data)
{
	addRear(&(l->front) , &(l->rear) ,  data);
}

void listDeleteNode(list * l, node * toBeDeletad)
{
	 deleteNode(  &(l->front) ,   &(l->rear)  ,  toBeDeletad);
}

void listPrint(list * l)
{
	printDeq(&(l->front) ,   &(l->rear));
}

void listPrintRev(list * l)
{
	// printf("pr \n");
	printDeqRev(&(l->front) ,   &(l->rear));
}

void listAddRearNode(list * l  , node * data)
{
	addRearNode( &(l->front) ,   &(l->rear) ,   data);
}

list * jonLists(list * l1 , list * l2)
{

	if(l1->rear == NULL)
		return l2;
	if(l2->rear == NULL)
		return l1;

	(l1->rear)->prev = l2->front;
	(l2->front)->next = l1->rear;

	list * l;
	l->front = l1->front;
	l->rear = l2->rear;

	(l->front)->next = NULL;
	(l->rear)->prev = NULL;


	return l; 
}

//END OF LIST TEMPLATE
list * mergeLists(list * l1 , list * l2)
{
	list * l = (list *)malloc(sizeof(list));
	initList(l);

	node * tempI = l1->front;

	node * tempJ = l2->front;

	while( 1 )
	{
		if(tempI==NULL)
			break;

		if(tempJ==NULL) break;


		
		if(tempI->data.data < tempJ->data.data)
		{
			node * nextTempI = tempI->prev;
			listAddRearNode(l , tempI);
			tempI = nextTempI;
			//printf("%d n \n", nextTempI->data.data);
			//printf("if 1\n");
		}
		else
		{
			node * nextTempJ = tempJ->prev;
			listAddRearNode(l , tempJ);
			tempJ = nextTempJ;

		}
	}
 
 
	while(tempI != NULL )
	{
		node * nextTempI = tempI->prev;
		listAddRearNode(l , tempI);
		tempI = nextTempI;
	}
 

	while(tempJ != NULL)
	{
		node * nextTempJ = tempJ->prev;
		listAddRearNode(l , tempJ);
		tempJ = nextTempJ;
	}

	return l;

}

node * getMidList(list * l)
{
	node * temp = l->front;
	int n = 0;
	while(temp != NULL)
	{
		temp = temp->prev;
		n++;
	}
	// printf("%d\n",n );
	int i;
	temp =  l->front;
	for(i=0;i<n/2-1 ; i++)
	{
		temp = temp->prev;
	}
	return temp;
}


list *mSortList(list * l)
{

	if(l->front == l->rear) 
		return l;

	list * l1 = (list*)malloc(sizeof(list));
	list * l2 = (list*)malloc(sizeof(list));

	l1->front = l->front;
	l2->rear = l->rear;

	node * mid = getMidList(l);
	node * midNext = mid->prev;

	mid->prev = NULL;
	midNext->next = NULL;

	l2->front = midNext;
	l1->rear = mid;

 
	l1 = mSortList(l1);
	// printf("sorted ");
 
	l2 = mSortList(l2);
 
 
	list * lll = mergeLists(l1 , l2);
 

	return lll;
}

void findSumWithMaxDiff(list * l1 , long n ,long num)
{
	node * tempI = l1->front;
	node * tempJ = l1->rear;

	long i = 0;
	long j = n-1;

	while(1)
	{
		// printf("ha\n");
		if( (tempJ != NULL &&  tempJ->prev == tempI) || (tempI != NULL &&  tempI->next == tempJ)   )
		{
			printf("NO");
			return;
		}



		long curSum = tempI->data.data + tempJ->data.data;

		if(curSum > num)
		{
			tempJ = tempJ->next;
			j--;
		}
		else if(curSum < num)
		{
			tempI = tempI->prev;
			i++;
		}
		else
		{
			printf("%d %d %d %d", i , j , tempI->data.data , tempJ->data.data);
			return;
		}


	}

}

int main()
{

    long n , num;
 
	scanf("%lld" , &n);

	scanf("%lld" , &num);
 
	list l;
	initList(&l);

	nodeData tempdata;

	long inCode;
	long i;
 


	for( i=0;i<n;i++)
	{

		scanf("%lld" , &inCode);
		tempdata.data = inCode;
		listAddRear(&l , tempdata);
	}

	// listPrint(&l);

	findSumWithMaxDiff(&l , n , num);
	

	

	return 0;


}
#include<stdio.h>

int main()
{
    long long int n,x,*a,i,found=0;
    scanf("%lld%lld",&n,&x);
    a=(long long int*)malloc(n*sizeof(long long int));
    for(i=0;i<n;i++)
        scanf("%lld",&a[i]);
    int s=0,e=n-1;
    while(s<e){
        if(a[s]+a[e]==x){
            printf("%lld %lld %lld %lld",s,e,a[s],a[e]);
            found=1;
            break;
         }
         else if(a[s]+a[e]<x)
            s++;
         else
            e--;
    }
    if(found==0)
        printf("NO\n");
    free(a);
    return 0;
}

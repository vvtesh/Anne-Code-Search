#include<stdio.h>
int main(){int n,a,i,flag=0,flagbreak=0;scanf("%d%d",&n,&a);int arr[n];
	for(i=0;i<n;i++)scanf("%d",&arr[i]);
	int	low = 0;
	int high= n-1;
	while(low <= high)
	{
   int x = arr[low];
   int y = arr[high];
   long long int total = x+y;
   if(total == a)
      flag=1;
   else if(total> a)
      high--;
   else low++;  
    
   if(flag==1){
    printf("%d %d %d %d",low,high,x,y);flagbreak=1;break;} 
	}if(flagbreak==0)printf("NO");
	return 0;
	}
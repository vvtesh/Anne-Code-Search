#include<stdio.h>
int main()
{
    int j; int n;int sum;
    scanf("%d",&n); int a[n];
    scanf("%d",&sum);
    for(j=0;j<n;j++)
        scanf("%d",&a[j]);
    int i=0,k=n-1;
    int tempsum;
    while(i < k)
    {
        tempsum=a[i]+a[k];

            if(tempsum == sum)
            {
                printf("%d %d %d %d\n",i,k,a[i],a[k]);
                break;
                i++;k--;
            }
            else if(tempsum<sum)
            {
               i++;
            }
            else
            {
              k--;
            }


    }
    if(i>=k){
    printf("NO");}

  return 0;
}


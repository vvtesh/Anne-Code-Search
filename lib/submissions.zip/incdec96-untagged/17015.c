#include<stdio.h>

#define sll(n) scanf("%lld",&n)
#define fo(i,a,b)	for(i=a;i<b;i++)
typedef long long ll;

ll a[1000001];

int main()
{
	int flag=0;
	ll A,n,i,j,temp1,temp2;
	sll(n);
	sll(A);
	fo(i,0,n)
		sll(a[i]);
	i=0;
	j=n-1;
	while(i!=j)
	{
		if(a[i]+a[j]==A)
		{
			temp1=i;
			temp2=j;
			flag=1;
			break;
		}
		if(a[i]+a[j]>A)
			j--;
		else
			i++;

	}
	if(flag==0)
		printf("NO");
	else
	{
		printf("%lld %lld %lld %lld",i,j,a[i],a[j]);
	}
	return 0;
}
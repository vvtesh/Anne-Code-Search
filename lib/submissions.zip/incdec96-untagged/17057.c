#include <stdio.h>
#include <stdlib.h>

#define si(a) scanf("%d",&a)

int main(){
	//freopen("in", "r", stdin);
	int n,k,a[1000010],i=0,j=0; si(n); si(k);
	for(i=0;i<n;i++)
		si(a[i]);
	i=0; j=n-1;
	while(a[i]+a[j]!=k&&i<n&&j>0){
		if(i+j<k)i++;
		else j--;
	}
	if(a[i]+a[j]==k)
		printf("%d %d %d %d", i, j, a[i], a[j]);
	else printf("NO");
	return 0;
}
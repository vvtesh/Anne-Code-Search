#include<stdio.h>
int main()
{
    unsigned long A[1000000];
    unsigned long n,sum,temp,k,i,j=0;
    int a=1;
    scanf("%lu %lu",&n,&sum);
    for(i=0;i<n;i++)
    {
       scanf("%lu",&A[i]);
    }
    k=n-1;
while(j<k)
{
    temp=A[j]+A[k];
    if(temp==sum)
    {
        printf("%lu %lu %lu %lu\n",j,k,A[j],A[k]);
        a=0;
        break;
    }
    else if(temp>sum)
    {
        k--;
    }
    else
    {
       j++;
    }
}
if(a!=0)
{
   printf("NO\n");
}

return 0;
}

#include<stdio.h>
#include<stdlib.h>

struct node
{
int x;
struct node *prev;
struct node *next;
}*start=NULL,*tail=NULL; 






int insertend(int x)
{
struct node *temp,*save=start;
if(start==NULL&&tail==NULL)
{
start=(struct node *)malloc(sizeof(struct node));
start->x=x;
start->next=NULL;
start->prev=NULL;
tail=start;
}
else
{
temp=(struct node *)malloc(sizeof(struct node));
temp->x=x;
tail->next=temp;
temp->prev=tail;
temp->next=NULL;
tail=temp;
}
return 0;
}




int search(int n,int N,struct node *temp,struct node *last)
{
int i=1,j=N,M=N,k=0;
while(M>0)
{
if((temp->x+last->x)==n){
printf("%d %d %d %d\n",i-1,j-1,temp->x,last->x);
k=1;
break;
}
else if((temp->x+last->x)>n){
last=last->prev;
j--;}
else if((temp->x+last->x)<n){
temp=temp->next;
i++;}
M--;
}
if(k==0)
printf("NO\n");
return(0);
}





int main()
{
int N,x,A,i;
scanf("%d%d",&N,&A);
for(i=0;i<N;i++){
scanf("%d",&x);
insertend(x);
}
struct node *temp=start;
struct node *save=start;
struct node *last=tail;
search(A,N,temp,last);
return(0);
}



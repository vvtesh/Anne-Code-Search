#include<stdio.h>
int main()
{
int n,sum;
    int ele;
int flag=0;
    int i=0;
int k;
    //printf("enter no of elements and sum");
    scanf("%d%d", &n, &sum);
    int arr[n];
     int j=n-1;
    for(k=0;k<n;k++)
        scanf("%d", &arr[k]);

    while(i<j)
    {
        if((arr[i]+arr[j])==sum)
            {printf("%d %d %d %d",i,j,arr[i], arr[j]);
            flag=1;
            break;}
        else if((arr[i]+arr[j])<sum)
        {
            i=i+1;
           // printf("go\n");

        }
        else
    {
        j=j-1;
       // printf("jo\n");
    }

    }
    if(flag==0)
        printf("NO");
return 0;}







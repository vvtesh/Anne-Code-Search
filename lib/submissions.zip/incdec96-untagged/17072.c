#include <stdio.h>
#include <malloc.h>

int main() {
	int i,n,s,*a,b,c=0;
	scanf("%d %d",&n,&s);
	//printf("a");
	a=(int*)malloc(sizeof(int)*n);
	//printf("b");
	//printf("%d",n);
	for(i=0;i<n;i++) {
		//printf("c");
		scanf("%d",&a[i]); }
	i=0;
	int j=n-1;
	while(i<j) {
		b=a[i]+a[j];
		if(b==s) {
			c=1;
			printf("%d %d %d %d", i, j, a[i], a[j]);
			break;
		}
		if(b<s) i++;
		else if(b>s) j--; 
	}
	if(c==0) printf("NO");
	return 0;
}
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num, sum;
    scanf("%d %d", &num, &sum);
    int arr[num];
    int i=0;
    int j=num-1;
    int k=0;
   // int s;
    int flag=0;

    for(i=0;i<num;i++)
    {
         scanf("%d",&arr[i]);
    }
    

    while(j>0 && k<num-1)
    {
        if(sum==arr[j]+arr[k])
        {
            printf("%d %d %d %d",k,j,arr[k],arr[j]);
            flag=1;
            break;
        }
        else if (sum<arr[j]+arr[k])
        {
            j--;

        }
        else if(sum>arr[j]+arr[k])
        {
            k++;
        }
        else
        {
            flag=0;
        }
    }
    if(flag==0)
    {
        printf("NO");
    }
    return 0;

}
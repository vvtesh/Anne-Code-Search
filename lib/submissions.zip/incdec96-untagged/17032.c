#include <stdio.h>
int main()
{
    long long int n,s;
    scanf("%lld %lld",&n,&s);
    long long int a[n],i,j;
    for(i=0;i<n;i++)
    {
        scanf("%lld",&a[i]);
    }
    i=0;j=n-1;
    long long int sum;
    while(i!=j)
    {
        sum=a[i]+a[j];
        if(sum>s)
        {
            j--;
        }
        else if(sum<s)
        {
            i++;
        }
        else if(sum==s)
        {
            printf("%lld %lld %lld %lld\n",i,j,a[i],a[j]);
            break;
        }
    }
    if(i==j)
    {
        printf("NO\n");
    }
    return 0;
}

#include<stdio.h>

int main()
{	
	int n,a,i;
	scanf("%d",&n);
	scanf("%d",&a);
	int Arr[n];
	for(i=0;i<n;i++)
	{	
		scanf("%d",&Arr[i]);
	}
	int *p1=Arr;
	int *p2=&Arr[n-1];
	//printf("%d  %d",*p1,*p2);
	i=0;
	int flag=0,j=n-1;
	while(p1!=p2 && flag==0)
	{	
		if((*p1)+(*p2)==a)
		{
			flag++;
		}
		else if((*p1)+(*p2)>a)
		{
			p2--;
			j--;	
		}
		else
		{
			p1++;
			i++;
		}
	}
	if(flag!=0)
	{
		printf("%d %d %d %d",i,j,*p1,*p2);
	}
	else
		printf("NO");
	return 0;
}

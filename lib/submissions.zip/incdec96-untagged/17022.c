#include<stdio.h>
#include<stdlib.h>

#define rep(i,s,e) for(i=s;i<=e;i++)
#define rrep(i,s,e) for(i=s;i>=e;i--)

long long ARR[1000100];

long long main()
{
  long long i,N,A,j,flag=0;

  scanf("%lld%lld",&N,&A);
  rep(i,0,N-1)
  {
      scanf("%lld",&ARR[i]);
  }

  for(i=0,j=N-1;i<N/2,j>N/2;)
  {
      if(ARR[i]+ARR[j]<A)
        i++;
      else if(ARR[i]+ARR[j]>A)
        j--;
      else if(ARR[i]+ARR[j]==A)
      {
          flag=1;
          break;
      }
  }

  if(flag==1)
  {
       printf("%lld %lld %lld %lld",i,j,ARR[i],ARR[j]);
  }
  else
       printf("NO");

  return 0;
}

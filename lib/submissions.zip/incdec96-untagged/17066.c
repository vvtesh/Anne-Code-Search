#include<stdio.h>
int main()
{
    int arr[50];
    int i,j,k,N,A,flag=0,pos,pos1;
    scanf("%d %d",&N,&A);
    for(i=0;i<N;i++)
    {
        scanf("%d",&arr[i]);
    }
    j = 0;
    k = N-1;
    while(j!=k)
     {
        if(arr[j]+arr[k]==A)
        {
            pos = j;
            pos1 = k;
            flag = 1;
            break;
        }
        else if(arr[j]+arr[k]>A)
        {

            k--;
        }
        else if(arr[j]+arr[k]<A)
        {
            j++;
        }

    }
    if(flag==1)
    {
        printf("%d %d %d %d",pos,pos1,arr[pos],arr[pos1]);
    }
    else
    {
        printf("NO");
    }
    return 0;

}

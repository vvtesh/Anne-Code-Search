#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,sum;
    int *a;
    int i,j;
    scanf("%d %d",&n,&sum);
    a = malloc(sizeof(int)*n);
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    int beg,end;
    int l,r,diff;
    l = r =0;
    int min=0;
    beg = 0;
    end = n-1;
    while(beg<end)
    {
        if((a[beg]+a[end]) == sum)
        {
            printf("%d %d %d %d\n",beg,end,a[beg],a[end]);
            break;
        }
        else if((a[beg]+a[end]) < sum)
            beg++;
        else
            end--;
    }
    if(beg>=end)
        printf("NO");
    return 0;
}

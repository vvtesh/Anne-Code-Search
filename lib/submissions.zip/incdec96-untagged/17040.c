#include<stdio.h>
int main()
{
 int n,*a,i=0,sum,s;
 scanf("%d",&n);
 scanf("%d",&sum);
 a=(int *)malloc(n*sizeof(int));
 for (i=0;i<n;i++)
 {
     scanf("%d",&a[i]);

 }

 i=0;
 int j=n-1,checks=-1,subij=0;
 int r,b;
 while(i<j)
 {
     s=a[i]+a[j];
     if(s==sum)
      {
        checks=s;
        printf("%d %d %d %d",i,j,a[i],a[j]);
        break;
      }
     else if(s<sum)
     {
         i=i+1;
     }
     else if(s>sum)
     {
         j=j-1;
     }
}



  if (checks==-1)
    {
        printf("NO");
    }

return 0;
}

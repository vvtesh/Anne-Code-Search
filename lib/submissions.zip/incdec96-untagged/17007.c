#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
struct point{
    int x;
    int y;
    
};
struct node {
    struct point a;
    struct node * next;
    struct node * prev;
};

struct node *head=NULL;
struct node *tail=NULL;
struct node *new;


void create_list()
{
    new=(struct node*)malloc(1*sizeof(struct node));
}

void insert_beg()
{   int data1;
    int data2;
    scanf("%d %d",&data1,&data2);
    //struct node * new;
    //new=(struct node*)malloc(1*sizeof(struct node));
    if(data1>=1 && data2<=pow(10.0,9) && data2>=1 && data2<=pow(10.0,9))
    {
    new->a.x=data1;
    new->a.y=data2;
    if(head==NULL)
    {
        head=new;
        tail=new;
        new->next=NULL;
        new->prev=NULL;
        
    }
    else
    {
        new->next=head;
        head->prev=new;
        new->prev=NULL;
        head=new;
    }
    }
    
}

void insert_end()
{   int data1;
    int data2;
    scanf("%d %d",&data1,&data2);
    //struct node * new;
    //new=(struct node *)malloc(1*sizeof(struct node));
    if(data1>=1 && data2<=pow(10.0,9) && data2>=1 && data2<=pow(10.0,9))
    {new->a.x=data1;
    new->a.y=data2;
    if(tail==NULL)
    {
        head=new;
        tail=new;
        new->next=NULL;
        new->prev=NULL;
    }
    else
    {
        tail->next=new;
        new->prev=tail;
        new->next=NULL;
        tail=new;
        
    }
    }
}


void print_list()
{   int type;
    scanf("%d",&type);
    if(type==0)
    //traverse from beginning
    {
        struct node *current;
        current=head;
        if(head==NULL && tail==NULL)
        {
            printf("NULL\n");
            printf("\n");
        }
        else{
        while(current->next!=NULL)
        {
            printf("%d %d\n",current->a.x,current->a.y);
            current=current->next;
        }
        printf("%d %d\n",tail->a.x,tail->a.y);
        printf("\n");
        }
    }
    else if(type==1)//traverse from end
    {
        if(tail==NULL && head==NULL)
        {
            printf("NULL\n");
            printf("\n");
        }
        else
        {struct node *current;
        current=tail;
        while(current->prev!=NULL)
        {
            printf("%d %d\n",current->a.x,current->a.y);
            current=current->prev;
        }
        printf("%d %d\n",head->a.x,head->a.y);
        printf("\n");
        }
    
    }
    
}



void delete_beg()
{
    struct node *temp;
    temp=head;
    if(head->next!=NULL)
    {
    head=head->next;
    head->prev=NULL;
    free(temp);
    }
    else
    {
        free(temp);
        tail=NULL;
        head=NULL;
    }
    
}


void delete_end()
{
    struct node *temp;
    temp=tail;
    if(tail->prev!=NULL)
    {   tail=tail->prev;
        tail->next=NULL;
        free(temp);
    }
    else
    {   free(temp);
        tail=NULL;
        head=NULL;
    }
}


void delete_list()
{   if(head==NULL && tail==NULL)
    {;}
   else{
    
    struct node *temp;
    while(head!=tail)
    {
        temp=head;
        head=head->next;
        free(temp);
        
    }
    free(tail);
    head=NULL;
    tail=NULL;
   }
}

int main()
{
    
    
    //printf("HELLO WORLD\n");
    char string[100];
    int create=0;
    while(1)
    {
        
        scanf("%s",string);
        if(strcmp(string,"createlist")==0)
        {   create++;
            if(create==1)
            {
            create_list();
            }
        }
        if(strcmp(string,"insertbeg")==0)
        {   if(create!=1)
            {create_list();}
            insert_beg();
        }
        else if(strcmp(string,"insertend")==0)
        {   if(create!=1)
        {
            create_list();
        }
            insert_end();
        }
        else if(strcmp(string,"printlist")==0)
        {
            
            
            print_list();
        }
        else if(strcmp(string,"deletebeg")==0)
        {
            delete_beg();
        }
        else if(strcmp(string,"deleteend")==0)
        {
            delete_end();
        }
        else if(strcmp(string,"deletelist")==0)
        {
            delete_list();
        }
        else if(string[0]=='0')
        {
            goto exit;
        }
        
    }
    exit:;
    return 0;
}





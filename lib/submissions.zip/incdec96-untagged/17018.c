#include<stdio.h>
void main()
{
	int i,n,a;
	scanf("%d %d",&n,&a);
	int A[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&A[i]);
	}
	int l=0,flag=0;
	int r=n-1;
	while(l<r)
	{
		if(A[l]+A[r]==a)
		{
			printf("%d %d %d %d",l,r,A[l],A[r]);
			flag=1;
			break;
		}
		else if(A[l]+A[r]<a)
		{
			l++;
		}
		else
		{
			r--;
		}
	}
	if(flag==0)
	{
		printf("NO");
	}
	
}

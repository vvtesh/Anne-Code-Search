#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N,A;int j,i;
    scanf("%d %d",&N,&A);
    int B[N];
    for(i=0;i<N;++i)
        {scanf("%d",&B[i]);}
    j=N-1;i=0;
int flag=0;

    while(i<j) 

    { 
        if(B[i]+B[j]<A)
        {
            ++i;
        }
        else if(B[i]+B[j]==A)
        {
            printf("%d %d %d %d",i,j,B[i],B[j]);
            flag=1;break;
        }
        else if (B[i]+B[j]>A)
        {
            --j;
        }


    }
    if(flag==0)
        printf("NO");
return 0;
}
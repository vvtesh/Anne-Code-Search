#include<stdio.h>
int main(){
    int* a;
    int N, A;
    scanf("%d %d",&N,&A);
    int i=0;
    int j;
    int tdiff=0;
    int sumdiff[2];
    int diff=-1;
    int ip, jp;
    a=(int)malloc(N*sizeof(int));
    for(i=0;i<N;i++) scanf("%d",&a[i]);
    for(i=0;i<N-1;i++){
        for(j=i+1;j<N;j++){
            if(a[i]+a[j]==A) {
                tdiff=a[j]-a[i];
                if(tdiff>diff) {
                    diff=tdiff;
                    sumdiff[0]=a[i];
                    sumdiff[1]=a[j];
                    ip=i;
                    jp=j;
                }
                break;
            }
        }
    }
    if(diff==-1){
        printf("NO");
        return 0;
    }
    printf("%d %d %d %d",ip,jp,sumdiff[0],sumdiff[1]);
    return 0;
}

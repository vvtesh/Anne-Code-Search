#include<stdio.h>
int main()
{
    int n,a,i,j,p,q,flag=0;
    scanf("%d",&n);
    scanf("%d",&a);
    int s[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&s[i]);
    }
    for(i=0,j=n-1;i<j;)
    {
        if(s[i]+s[j]==a)
        {
            flag=1;
            p=i;
            q=j;
            break;
        }
        else if(s[i]+s[j]<a)
        {
            i++;
        }
        else
        {
            j--;
        }
    }

    if (flag==0)
        printf("NO");
    else
        printf("%d %d %d %d",p,q,s[p],s[q]);
    return 0;
}

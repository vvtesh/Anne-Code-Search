#include<stdio.h>
int main()
{int i,n,arr[1000000],num,peh,aak;
 scanf("%d",&n);
 scanf("%d",&num);
 for(i=0;i<n;i++)
 {scanf("%d",&arr[i]);
}
  peh=0;
  aak=(n-1);
  while(peh<aak)
  {if((arr[peh]+arr[aak])<num)
  { peh++;
  }
   else if (arr[peh]+arr[aak]>num)
   {aak--;
    }
   else{printf("%d %d %d %d",peh,aak,arr[peh],arr[aak]);break;}
    }
  if(peh>=aak){printf("NO");}

return 0;
}

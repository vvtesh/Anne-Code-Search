#include<stdio.h>
#include<stdlib.h>
int main(void)
{
int N,A,i,j,c=0,sum;
scanf("%d %d",&N,&A);
int *arry=(int *)malloc(N*sizeof(int));
    for(i=0;i<N;i++)
    {
    scanf("%d",&arry[i]);
    }
     i=0;
     j=N-1;
        while(i<=j)
        {sum=arry[i]+arry[j];
            if(sum==A)
            {
                    c=1;
                    break;
            }
            else if(sum<A)

            i++;

            else if(sum>A)
            j--;
        }

        if(c==1)
        {
        printf("%d %d %d %d",i,j,arry[i],arry[j]);
        printf("\n");
        }
        else
        printf("NO");
                    printf("\n");
return 0;
}

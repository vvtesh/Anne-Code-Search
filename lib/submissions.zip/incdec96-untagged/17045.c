#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
	int i,j,n,k,g,s;
	scanf("%d",&i);
	scanf("%d",&n);
	int a[i];
	for (j = 0; j < i; ++j)
	{
		scanf("%d",&a[j]);
	}
	for (j = 0,k=i-1; j < k;)
	{
		if (a[j]+a[k]<n)
			j++;
		else if(a[j]+a[k]>n)
			k--;
		else if(a[j]+a[k]==n)
		{
			s=j;
			g=k;
			break;
		}
		else
			g=-1;
	}

	if (g==-1)
		printf("NO");
	
	else
		printf("%d %d %d %d",s,g,a[s],a[g]);
	
	return 0;
}
#include<stdio.h>
#include<stdlib.h>

int main()
{
    int i, j,found=0;
    int f,s,pos1,pos2,N,A;
    int *arr;
    scanf("%d %d",&N,&A);
    arr=(int*)malloc(sizeof(int)*N);
    for(i=0;i<N;i++)
    {
        scanf("%d",&arr[i]);
    }
    for(i=0;i<N;)
    {
        if(arr[i]+arr[N-1] == A)
        {
            found=1;
            f=arr[i];
            s=arr[N-1];
            pos1=i;
            pos2=N-1;
            printf("%d %d %d %d",pos1,pos2,f,s);
        }
        i++;
    }
    if(found==0)
        printf("NO");

    return 0;
}

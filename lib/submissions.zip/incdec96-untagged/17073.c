#include<stdio.h>
int main()
{
	int A,n,i,low,top,z=0;
	int sum[4];
	int *array;
	scanf("%d %d",&n,&A);
	array = (int*)malloc(n*sizeof(int));
	for(i=0;i<n;i++)
	{
		scanf("%d",&array[i]);
	}
    low = 0;
    top = n-1;
    sum[0]= -1;
    while(low < top)
    {
         if(array[low] + array[top] == A)
         {
            if(z==1)
            {
                if((top-low)>(sum[3]-sum[2]))
                {
                    sum[2]=array[low];
                    sum[3]=array[top];
                    sum[0]=low;
                    sum[1]=top;
                }
            }
            else
            {
                sum[2]=array[low];
                sum[3]=array[top];
                sum[0]=low;
                sum[1]=top;
            }
            z=1;
            low--;
            top--;
         }  
         else if(array[low] + array[top] < A)
              low++;
         else 
              top--;
    }
    if(z == 0)
    {
    	printf("NO");
    }
    else
    {
    	printf("%d %d %d %d",sum[0],sum[1],sum[2],sum[3]);
    }
    return 0;    
}
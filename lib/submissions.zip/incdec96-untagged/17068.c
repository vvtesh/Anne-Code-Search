#include<stdio.h>
int main(){
	int A[1000000],N,b,i;
	scanf("%d",&N);
     	scanf("%d",&b);
	for(i=0;i<N;i++){
		scanf("%d",&A[i]);
	}
	int c=0,d=N-1;
	while(c<d){        
		if(A[c]+A[d]==b){
		printf("%d %d %d %d\n",c,d,A[c],A[d]);
		break;
		}
			else if(A[c]+A[d]<b){
			c=c+1;
			}
				else if(A[c]+A[d]>b){
 					d=d-1;
				}
	}
	if(A[c]+A[d]!=b){
		printf("NO\n");	
	}
	return 0;
}


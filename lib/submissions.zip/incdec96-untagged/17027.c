#include<stdio.h>
#include<malloc.h>
int main()
{ int n;
  int sum;
  scanf("%d %d",&n,&sum);
  int *a;
  a=(int*)malloc(n*sizeof(int));
  int i;
  for(i=0;i<n;i++)
  {scanf("%d",&a[i]);
   
  }
  int j=0,k=n-1;
  int flag=0;
  while( j<k)
  { if((a[j]+a[k])==sum)
    {flag=1; 
    break;
    }
    else if((a[j]+a[k])>sum)
           k--;
    else if((a[j]+a[k])<sum)
           j++;
  }
  if(flag==0)
   printf("NO");
  else 
   printf("%d %d %d %d",j,k,a[j],a[k]);
   return(0);
}
  

#include <stdio.h>
#include <stdlib.h>


int main()
{
	int len, sum;

	scanf("%d %d", &len, &sum);

	int arr[len];

	int i = 0;
	for (i;i<len;i++) scanf("%d",&arr[i]);

		int j = len-1;

		for (j;j>0;j--)
		{
			for (i = 0;i<j;i++)
			{
				if (arr[i] + arr[j] == sum)
				{
					printf("%d %d %d %d\n", i, j, arr[i], arr[j] );
					return 0;
				}
				else if (arr[i] + arr[j] > sum)
					i = j-1;
			}
		}
		printf("NO\n");
		return 0;
}
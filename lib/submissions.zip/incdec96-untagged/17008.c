#include<stdio.h>
int main()
{
	int N,A,l,r,i;
	scanf("%d",&N);
        scanf("%d",&A);
        int J[N];
	for(i=0;i<N;i++)
	{
		scanf("%d",&J[i]);
	}
	l=0;
	r=N-1;
	while(l<r)
	{
		if(J[l]+J[r]==A)
		break;
		else if(J[l]+J[r]<A)
		l++;
		else
		r--;
	}
	if(J[l]+J[r]==A)
		printf("%d %d %d %d",l,r,J[l],J[r]);
	else
	    printf("NO");
		
return 0;
}


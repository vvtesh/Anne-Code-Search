#include<stdio.h>
int main()
{
    int A[1000010];
    int n,sum,temp,i=0,k,j=0,a=1;
    scanf("%d %d",&n,&sum);
    for(i=0;i<n;i++)
    {
       scanf("%d",&A[i]);
    }
    k=n-1;
while(j<k)
{
    temp=A[j]+A[k];
    if(temp==sum)
    {
        printf("%d %d %d %d",j,k,A[j],A[k]);
        a=0;
        break;
    }
    else if(temp>sum)
    {
        k--;
    }
    else if(temp<sum)
    {
       j++;
    }
}
if(a!=0)
{
   printf("NO");
}

    return 0;

}
#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include<string.h>
struct node
{
    int data;
    struct node* next;
    struct node* prev;
};

struct node *head , *last;

void createlist()
{
    head=last=NULL;
}

int count=0;

void insertbeg(int d)
{
    struct node *next,*temp;
    next= (struct node*)malloc(sizeof(struct node));
    next->data=d;
    if(head==NULL)
    {
        head=next;
        head->prev=NULL;
        head->next=NULL;
        last=head;
    }
    else
    {
        temp=next;
        (temp).prev=NULL;
        (*temp).next=head;
        (*head).prev=temp;
        head=temp;
    }
}

void insertend(int d)
{
    struct node *next,*temp;
    next=(struct node*)malloc(sizeof(struct node));
    next->data=d;
    if(head==0)
    {
        head=next;
        (*head).prev=NULL;
        (*head).next=NULL;
        last=head;
    }
    else
    {
        (*last).next=next;
        (*next).prev=last;
        last=next;
        (*last).next=NULL;
    }
}

void deletebeg()
{
    struct node *temp;
    if(head==NULL)
    {
        return;
    }
    else if(head->next==NULL)
    {
        temp=head;
        free(temp);
        head=last=NULL;
    }
    else
    {
        temp=head;
        head=head->next;
        free(temp);
        head->prev=NULL;
    }
}

void deletelast()
{
    struct node *temp;
    temp=last;
    if(temp==NULL)
    {
        return;
    }
    else if(temp->prev==NULL)
    {
        free(temp);
        head=NULL;
        last=NULL;
    }
    else
    {
        last=temp->prev;
        last->next=NULL;
        free(temp);
    }
}

void printlist(int k)
{
    struct node *temp,*next;
    if(k==0)
    {
        temp=head;
        if(temp==NULL)
        {
            printf("NULL\n\n");
        }
        else
        {
            while(temp!=NULL)
            {
                printf("%d \n",temp->data);
                temp=temp->next;
            }
    }
    }
    if(k==1)
    {
        next=last;
        if(next==NULL)
        {
            printf("NULL\n\n");
        }
        else
        {
            while(next!=NULL)
            {
                printf("%d\n",next->data);
                next=next->prev;
            }
        }
    }
}
struct node* partition(struct node *m, struct node *n)
{
    int x  = n->data;
    struct node *j;
    struct node *i = m->prev;

    for ( j= m; j != n; j = j->next)
    {
        if (j->data <= x)
        {
            i = (i == NULL)? m : i->next;
            swap(&(i->data), &(j->data));
        }
    }
    i = (i == NULL)? m : i->next;
    swap(&(i->data), &(n->data));
    return i;
}


void quickSort(struct node* l, struct node *h)
{
    if (h != NULL && l != h && l != h->next)
    {
        struct node *p = partition(l, h);
        quickSort(l, p->prev);
        quickSort(p->next, h);
    }
}

void sortlist(struct node *head)
{

    struct node *h = last;
    quickSort(head, h);
}

void swap(int *a,int *b)
{
int temp;
temp=*a;
*a=*b;
*b=temp;
}


int main()
{
    int n;
    char ch[25];
    createlist();
struct node *h,*t;
h=head;
t=last;
    while(1)
    {
        scanf("%s %d",&str,&n);
        if(strcmp(ch,"insertbeg")==0)
        {
            insertbeg(n);
        }
        else if(strcmp(ch,"insertend")==0)
        {
            insertend(n);
        }
        else if(strcmp(ch,"deletebeg")==0)
        {
            deletebeg();
        }
        else if(strcmp(ch,"deletelast")==0)
        {
            deletelast();
        }
        else if((strcmp(ch,"stop")==0)&&(n==0))
        {
            sortlist(head);
            printlist(0);
            break;
        }
      else if((strcmp(ch,"stop")==0)&&(n==1))
        {
            sortlist(head);
            printlist(1);
            break;
        }
    }
        return 0;
}

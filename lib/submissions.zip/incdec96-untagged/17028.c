#include <stdio.h>
#include <malloc.h>

int main()
{
	int N, A, i;
	scanf("%d", &N);
	scanf("%d", &A);
	int arr[N];
	//int arr = (int *)malloc(N*sizeof(int));
	for(i=0; i<N; ++i) {
		scanf("%d", (arr+i));
	}
	findpair(N, A, arr);
    return 0;
}

void findpair(int N, int A, int *arr) {
    int f=0;
	int r=N-1;
	while(f < r) {
		if(arr[f] + arr[r] == A)
            break;
		else if(arr[f] + arr[r] < A)
            f++;
		else
            r--;
	}
	if(arr[f]+arr[r]==A)
		printf("%d %d %d %d\n", f, r, arr[f], arr[r]);
	else
	    printf("NO\n");
}

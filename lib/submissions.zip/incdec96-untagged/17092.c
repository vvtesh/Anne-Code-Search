#include <stdio.h>
#include <stdlib.h>

int main()
{
	int *arr = (int*)malloc(sizeof(int));
	int n, a, i;
	scanf ("%d %d", &n, &a);
	
	if ((n<1) || (n>1000000) || (a<1) || (a>1000000000))
	{
		return 0;
	}
	/*
	else if ((a<1) || a>1000000000)
	{
		return 0;
	}
	*/
	int x;
	for (i=0; i<n; i++)
	{
		scanf("%d", &x);
		if (x<1 || x>1000000000)
		{
			return 0;
		}
		else
		{
			arr[i]=x;
		}
	}

	int j, count;
	
	i = 0;
	j = n-1;

	while (i<j)
	{
		if(arr[i]+arr[j]==a)
		{
			printf("%d %d %d %d\n", i, j, arr[i], arr[j]);
			count =1;
			break;
		}
		else if (arr[i]+arr[j]<a)
		{
			i++;
		} 
		else if (arr[i]+arr[j]>a)
		{
			j--;
		}
	}

	if (count!=1)
	{
		printf("NO");
		return 0;
	}
	else
	{
		return 0;
	}
}
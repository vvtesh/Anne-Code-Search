#include<stdio.h>
int binarysearch(int n, int A[], int size)
{
	int first = 0, last = size - 1;
	int mid = (first + last)/2;
	while(first <= last){
		if(A[mid] < n)
			first = mid+1;
		else if(A[mid] > n)
			last = mid -1;
		else
			return mid;
		mid = (first+last)/2;
	}
	if(first > last)
		return -1;
}

int main()
{
	int size, sum, i, d=-1;
	scanf("%d %d",&size,&sum);
	int A[size];
	for(i=0;i<size;i++)
	{
		scanf("%d",&A[i]);
	}
	for(i=0;i<size;i++)
	{
		d=binarysearch(sum - A[i], A, size);		
		if(d!=-1){
			if(i!=d){
				printf("%d %d %d %d",i,d,A[i],A[d]);
				break;
			}
			else
				d = -1;
		}
	}
	if(d==-1)
		printf("\nNO");
	return 0;
}

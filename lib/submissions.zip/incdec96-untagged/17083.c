#include<stdio.h>
#include<stdlib.h>
int main()
{
    int *a,t,b,c,n,*arr,l,r,i;
    int flag=0;
    int found=0;
    scanf("%d %d",&n,&b);
    a=(int*)malloc(n*sizeof(int*));
    arr=(int*)malloc(n*sizeof(int*));
    c=n;
    i=0;
    while(i<c)
    {
        scanf("%d",&a[i]);
        i++;
    }
    a[n]='\0';
    //for(i=0;i<n;i++)
        //printf("%lld ",a[i]);
    l=0;
    r=n-1;
    while(l<r)
    {
        if(a[l]+a[r]==b && found==0)
        {
            flag=1;
            found=1;
            arr[0]=l;
            arr[1]=r;
            arr[2]=a[l];
            arr[3]=a[r];
            //printf("%d %d %d %d\n",l,r,a[l],a[r]);
            l++;
            r--;
        }
        else if(a[l]+a[r]==b && found==1)
        {
            flag=1;
            //printf("%d %d %d %d\n",l,r,a[l],a[r]);
            if ((a[r]-a[l])>(arr[3]-arr[2]))
            {
                arr[0]=l;
                arr[1]=r;
                arr[2]=a[l];
                arr[3]=a[r];
            }
            r--;
            l++;
        }
        else if(a[l]+a[r]<b)
            l++;
        else
            r--;
}
    if (flag==1)
        printf("%d %d %d %d",arr[0],arr[1],arr[2],arr[3]);
    else
    printf("NO");
    return 0;
}

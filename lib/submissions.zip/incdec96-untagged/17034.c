#include<stdio.h>
#include<stdlib.h>

int main(){
    int nnn,aaa,i,j,sum,flag;
    flag=0;
    int *arr;
  //  puts("enter n and a");
    scanf("%d%d",&nnn,&aaa);
    i=nnn;
    arr=(int*)malloc(nnn*sizeof(int));
    while(i>0){
        scanf("%d",&arr[nnn-i]);
        i--;
    }
   // for(i=0;i<nnn;i++){
   //     printf("%d ",arr[i]);
  //  }
    j=nnn-1;

    for(i=0;i<=j;i++){
            j=nnn-1;

        sum=arr[i]+arr[j];
        while(sum>aaa && j>=i){
        sum=arr[i]+arr[j];
            j--;
        }
        if (sum==aaa){
            printf("%d %d %d %d\n",i,j,arr[i],arr[j]);
            flag=1;
            break;
        }

    }
    if(flag==0) printf("NO\n");

    return 0;
}

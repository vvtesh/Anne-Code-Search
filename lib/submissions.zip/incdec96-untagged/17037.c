#include <stdio.h>
#include <stdlib.h>
int main()
{
	int n,a,i,j;
	int *x;
	scanf("%d", &n);
	x=malloc(sizeof(int)*n);
	scanf("%d", &a);
	for (i=0; i<n; i++)
	{
		scanf("%d", x+i);
	}
	i=0;
	j=n-1;
	while (i<j)
	{
		if (x[i]+x[j]==a)
		{
			printf("%d %d %d %d\n", i,j,x[i],x[j]);
			break;
			i++;
			j--;
		}
		else if (x[i]+x[j]<a)
		{
			i++;
		}
		else if (x[i]+x[j]>a)
			j--;
	}
	if (x[i]+x[j]!=a)
			printf("NO\n");
		return 0;
}
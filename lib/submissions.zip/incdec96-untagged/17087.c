#include <stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
int n,b,z=0,i=0,j,s=0;
scanf("%d",&n);
scanf("%d",&b);
int *arr=(int *)malloc(n*sizeof(int));
while(i!=n)
{
scanf("%d",&arr[i]);
i++;
}
i=0;
j=n-1;
while(i<=j)
{
s=arr[i]+arr[j];
if(s==b)
{
z=1;
break;
}
if(s<b)
i++;
else
j--;
}
if(z==1)
printf("%d %d %d %d",i,j,arr[i],arr[j]);
else
printf("NO");

return 0;
}

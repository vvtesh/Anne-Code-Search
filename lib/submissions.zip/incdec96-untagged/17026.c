#include<stdio.h>
#include<stdlib.h>
int main(void)
{
int a,b,i,j,c=0;
scanf("%d %d",&a,&b);
int *arr=(int *)malloc(a*sizeof(int));
    for(i=0;i<a;i++)
    {
    scanf("%d",&arr[i]);
    }
     i=0;
     j=a-1;
        while(i<=j)
        {
            if((arr[j]+arr[i])==b)
            {
                    c=1;
                    break;
            }
            else if((arr[j]+arr[i])<b){

            i++;}

            else if((arr[j]+arr[i])>b){
            j--;}
        }

        if(c==1)
        {
        printf("%d %d %d %d",i,j,arr[i],arr[j]);
        printf("\n");
        }
        else{
        printf("NO");
        printf("\n");}
return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int a, b,i=0, *arr,end,flag=1;
    scanf("%d%d",&a,&b);
    arr = (int*)malloc(a*sizeof(int));
    while(i<a)
    {
        scanf("%d",arr+i);
        i++;
    }
    i=0;
    end=a-1;
    while(i<end)
    {
        if(*(arr+i)+ *(arr+end)==b){
            printf("%d %d %d %d\n",i,end,*(arr+i),*(arr+end));
            flag=0;
            break;
        }
        else if(*(arr+i)+ *(arr+end)>=b)
            end--;
        else
            i++;
    }
    if(flag==1)
        printf("NO");
    return 0;
}

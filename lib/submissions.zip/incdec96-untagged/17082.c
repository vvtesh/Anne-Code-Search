#include<stdio.h>
int main(void)
{
    int N,rsum;
    scanf("%d%d",&N,&rsum);
    int *ar=(int *)malloc(N*sizeof(int));
    int found=0;
    int i;
    for(i=0;i<N;i++)
    {
        scanf("%d",&ar[i]);
    }
    i=0;
    int sum=0;
    int j=N-1;
    while(i<=j)
    {
        sum=ar[i]+ar[j];
        if(sum==rsum)
        {
            found=1;
            break;
        }
        if(sum<rsum)
            i++;
        else
            j--;
    }
    if(found==1)
        printf("%d %d %d %d",i,j,ar[i],ar[j]);
    else
        printf("NO");
    return 0;
}

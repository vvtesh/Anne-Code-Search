#include <stdio.h>

int main(int argc, char const *argv[])
{
	int n,i,j;

	unsigned long A;

	scanf("%d %lu",&n,&A);
	unsigned long ar[n];

	for(i=0;i<n;i++){
		scanf("%lu",&ar[i]);
	}
	
	i=0;j=n-1;

	//printf("%lu %lu\n",sizeof(ar[0]),sizeof(long));

	while(i<j){
		if(ar[i]+ar[j]==A){
			printf("%d %d %lu %lu\n",i,j,ar[i],ar[j]);
			return 0;
		}
		else if(ar[i]+ar[j]<A){
			i++;
		}
		else{
			j--;
		}
	}

	printf("NO\n");
	return 0;
}
#include<stdio.h>

int main()
{
    int N,A;
    scanf("%d %d",&N,&A);
    int arr[N],i;
    for(i=0;i<N;i++)
    {
        scanf("%d",&arr[i]);
    }
    int k=0,l=N-1;
    while(l>k)
    {
        if(arr[k]+arr[l]==A)
        {
            printf("%d %d %d %d",k,l,arr[k],arr[l]);
            break;
        }
        else if(arr[k]+arr[l]>A)
        {
            l--;
        }
        else
        {
            k++;
        }

    }
    if(l==k)
    {
        printf("NO");
    }
    return 0;
}

#include<stdio.h>
int main()
{
    int N,A,i;
    scanf("%d%d",&N,&A);
    int arr[N];
    for(i=0;i<N;i++)
        scanf("%d",&arr[i]);
    int index1=N-1,index2=0,c=0;
    while(index1>=index2)
    {
        if(arr[index1]+arr[index2]==A)
        {
            c=1;
            break;
        }
        else if(arr[index1]+arr[index2]>A)
            index1--;
        else
            index2++;
    }
    if(c==1)
        printf("%d %d %d %d",index2,index1,arr[index2],arr[index1]);
    else
        printf("NO");
    return 0;
}

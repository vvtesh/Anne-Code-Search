#include<stdio.h>
int main()
{
    int siz,s,sum,i,elem,pos1=0,pos2=0,elem1=0,elem2=0,top,last;
    scanf("%d %d",&siz,&sum);
    int arr[siz];
    for(i=0;i<=(siz-1);i++)
    {
        scanf("%d",&elem);
        arr[i]=elem;
    }
    top=0;
    last=siz-1;
    for(i=0;i<=siz-1;i++)
    {
        if(top>=last)
        {
            break;
        }
        s=arr[top]+arr[last];
        if(s>sum)
        {
            last--;
        }
        else if(s<sum)
        {
            top++;
        }
        else
        {
            if((arr[last]-arr[top])>(elem2-elem1))
            {
                pos1=top;
                pos2=last;
                elem1=arr[top];
                elem2=arr[last];
                top++;
                last--;
            }
            else
            {
                top++;
                last--;
            }
        }
    }
    if(elem1!=0 || elem2!=0)
    {
        printf("%d %d %d %d\n",pos1,pos2,elem1,elem2);
    }
    else
        printf("NO");

    return 0;
}

#include <stdio.h>
int main(void)
{
    int n,b;
    scanf("%d%d",&n,&b);
    int *c=(int *)malloc(n*sizeof(int));
    int f=0;
    int i;
    for(i=0;i<n;i++)
    {
        scanf("%d",&c[i]);
    }
    i=0;
    int s=0;
    int j=n-1;
    while(i<=j)
    {
        s=c[i]+c[j];
        if(s==b)
        {
            f=1;
            break;
        }
        if(s<b)
            i++;
        else
            j--;
    }
    if(f==1)
        printf("%d %d %d %d",i,j,c[i],c[j]);
    else
        printf("NO");
    return 0;
}

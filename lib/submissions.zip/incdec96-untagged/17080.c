#include <stdio.h>
#include <stdlib.h>

int main()
{
    long long n,sum;
    scanf("%lld %lld", &n, &sum);
    long long arr[n];
    long long i;
    for(i=0;i<n;i++){
        scanf("%lld", &arr[i]);
    }
    i=0;
    long long j=n-1;
    int flag=0;
    while(i<j){
        if(arr[i]+arr[j]<sum){
            i++;
        }
        else if(arr[i]+arr[j]>sum){
            j--;
        }
        else{
            flag=1;
            break;
        }
    }
    if(flag==1){
        printf("%lld %lld %lld %lld\n", i,j,arr[i],arr[j]);
    }
    else{
        printf("NO\n");
    }
    return 0;
}




#include<stdio.h>

int main()
{
    int n,a,i,d,index1,index2;
    scanf("%d %d",&n,&a);
    int arr[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    index1=0;
    index2=n-1;
    while(index2>index1)
        {
            if(arr[index1]+arr[index2] < a)
            {
                index1++;
            }
            else if(arr[index1]+arr[index2] > a)
            {
                index2--;
                i=index1;
            }
            else
            {
                printf("%d %d %d %d",index1,index2,arr[index1],arr[index2]);
                return(0);
            }
        }
    printf("NO");
    return(0);
}

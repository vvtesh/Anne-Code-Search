#include<stdio.h>
int main()
{
	int t;
	long long int i,j,diff,ipos,jpos,flag,a,n,arr[1000001];
		scanf("%lld %lld",&n,&a);
		for(i=0;i<n;++i)
		{
			scanf("%lld",arr+i);
		}
		i=0;j=n-1;diff=0;flag=0;
		while((j-i)>=1)
		{
			if((arr[i]+arr[j])<a)
			{
				i++;
			}
			else if((arr[i]+arr[j])>a)
			{
				j--;
			}
			else
			{
				/*if((arr[j]-arr[i])>diff)
				{	
					diff=arr[j]-arr[i];
					ipos=i;jpos=j;
					flag=1;
				}
				i++;j--;*/
				flag=1;
			}
		}
		if(flag)
			printf("%lld %lld %lld %lld\n",i,j,arr[i],arr[j]);
		else
			printf("NO\n");
	return 0;
}
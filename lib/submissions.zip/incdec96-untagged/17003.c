#include<stdio.h>
#include<stdlib.h>

int main()
{
    int n;
    int s,i,j;
    int sum=0;
    scanf("%d %d",&n,&s);
    int *a=(int*)malloc(sizeof(int)*n);
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    i=0;
    j=n-1;
    while(i<j)
    {
        if(a[i]+a[j]==s)
            break;
        else if(a[i]+a[j]<s)
            i++;
        else
            j--;
    }
    if(i==j)
        printf("NO");
    else
    {
        printf("%d %d %d %d",i,j,a[i],a[j]);
    }
    return 0;
}

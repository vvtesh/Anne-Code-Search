#include<stdio.h>

typedef long long ll;

ll a[1000001];

int main()
{
int flag=0;
ll A,n,i,j,p,q;
scanf("%lld",&n);
scanf("%lld",&A);
for(i=0;i<n;i++)
{scanf("%lld",&a[i]);}
i=0;
j=n-1;
while(i!=j)
{
if(a[i]+a[j]==A)
{
p=i;
q=j;
flag=1;
break;
}
if(a[i]+a[j]>A)
j--;
else
i++;

}
if(flag==0)
printf("NO\n");
else
{
printf("%lld %lld %lld %lld\n",i,j,a[i],a[j]);
}
return 0;
}

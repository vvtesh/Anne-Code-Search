#include <stdio.h>
int main() 
{

	int N;
	int i,A,a,b;
	scanf("%d  %d",&N,&A);
	int arr[N];
	for(i=0;i<N;i++)
	 {
	  scanf("%d",&arr[i]);
	 }
	 a=0;
	 b=N-1;
    
    while(a<b)
    {
        
        	 if (arr[a]+arr[b]==A)
        	   break;
        	 else if(arr[a]+arr[b] < A)
        	   a++;
        	 else
        	   b--;
        	    
    }
        	    if(arr[a]+arr[b]==A)
        	    printf("%d %d %d %d",a,b,arr[a],arr[b]);
        	     
        	   else
        	     printf("NO");
       
    
		return 0;
}
#include<stdio.h>
#include<stdlib.h>

void pair(int *a,int size,int s)
{
	int i=0,j=(size-1),sum=0;
	while(i<j && i<(size-1) && j>0)
	{
		sum=a[i]+a[j];
		if(s > sum)
			i++;
		else if(s < sum)
			j--;
		else
			break;
	}
	if(sum!=s)
		printf("NO\n");
	else
		printf("%d %d %d %d\n",i,j,a[i],a[j]);
}

int main()
{
	int size=0,no=0,i=0;
	scanf("%d",&size);
	int *a=malloc(sizeof(*a)*size);
	scanf("%d",&no);
	while(i<size)
	{
		scanf("%d",&a[i]);
		i++;
	}
	pair(a,size,no);
	return 0;
}

#include <stdio.h>

int main () {
int arr[1000000],n,a,i,l,r;
	scanf("%d %d",&n,&a);
	for (i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	l = 0;
	r = n-1;
	while (l<r){
		if(arr[l]+arr[r]==a){
			printf("%d %d %d %d\n",l,r,arr[l],arr[r]);
			return 0;
		}
		else if ((arr[l]+arr[r]) < a){
			l++;
		}
		else{
			r--;
		}
	}
	printf("NO\n");
	return 0;
}
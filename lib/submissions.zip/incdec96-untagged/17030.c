#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int bin_srch (int Arr[], int beg, int end, int Val)
{
	int mid = (beg + end)/2;
	if (end < beg)
		return -1;
	else if (Arr[mid] == Val)
		return mid;
	else if (Arr[mid] > Val)
		return bin_srch (Arr, beg, mid-1, Val);
	else if (Arr[mid] < Val)
		return bin_srch (Arr, mid+1, end, Val);
}
	
void search (int Arr[], int size, int A)
{
	int i, temp, index1, found = 0;
	for (i=0; Arr[i] <= (A/2); i++)
	{	
		index1 = bin_srch (Arr, 0, size-1, A-(Arr[i]));
		if (index1 == -1)
			continue;
		else
		{
			found = 1;
			printf ("%d %d %d %d", i, index1, Arr[i], Arr[index1]);
			break;
		}
		printf (" ");
	}
	
	if (found == 0)
		printf ("NO\n\n");
	else
		printf ("\n\n");
}
			
		
int main()
{
	int size, A, i = 0;
	scanf ("%d %d", &size, &A);
	int *str_arr;
	str_arr = (int *) malloc (sizeof(int) * size);
	while (i < size)
	{
		scanf ("%d", &str_arr[i]);
		i++;
	}
	
	//for (i=0; i<size; i++)
	//	printf ("%d ", str_arr[i]);
	
	search (str_arr, size, A);
	return 0;
}

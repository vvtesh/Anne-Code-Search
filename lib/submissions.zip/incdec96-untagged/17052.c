#include <stdio.h>

int main(){
	int n,k,i,j;
	scanf("%d",&n);
	scanf("%d",&k);
	long a[n];
	for(i=0;i<n;i++)
		scanf("%ld",&a[i]);
	i=0;
	j=n-1;
	while(i<j){
		if((a[i]+a[j])==k)
			break;
		else if((a[i]+a[j])<k)
			i++;
		else
			j--;
	}
	if(i>=j)
		printf("NO\n");
	else
		printf("%d %d %ld %ld\n",i,j,a[i],a[j]);
	return 0;
}
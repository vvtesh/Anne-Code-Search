#include <stdio.h>

int main(){
int min,max,i,size,num,j,flag;

scanf("%d%d",&size,&num);
int A[size];
for(i=0;i<size;++i)
    scanf("%d",&A[i]);

flag=0;
i=0;
j=size-1;

while(i<j){
    if(A[i]+A[j]==num){
        flag=1;
        printf("%d %d %d %d",i,j,A[i],A[j]);
        break;
     }
     else if (A[i]+A[j]<num)
        i++;
     else
        j--;
}

if (flag==0)
    printf("NO");
return 0;
}

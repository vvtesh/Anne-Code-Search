#include<stdio.h>
int main()
{
	int s,n,i,sum,c=0,f,l,b[3];
	scanf("%d %d",&n,&s);
	int a[n];
	for(i=0 ; i<n ; i++)
		scanf("%d",&a[i]);
	f=0;
	l=n-1;
	//sum=a[f]+a[l];
	//if(sum==s)
	//	printf("%d %d %d %d\n",f,l,a[f],a[l]);
	while(sum!=s)
	{
		sum=a[f]+a[l];
		if(f==l)
			break;
		if(sum==s)
		{
			b[0]=f;b[1]=l;b[2]=a[f];b[3]=a[l];
			c++;
		}
		if(sum<s)
			f++;
		else if(sum>s)
			l--;
	}
	if(c==0)
		printf("NO\n");
	else
		printf("%d %d %d %d\n",b[0],b[1],b[2],b[3]);
	return 0;
}

#include<stdio.h>
int main()
{
int n,sum,i,j,flag=0;
scanf("%d %d",&n,&sum);
int a[n];
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
i=0;
j=n-1;
while(i<j)
{
if(a[i]+a[j]==sum)
   {
    printf("%d %d %d %d",i,j,a[i],a[j]);
    flag=1;
    break;
   }
else if(a[i]+a[j]>sum)
    j--;
else
    i++;
}
if(!flag)
    printf("NO");
return 0;
}

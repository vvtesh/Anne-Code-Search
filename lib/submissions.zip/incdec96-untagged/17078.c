#include <stdio.h>
#include <stdlib.h>
int main()
{
	int n, a;
	scanf("%d %d", &n, &a);
	int i, j;
	int *x;
	x = (int*)malloc(sizeof(int)*n);
	for(i = 0; i < n; i++)
	{
		scanf("%d", (x + i));
	}
	i = 0;
	j = n - 1;
	int f;
	f = 0;
	while(i < j)
	{
		if(*(x + i) + *(x + j) > a)
		{
			j--;
		}
		else if(*(x + i) + *(x + j) < a)
		{
			i++;
		}
		else
		{
			f = 1;
			break;
		}
	}
	if(f == 0)
	{
		printf("NO\n");
	}
	else
	{
		printf("%d %d %d %d\n", i, j, *(x + i), *(x + j));
	}
	return 0;
}
#include <stdio.h>

int Work(int *a,int n,int sum)
{
    int start,last,check=0;
    start=0;last=n-1;
    while(start<last)
    {
        if(a[last]+a[start]==sum)

            {
                printf("%d %d %d %d\n",start,last,a[start],a[last]);
                check+=1;
                break;
            }

        else if(a[last]+a[start]>sum)
        {
            last-=1;
        }
        else if(a[last]+a[start]<sum)
        {

            start+=1;
        }

    }
    if(check==0)
        printf("NO\n");
    return 0;


}



int main()
{
    int size;int sum;int i=0;//int t=1;
   // while(t<=100)
    //{
        scanf("\n%d %d",&size,&sum);
        int *a=(int*)malloc(size*sizeof(int));

        for(i=0;i<size;i++)
            scanf("%d",&a[i]);
        Work(a,size,sum);
    //}

return 0;
}

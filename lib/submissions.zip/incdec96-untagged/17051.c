#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n, a, i, head, tail;
    
    scanf("%d %d", &n, &a);
    int arr[n];
    
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    
    head = 0;
    tail = n - 1;
    
    for(;;)
    {
        if (arr[head]+arr[tail] > a && head < tail)
            tail--;
        else if (arr[head]+arr[tail] < a && head < tail)
            head++;
        else if((arr[head]+arr[tail]) == a)
        {
            printf("%d %d %d %d\n", head, tail, arr[head], arr[tail]);
            exit(0);
        }
        else
        {
            printf("NO\n");
            exit(0);
        }
    }
    
    return 0;
}

#include<stdio.h>
int main()
{
	unsigned long a[1000000],N,A;
	scanf("%lu",&N);
	scanf("%lu",&A);
	unsigned long i,j,k,lr=0,ur=N-1;
	for(i=0;i<N;i++)
	{	scanf("%lu",&a[i]);
	}
	unsigned long a1,a2;
	unsigned long a1p,a2p;
	int flag=1;
	while(lr<ur)
	{	if((a[lr]+a[ur])==A)	
		{	flag=0;
			a1p=lr;
			a2p=ur;
			break;
		}
		else if((a[lr]+a[ur])<A)
		lr++;
		else ur--;
	}
	if(flag==0) printf("%lu %lu %lu %lu\n",a1p,a2p,a[a1p],a[a2p]);
	else printf("NO\n");
	return 0;
}


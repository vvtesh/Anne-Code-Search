#include<stdio.h>

int N,x;


int main()
{
  scanf("%d %d",&N,&x);


   int a[N],k;
  
   int i=0;
   int j = N-1;

   for(k=0;k<N;k++)
   {
 		scanf("%d",&a[k]);

   }
  
  
  
  
  while(i<j)
  {
     if(a[i] + a[j] == x) 
     {printf("%d %d %d %d", i, j, a[i], a[j]); break;
     }

     else if(a[i] + a[j] < x) i++;

     else if (a[i] + a[j] > x) j--;
     
     else break;
     
   }
   
   if(i>=j)
    printf("NO");






	return 0;
	
}	
#include <stdio.h>

int main()
{
	int i,j;

	long n,A;

	scanf("%d %lu",&n,&A);
	int ar[n];

	for(i=0;i<n;i++){
		scanf("%lu",&ar[i]);
	}
	
	i=0;j=n-1;

	while(i<j){
		if(ar[i]+ar[j]==A){
			printf("%d %d %i %i\n",i,j,ar[i],ar[j]);
			return 0;
		}
		else if(ar[i]+ar[j]<A){
			i++;
		}
		else{
			j--;
		}
	}

	printf("NO\n");
	return 0;
}

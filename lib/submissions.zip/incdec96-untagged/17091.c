#include <stdio.h>
#include<string.h>
#include<stdlib.h>
int main(void)
{
    int n,b,f=0,s=0;
    scanf("%d%d",&n,&b);
    
	int *temp=(int *)malloc(n*sizeof(int));
    int i;
    for(i=0;i<n;++i)
    {
    	scanf("%d",&temp[i]);
    }
    i=0;
    int j;
    j=n-1;
   
	while(i<=j)
    {
        s=temp[i]+temp[j];
        if(s==b)
        {
            f=1;
            break;
        }
        if(s<b)
            ++i;
        else
            --j;
    }
    if(f==1)
    printf("%d %d %d %d",i,j,temp[i],temp[j]);
    else
    printf("NO");
    return 0;
}

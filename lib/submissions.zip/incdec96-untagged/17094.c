#include <stdio.h>
long int ironman(long long int ,long int ,long long int []);
int main()
{
    long long int n,a;
    scanf("%lld %lld",&n,&a);
    long long int b[n+1];
    int i,j,check=0;
    for(i=0;i<n;i++)
    {
        scanf("%lld",&b[i]);
    }
    for(i=0;i<n;i++)
    {
        if (ironman(a-b[i],n,b)!=0)
            {
                printf("%ld %ld %lld %lld\n",i,ironman(a-b[i],n,b),b[i],a-b[i]);
                check=1;
                break;
            }
    }
    if(check==0)
        printf("NO\n");
    return 0;
}
long int ironman(long long int value,long int n,long long int list[])
{
    long int first,last,middle;
    first = 0;
   last = n - 1;
   middle = (first+last)/2;

   while( first <= last )
   {
      if ( list[middle] < value)
         first = middle + 1;
      else if ( list[middle] == value )
      {
         return middle;
      }
      else
         last = middle - 1;

      middle = (first + last)/2;
   }
   return 0;
}

#include<stdio.h>
void main(){
    int x,y,start=0,last=0,sum=0,e=0;

    scanf("%d %d",&x,&y);
    int a[x];
    for (last=0;last<x;last++){
        scanf("%d",&a[last]);
    }
    last=last-1;
    while(start<last){
        sum=a[start]+a[last];
        if (sum==y){
                e=1;
                printf("%d %d %d %d",start,last,a[start],a[last]);
                break;

        }
        else if (sum<y){
            start=start+1;
        }
        else if (sum>y){
            last=last-1;
        }
    }
    if (e==0){
        printf("NO");
    }

}

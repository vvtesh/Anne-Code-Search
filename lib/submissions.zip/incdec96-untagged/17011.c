#include <stdio.h>
#include <string.h>

int main()
{
	int N,i,j;
	unsigned long A;
	scanf("%d %lu", &N, &A);
	unsigned long array[N];
	
	for(i=0;i<N;i++)
	{
		scanf("\n %lu", &array[i]);
	}
	
	i=0,j=N-1;
	
	while(i<j)
	{
		if(array[i]+array[j]==A)
		{
			printf("%d %d %lu %lu\n",i,j,array[i],array[j]);
			return 0;
		
		}
		else if(array[i]+array[j]<A)
		{
			i++;
		}
		else
		{
			j--;
		}
	}
	
	printf("NO \n");
	return 0;
}

#include<stdio.h>
int main()
{
	int total,tt,i,kite,j,n,no;

	scanf("%d%d",&n,&no);
	int arr[n];
	for(tt=0;tt<n;tt++)
	{
		scanf("%d",&arr[tt]);
	}
	i=0;
	j=n-1;
	for(kite=0;kite<n;kite++)
	{
		total=arr[i]+arr[j];
		if (total==no)
        {
			break;
        }
		if(total>no)
		{
			j--;
		}
		if(total<no)
		{
			i++;
		}
	}
	if(kite==n)
	{
		printf("NO");
	}
	else
	{
		printf("%d ",i);
		printf("%d ",j);
		printf("%d ",arr[i]);
		printf("%d ",arr[j]);
	}
	return 0;
}


#include <stdio.h>
int main(){
     {
        int length,sum,i,j=0,k=0,testsum;
        scanf("%d",&length);
        scanf("%d",&sum);
        int array[length];
        for (i=0; i<length; i++) {
            scanf("%d",&array[i]);
        }
        k=length-1;
        j=0;
        testsum=array[k]+array[j];
        while ((testsum!=sum)&&(k>j)) {
            if (testsum<sum){
                j++;
            }
            else if (testsum>sum){
                k--;
            }
            testsum=array[k]+array[j];
        }
        if (testsum==sum) {
            printf("%d %d %d %d",j,k,array[j],array[k]);
        }
        else{
            printf("NO");
        }
        

    }
    return 0;
}
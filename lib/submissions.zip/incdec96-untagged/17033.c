#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#define R(t) scanf("%lld",&t)
#define W(t) printf("%lld ",t)
#define ll long long

typedef struct node
{
	ll x;
	struct node *prev,*next;
}node;

node *top,*bottom,*itr;

void insertbeg(ll x)
{
	itr=(node*)malloc(sizeof(node));
	itr->x=x;
	if(top)
	{
		itr->next=top;top->prev=itr;
		itr->prev=NULL;
		top=itr;
	}
	else
	{
		top=bottom=NULL;
		top=bottom=itr;
		top->prev=NULL;
		bottom->next=NULL;
	}
}

void insertend(ll x)
{
	itr=(node*)malloc(sizeof(node));
	itr->x=x;
	if(bottom)
	{
		itr->prev=bottom;bottom->next=itr;
		itr->next=NULL;
		bottom=itr;
	}
	else
	{
		top=bottom=NULL;
		bottom=top=itr;
		top->prev=NULL;
		bottom->next=NULL;
	}
}

void printstart()
{
	itr=(node*)malloc(sizeof(node));
	itr=top;
	if(top==bottom)W(top->x);
	else
	{
		while(itr)
		{
			W(itr->x);itr=itr->next;
		}
	}
}

void printend()
{
	itr=(node*)malloc(sizeof(node));
	itr=bottom;
	if(top==bottom)W(top->x);
	else
	{
		while(itr)
		{
			W(itr->x);itr=itr->prev;
		}
	}
}

void deletebeg()
{
	itr=(node*)malloc(sizeof(node));
	itr=top;
	if(top==bottom)
	{
		top=bottom=NULL;free(itr);
	}
	else
	{
		(itr->next)->prev=NULL;
		top=top->next;
		free(itr);
	}
}

void deleteend()
{
	itr=(node*)malloc(sizeof(node));
	itr=bottom;
	if(top==bottom)
	{
		top=bottom=NULL;free(itr);
	}
	else
	{
		(itr->prev)->next=NULL;
		bottom=bottom->prev;
		free(itr);
	}
}

node* partition(node *l,node *h)
{
	if(l==h)return l;
	itr=(node*)malloc(sizeof(node));
	itr=l;
	ll val;
	node *i,*j;
	i=(node*)malloc(sizeof(node));
	j=(node*)malloc(sizeof(node));
	i=j=l;
	while(i && i!=h)
	{
		if(i->x<h->x)
		{
			val=j->x;
			j->x=i->x;
			i->x=val;
			j=j->next;
		}
		i=i->next;
	}
	val=h->x;
	h->x=j->x;
	j->x=val;
	return j;
}

void quickdllsort(node *a,node *b)
{
	node *p=(node*)malloc(sizeof(node));
	if(a && b && a!=b && b!=a->next)
	{
		p=partition(a,b);
		if(p->prev!=a && p->prev)quickdllsort(a,p->prev);
		if(p->next!=b && p->next)quickdllsort(p->next,b);
	}
}

int main()
{
	top=bottom=NULL;
	char a[20];scanf("%s",a);
	int flag=0;
	do
	{
		if(!strcmp(a,"insertbeg"))
		{
			ll x;R(x);
			insertbeg(x);
		}
		else if(!strcmp(a,"insertend"))
		{
			ll x;R(x);
			insertend(x);
		}
		else if(!strcmp(a,"deletebeg"))deletebeg();
		else if(!strcmp(a,"deletelast"))deleteend();
		else if(!strcmp(a,"stop"))
		{
			quickdllsort(top,bottom);
			int k;scanf("%d",&k);
			k==0?printstart():printend();
			flag=1;break;
		}
		scanf("%s",a);
	}while(flag==0);
	return 0;
}
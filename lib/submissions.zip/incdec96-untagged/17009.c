#include<stdio.h>
#include<stdlib.h>

int main()
{
    int n,a,i,j=0,k,sum;
    int* arr=(int*)malloc(100000000*sizeof(int));
    scanf("%d %d",&n,&a);
    for(i=0;i<n;i++)
    {
        scanf("%d",arr+i);
    }
    k=n-1;
    if(n<2)
    {
        printf("NO");
    }
  else{
   while(j!=k)
    {
        sum=arr[j]+arr[k];
        if(sum==a)
        {
            printf("%d %d %d %d",j,k,arr[j],arr[k]);
            break;
        }
        else if(sum<a)
        {
            j++;
        }
        else if(sum>a)
        {
            k--;
        }

    }
    if(j==k)
        {
            printf("NO");
        }
  }

    return 0;
}

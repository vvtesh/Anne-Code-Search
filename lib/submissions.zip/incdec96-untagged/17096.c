#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct _node {
int a;
struct _node* next;
struct _node* prev;
} node;
node *head;
node *tail;
int t=0,k;
void createlist()
{
    head=NULL;
    tail=NULL;
    t=1;

}

void insertbeg()
{
    if(head==NULL)
    {
        createlist();
    }
    node *temp;
    temp=(node*)malloc(sizeof(node));
    scanf("%d",&temp->a);
    temp->next=head;
    if(head!=NULL)
        head->prev=temp;
    if(head==NULL)
        tail=temp;
    head=temp;
    temp->prev=NULL;

}
void insertend()
{

    if(head==NULL)
    {
        createlist();
        insertbeg();
    }
    else
    {node *temp;
    temp=(node*)malloc(sizeof(node));
    scanf("%d",&temp->a);
     tail->next=temp;
    temp->prev=tail;
    temp->next=NULL;
    tail=temp;
    }

}
void printlist()
{
    int k;
    scanf("%d",&k);
    node *temp;
    if(k==0)
    {
        if(head==NULL)
        {
            printf("NULL\n\n");
        }
        else
        {


        temp=head;
        while(temp!=NULL)
            {   printf("%d\n",temp->a);
                temp=temp->next;
            }
        printf("\n");
        }
    }
    else if(k==1)
    {   if(head==NULL)
        {
            printf("NULL\n\n");
        }
        else
        {
        temp=tail;
        while(temp!=NULL)
            {   printf("%d\n",temp->a);
                temp=temp->prev;
            }
            printf("\n");
        }
    }
}

void deletebeg()
{
    node *temp;
    temp=head;
    if(head==NULL)
    {

    }
    else if(temp->next==NULL)
    {
        head=NULL;
        tail=NULL;
        free(temp);
    }
    else
    {
    node *temp;
    temp=head;
    head=head->next;
    head->prev=NULL;
    free(temp);
    }
}

void deletelast()
{   node *temp;
    temp=tail;
    if(head==NULL)
    {

    }
    else if(temp->prev==NULL)
    {
        head=NULL;
        tail=NULL;
        free(temp);
    }
    else
    {
    node *temp;
    temp=tail;
    tail=tail->prev;
    tail->next=NULL;
    free(temp);
    }
}

void sort()
{
 qusort(head,tail);
 printlist();
}
node * part(node *h,node *t)
{   int temp;
    int x=t->a;
    node *i=h->prev;
    node *j;
    for(j=h;j!=t;j=j->next)
    {
        if(j->a<=x)
        {
            if(i==NULL)
            {
                i=h;
            }
            else
                i=i->next;
            temp=i->a;
             i->a=j->a;
            j->a=temp;
        }
    }
    if(i==NULL)
            {
                i=h;
            }
            else
                i=i->next;
    temp=i->a;
    i->a=t->a;
    t->a=temp;
    return i;
}
void qusort(node *h,node* t)
{

    if(t!=NULL && h!=t && h!=t->next)
    {
        node *p=part(h,t);
        qusort(h,p->prev);
        qusort(p->next,t);
    }

}

int main()
{
    char a[20];
    while(1)
    {    scanf("%s",&a);
         if(strcmp(a,"insertbeg")==0)
         {
            insertbeg();
         }
         else if(strcmp(a,"stop")==0)
            {

            sort();
            exit(0);
            }
         else if(strcmp(a,"createlist")==0)
         {
             if(t==0)
             {createlist();
             }
         }

         else if(strcmp(a,"insertend")==0)
         {
            insertend();
         }
         else if(strcmp(a,"printlist")==0)
         {
             printlist();
         }
         else if(strcmp(a,"deletebeg")==0)
         {
             deletebeg();
         }
         else if(strcmp(a,"deletelast")==0)
         {
             deletelast();
         }

    }
    return 0;
}

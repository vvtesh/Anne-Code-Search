#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(){
    int n,a,i,flag=0;
    scanf("%d %d",&n,&a);
    int *arr=(int *)malloc(n*sizeof(int));

    for(i=0;i<n;i++){
        scanf("%d",&arr[i]);
        }

    int sum;int first=0,last=n-1;

    while(first<last){
        if((arr[first]+arr[last])==a){
            flag=1;
            printf("%d %d %d %d\n",first,last,arr[first],arr[last]);
            break;
        }
        else if((arr[first]+arr[last])<a){
            first++;
        }
        else{
            last--;
        }
    }
    if(flag==0){
        printf("NO");
    }
return 0;
}

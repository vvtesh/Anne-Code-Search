#include <stdio.h>
int main()
{
    int N,A;
    scanf("%d%d",&N,&A);
    int arr[N];
    int i,left,right,flag=0,sum;
    for (i=0;i<N;i++)
    {
        scanf("%d",&arr[i]);
    }
    left=0;right=N-1;
    while (left!=right)
    {
        sum=arr[left]+arr[right];
        if (sum<A)
            left++;
        else if (sum>A)
            right--;
        else
        {
        flag=1;break;
        }
    }
    if (flag==0)
        printf("NO");
    else
        printf("%d %d %d %d",left,right,arr[left],arr[right]);
    return 0;
}

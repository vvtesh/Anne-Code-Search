#include<stdio.h>
#include<stdlib.h>
int i,j;

int main()
{
 
 int size,a;
 scanf("%d %d",&size,&a);
 int *arr= (int *)malloc(size*sizeof(int));
 for(i=0;i<size;i++)
 {
    scanf("%d",&arr[i]);
 }
 for(i=0,j=size-1;i<j;)
 {
   if(arr[i]+arr[j]==a)
       {printf("%d %d %d %d",i,j,arr[i],arr[j]);
        return 0;
       }
   else
   if(arr[i]+arr[j]>a)
      j--; 
   else
      i++;
   
 }
    
    printf("NO");
    return 0;

}
	
	


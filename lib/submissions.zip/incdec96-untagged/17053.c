#include <stdio.h>

int main(void) {
	int i,j,mid,n,sum,flag;
	scanf("%d %d",&n,&sum);
	int arr[n];
	flag=0;
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	mid=n/2;
	j=n-1;
	i=0;
	while((i<mid || j>=mid) && i!=j)
	{
		if(arr[i]+arr[j]==sum)
		{
			printf("%d %d %d %d",i,j,arr[i],arr[j]);
			flag=1;
			break;
		}
		else if(arr[i]+arr[j]>sum)
		{
			j--;
		}
		else
		{
			i++;
		}
	}
	if(flag==0)
	{
		printf("NO");
	}
	
	return 0;
}

# include <stdio.h>

int main()
{
    int n;
    scanf("%d",&n);

    int sum;
    scanf("%d",&sum);

    int array[n];

    int i;
    for(i=0;i<=n-1;i++)
    {
        int d;
        scanf("%d",&d);
        array[i]=d;
    }

    int a, b;

    a = 0;
    b = n-1;
    int count=0;
    while(a < b)
    {
         if(array[a] + array[b] == sum)
              {
                  printf("%d %d %d %d",a,b,array[a],array[b]);
                  count++;
                  break;
              }
         else if(array[a] + array[b] < sum)
              a++;
         else if( array[a] + array[b] > sum)
              b--;

    }
    if(count==0)
    {
        printf("NO\n");
    }

    return 0;
}


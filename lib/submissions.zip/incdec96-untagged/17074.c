#include <stdio.h>

int func(int A[], int arr_size, int sum)
{
    int l, r;
    l = 0;
    r = arr_size-1; 
    while(l < r)
    {
         if(A[l] + A[r] == sum) {printf("%d %d %d %d\n",l,r,A[l],A[r]);return 1;} 
         else if(A[l] + A[r] < sum) l++;
         else r--;
    }    
    return 0;
}

int main()
{
	int n,k,i;
	scanf("%d %d",&n,&k);
	int a[n];
	for(i=0;i<n;i++) scanf("%d",&a[i]);
	if(func(a,n,k)==0) printf("NO\n");
	return 0;
} 

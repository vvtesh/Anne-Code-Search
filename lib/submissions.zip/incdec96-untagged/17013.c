#include<stdio.h>
int main()
{
	int N,A,l,r,i;
	scanf("%d",&N);
        scanf("%d",&A);
        int Arr[N];
		for(i=0;i<N;i++)
		{
			scanf("%d",&Arr[i]);
		}
		l=0;
		r=N-1;
	while(l<r)
	{
		if(Arr[l]+Arr[r]==A)
	break;
		else if(Arr[l]+Arr[r]<A)
		l++;
		else
		r--;
	}
	if(Arr[l]+Arr[r]==A)
		printf("%d %d %d %d",l,r,Arr[l],Arr[r]);
	else
    		printf("NO");
return 0;
}



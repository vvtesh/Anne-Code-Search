#include<stdio.h>
#include<stdlib.h>

int main()
{
int N, A, i, d=0;
scanf("%d%d", &N, &A);
int arr[N], b=0, c=(N-1);


for(i=0; i<N; i++)
{
 scanf("%d", &arr[i]);
}

while(b<c)
{
if ( arr[b]+arr[c]==A)
{
 printf("%d %d ",b,c);
 printf("%d %d ", arr[b], arr[c]);
 d++;
 exit(0);
}
else if (arr[b]+arr[c]<A)
{
b++;
}
else
{
c--;
}
}


if (d==0)
{
 printf("NO");
}
return 0;
}

#include<stdio.h>
int main()
{
    int n,a,i,x,y,flag=0;
    scanf("%d %d", &n, &a);
    int *ptr;
    ptr=(int *)malloc(sizeof(int)*n);
    for(i=0;i<n;i++)
    {
        scanf("%d",ptr+i);
    }
    x=0;
    y=n-1;
    while(x<y)
    {
        if(ptr[x]+ptr[y]<a)
        {
            x++;
        }
        else if(ptr[x]+ptr[y]>a)
        {
            y--;
        }
        else
        {
            printf("%d %d %d %d\n",x,y,ptr[x],ptr[y]);
            flag=1;
            break;
        }
    }
    if(flag==0)
        printf("NO\n");
    return 0;
}

#include<stdio.h>
#include<string.h>
#include<stdlib.h>


int main()
{
    long a,*arr,n,i,j,k;
    scanf("%ld%ld",&n,&a);
    arr=(long*)malloc(1000000*sizeof(long));
    for(i=0;i<n;i++)
    {
        scanf("%ld",&arr[i]);
    }
    j=n;
    i=0;

    for(k=0;k<n;k++)
    {
        //printf("sd");
        if(i>=j-1)
        {
            printf("NO\n");
            break;
        }
        if((arr[i]+arr[j-1])==a)
        {
            printf("%ld %ld %ld %ld\n",i,j-1,arr[i],arr[j-1]);
            break;
        }
        else if((arr[i]+arr[j-1])>a)
        {
            j--;
        }
        else
        {
            i++;
        }

    }

    return 0;
}

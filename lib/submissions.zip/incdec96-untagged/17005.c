#include<stdio.h>
#include<stdlib.h>
int binary_search(int l,int h,int a,int arr[])
{
    int mid=(h+l)/2;
    if(arr[mid]==a) return mid;
    else if(l>=h) return -h;
    else if (arr[mid]<a) return binary_search(mid+1,h,a,arr);
    else return binary_search(l,mid,a,arr);

}
int main()
{
    int n,a,i;
    scanf("%d %d",&n,&a);
    int *arr=(int *)malloc(n*sizeof(int));
    for(i=0;i<n;i++)
        scanf("%d",&arr[i]);
    int maxsearch=binary_search(0,n-1,a/2,arr);
    int m=binary_search(0,n-1,a,arr);
    if (maxsearch<0)
        maxsearch*=-1;
    if(m<0) m*=-1;
    int diff=0,j,fpos,spos;
    for(i=0;i<=maxsearch;i++)
    {
        j=binary_search(i+1,m,a-arr[i],arr);
        if(j<0);
        else {
        if(diff<j-i){
            diff=j-i;
            fpos=i;
            spos=j;}
        }
    }
    if(diff==0)
        printf("NO");
    else printf("%d %d %d %d",fpos,spos,arr[fpos],arr[spos]);
    return 0;
}

#include<stdio.h>

int main()
{
    int N,K,flag=0;
    scanf("%d %d",&N,&K);
    int i;
    int a[1000000];
    for (i=0;i<N;i++)
    {
        scanf("%d",&a[i]);
    }
    int sum,lo,hi;
    lo=0;
    hi=N-1;
    while (lo<=hi)
    {
        sum=a[lo]+a[hi];
        if (sum==K)
        {
            printf("%d %d %d %d",lo,hi,a[lo],a[hi]);
            flag=1;
            break;
        }
        else if (sum<K)
            lo++;
        else
            hi--;
    }
    if (flag==0)
        printf("NO\n");


    return 0;
}

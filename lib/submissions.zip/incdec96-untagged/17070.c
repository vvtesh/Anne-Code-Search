#include <stdio.h>
#include <stdlib.h>

int main()
{
	int len, sum;
	scanf("%d %d", &len, &sum);
	
	int *sorted;
	sorted = (int*)malloc(sizeof(int) * len);

	int i = 0;
	while(i < len)
	{
		scanf("%d", &sorted[i]);
		i++;
	}

	int lo = 0, hi = (len - 1), diff = 0;
	int idx_lo, idx_hi;

	while(hi > lo)
	{
		if((sorted[hi] + sorted[lo]) == sum)
		{
			if((sorted[hi] - sorted[lo]) > diff)
			{
				idx_lo = lo;
				idx_hi = hi;
				diff = (sorted[hi] - sorted[lo]);
			}
			lo++;
			hi--;
		}
		else if((sorted[hi] + sorted[lo]) > sum)
		{
			hi--;
		}
		else
		{
			lo++;
		}
	}

	if(diff == 0)
	{
		printf("NO");
	}
	else
	{
		printf("%d %d %d %d\n", idx_lo, idx_hi, sorted[idx_lo], sorted[idx_hi]);
	}
	return 0;
}
#include<stdio.h>
#include<stdlib.h>

int main()
{
	int t;
	long a, n, i, temp, j;
	scanf("%ld %ld", &n, &a);
	long arr[1000000];

	for(i = 0; i < n; i++)
	{
		scanf("%ld", &arr[i]);
	}

	for(i = 0, j = n - 1; i < j; )
	{
		temp = a - arr[i];
		if(temp == arr[j])
		{
			printf("%ld %ld %ld %ld", i, j, arr[i], arr[j]);
		 	break;
		}
		else if(temp < arr[j])
			j--;
		else if(temp > arr[j])
			i++;
	}

	if (i >= j)
		printf("NO");

	printf("\n");

	return 0;
}

#include <stdio.h>
#include <stdlib.h>
int bin(int search,int n,int array[])
{
    int first,last,middle;
    first=0;
   last=n-1;
   middle=(first+last)/2;

   while( first<=last )
   {
      if ( array[middle] < search )
         first = middle + 1;
      else if ( array[middle] == search )
      {
         return middle;
      }
      else
         last = middle - 1;

      middle = (first + last)/2;
   }
   return 0;
}
void main()
{
    int n,a,data;
    scanf("%d %d",&n,&a);
    int b[n];
    int i,j,flag=0;
    for(i=0;i<n;i++)
    {
        scanf("%d",&b[i]);
    }
    for(i=0;i<n;i++)
    {
        if (bin(a-b[i],n,b)!=0)
            {
                printf("%d %d %d %d\n",i,bin(a-b[i],n,b),b[i],a-b[i]);
                flag=1;
                break;
            }
        else
            continue;
    }
    if(flag==0)
        printf("NO\n");
}


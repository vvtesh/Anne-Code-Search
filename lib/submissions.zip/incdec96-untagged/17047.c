#include <stdio.h>
#include<string.h>
#include<stdlib.h>
int main(void)
{
	int n,l,x=0,i,j,s=0;
	scanf("%d%d",&n,&l);
	int *c=(int *)malloc(n*sizeof(int));
for(i=0;i<n;i++)
{
	scanf("%d",&c[i]);
}
i=0;
j=n-1;
while(i<=j)
{
	s=c[i]+c[j];
	if(s==l)
	{
	x=1;
	break;
	}
	if(s<l)
	i++;
	else
	j--;
	}
	if(x==1)
	printf("%d %d %d %d",i,j,c[i],c[j]);
	else
	printf("NO");
	return 0;
}

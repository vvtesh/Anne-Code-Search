#include<stdio.h>
#include<malloc.h>
int main()
{ int n;
  int sum;
  scanf("%d %d",&n,&sum); 	// parameter
  int *a;
  a=(int*)malloc(n*sizeof(int)); 	// parameter
  int i;
  for(i=0;i<n;i++) 	// loop,parameter
  {scanf("%d",&a[i]); 	// array,parameter
   
  }
  int j=0,k=n-1;
  int flag=0;
  while( j<k) 	// parameter
  { if((a[j]+a[k])==sum) 	// conditional,parameter,decrement,increment
    {flag=1; 
    break;
    }
    else if((a[j]+a[k])>sum) 	// parameter
           k--; 	// decrement
    else if((a[j]+a[k])<sum) 	// parameter
           j++; 	// increment
  }
  if(flag==0) 	// conditional,parameter,array
   printf("NO"); 	// parameter
  else 
   printf("%d %d %d %d",j,k,a[j],a[k]); 	// array,parameter
   return(0); 	// parameter
}
  

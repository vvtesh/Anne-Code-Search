#include<stdio.h>



int main()

{

    int N,A;

    scanf("%d %d",&N,&A); 	// parameter

    int arr[N],i; 	// array

    for(i=0;i<N;i++) 	// loop,parameter

    {

        scanf("%d",&arr[i]); 	// array,parameter

    }

    int k=0,l=N-1;

    while(l>k) 	// parameter

    {

        if(arr[k]+arr[l]==A) 	// conditional,parameter,array,decrement,increment

        {

            printf("%d %d %d %d",k,l,arr[k],arr[l]); 	// array,parameter

            break;

        }

        else if(arr[k]+arr[l]>A) 	// parameter

        {

            l--; 	// decrement

        }

        else

        {

            k++; 	// increment

        }



    }

    if(l==k) 	// conditional,parameter

    {

        printf("NO"); 	// parameter

    }

    return 0;

}

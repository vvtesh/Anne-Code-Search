#include <stdio.h>

long int ironman(long long int ,long int ,long long int []); 	// array

int main()

{

    long long int n,a;

    scanf("%lld %lld",&n,&a); 	// parameter

    long long int b[n+1]; 	// array

    int i,j,check=0;

    for(i=0;i<n;i++) 	// loop,parameter

    {

        scanf("%lld",&b[i]); 	// array,parameter

    }

    for(i=0;i<n;i++) 	// loop,parameter

    {

        if (ironman(a-b[i],n,b)!=0) 	// parameter,array

            {

                printf("%ld %ld %lld %lld\n",i,ironman(a-b[i],n,b),b[i],a-b[i]); 	// array,parameter

                check=1;

                break;

            }

    }

    if(check==0) 	// conditional,parameter

        printf("NO\n"); 	// parameter

    return 0;

}

long int ironman(long long int value,long int n,long long int list[]) 	// array

{

    long int first,last,middle;

    first = 0;

   last = n - 1;

   middle = (first+last)/2; 	// parameter



   while( first <= last ) 	// parameter

   {

      if ( list[middle] < value) 	// parameter,conditional

         first = middle + 1;

      else if ( list[middle] == value ) 	// conditional,parameter

      {

         return middle;

      }

      else

         last = middle - 1;



      middle = (first + last)/2; 	// parameter

   }

   return 0;

}

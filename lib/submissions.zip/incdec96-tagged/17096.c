#include<stdio.h>

#include<string.h>

#include<stdlib.h>



typedef struct _node { 	// function

int a;

struct _node* next; 	// pointer

struct _node* prev; 	// pointer

} node;

node *head;

node *tail;

int t=0,k;

void createlist() 	// function,parameter

{

    head=NULL;

    tail=NULL;

    t=1;



}



void insertbeg() 	// function,parameter

{

    if(head==NULL) 	// conditional,parameter

    {

        createlist(); 	// parameter

    }

    node *temp;

    temp=(node*)malloc(sizeof(node)); 	// parameter

    scanf("%d",&temp->a); 	// parameter

    temp->next=head;

    if(head!=NULL) 	// parameter

        head->prev=temp;

    if(head==NULL) 	// conditional,parameter

        tail=temp;

    head=temp;

    temp->prev=NULL;



}

void insertend() 	// function,parameter

{



    if(head==NULL) 	// conditional,parameter

    {

        createlist(); 	// parameter

        insertbeg(); 	// parameter

    }

    else

    {node *temp;

    temp=(node*)malloc(sizeof(node)); 	// parameter

    scanf("%d",&temp->a); 	// parameter

     tail->next=temp;

    temp->prev=tail;

    temp->next=NULL;

    tail=temp;

    }



}

void printlist() 	// function,parameter

{

    int k;

    scanf("%d",&k); 	// parameter

    node *temp;

    if(k==0) 	// conditional,parameter

    {

        if(head==NULL) 	// conditional,parameter

        {

            printf("NULL\n\n"); 	// parameter

        }

        else

        {





        temp=head;

        while(temp!=NULL) 	// parameter

            {   printf("%d\n",temp->a); 	// parameter

                temp=temp->next;

            }

        printf("\n"); 	// parameter

        }

    }

    else if(k==1) 	// conditional,parameter

    {   if(head==NULL) 	// conditional,parameter

        {

            printf("NULL\n\n"); 	// parameter

        }

        else

        {

        temp=tail;

        while(temp!=NULL) 	// parameter

            {   printf("%d\n",temp->a); 	// parameter

                temp=temp->prev;

            }

            printf("\n"); 	// parameter

        }

    }

}



void deletebeg() 	// function,parameter

{

    node *temp;

    temp=head;

    if(head==NULL) 	// conditional,parameter

    {



    }

    else if(temp->next==NULL) 	// conditional,parameter

    {

        head=NULL;

        tail=NULL;

        free(temp); 	// parameter

    }

    else

    {

    node *temp;

    temp=head;

    head=head->next;

    head->prev=NULL;

    free(temp); 	// parameter

    }

}



void deletelast() 	// function,parameter

{   node *temp;

    temp=tail;

    if(head==NULL) 	// conditional,parameter

    {



    }

    else if(temp->prev==NULL) 	// conditional,parameter

    {

        head=NULL;

        tail=NULL;

        free(temp); 	// parameter

    }

    else

    {

    node *temp;

    temp=tail;

    tail=tail->prev;

    tail->next=NULL;

    free(temp); 	// parameter

    }

}



void sort() 	// function,parameter

{

 qusort(head,tail); 	// parameter

 printlist(); 	// parameter

}

node * part(node *h,node *t) 	// parameter

{   int temp;

    int x=t->a;

    node *i=h->prev;

    node *j;

    for(j=h;j!=t;j=j->next) 	// loop,parameter

    {

        if(j->a<=x) 	// parameter

        {

            if(i==NULL) 	// conditional,parameter

            {

                i=h;

            }

            else

                i=i->next;

            temp=i->a;

             i->a=j->a;

            j->a=temp;

        }

    }

    if(i==NULL) 	// conditional,parameter

            {

                i=h;

            }

            else

                i=i->next;

    temp=i->a;

    i->a=t->a;

    t->a=temp;

    return i;

}

void qusort(node *h,node* t) 	// function,parameter

{



    if(t!=NULL && h!=t && h!=t->next) 	// conditional,parameter

    {

        node *p=part(h,t); 	// parameter

        qusort(h,p->prev); 	// parameter

        qusort(p->next,t); 	// parameter

    }



}



int main()

{

    char a[20]; 	// array

    while(1) 	// parameter

    {    scanf("%s",&a); 	// parameter

         if(strcmp(a,"insertbeg")==0) 	// conditional,parameter

         {

            insertbeg(); 	// parameter

         }

         else if(strcmp(a,"stop")==0) 	// conditional,parameter

            {



            sort(); 	// parameter

            exit(0); 	// parameter

            }

         else if(strcmp(a,"createlist")==0) 	// conditional,parameter

         {

             if(t==0) 	// conditional,parameter

             {createlist(); 	// parameter

             }

         }



         else if(strcmp(a,"insertend")==0) 	// conditional,parameter

         {

            insertend(); 	// parameter

         }

         else if(strcmp(a,"printlist")==0) 	// conditional,parameter

         {

             printlist(); 	// parameter

         }

         else if(strcmp(a,"deletebeg")==0) 	// conditional,parameter

         {

             deletebeg(); 	// parameter

         }

         else if(strcmp(a,"deletelast")==0) 	// conditional,parameter

         {

             deletelast(); 	// parameter

         }



    }

    return 0;

}

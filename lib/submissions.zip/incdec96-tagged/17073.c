#include<stdio.h>
int main()
{
	int A,n,i,low,top,z=0;
	int sum[4]; 	// array
	int *array;
	scanf("%d %d",&n,&A); 	// parameter
	array = (int*)malloc(n*sizeof(int)); 	// parameter
	for(i=0;i<n;i++) 	// loop,parameter
	{
		scanf("%d",&array[i]); 	// array,parameter
	}
    low = 0;
    top = n-1;
    sum[0]= -1; 	// array
    while(low < top) 	// parameter
    {
         if(array[low] + array[top] == A) 	// conditional,parameter,decrement,increment
         {
            if(z==1) 	// conditional,parameter,array
            {
                if((top-low)>(sum[3]-sum[2])) 	// parameter
                {
                    sum[2]=array[low]; 	// array
                    sum[3]=array[top]; 	// array
                    sum[0]=low; 	// array
                    sum[1]=top; 	// array
                }
            }
            else
            {
                sum[2]=array[low]; 	// array
                sum[3]=array[top]; 	// array
                sum[0]=low; 	// array
                sum[1]=top; 	// array
            }
            z=1;
            low--; 	// decrement
            top--; 	// decrement
         }  
         else if(array[low] + array[top] < A) 	// parameter
              low++; 	// increment
         else 
              top--; 	// decrement
    }
    if(z == 0) 	// conditional,parameter,array
    {
    	printf("NO"); 	// parameter
    }
    else
    {
    	printf("%d %d %d %d",sum[0],sum[1],sum[2],sum[3]); 	// array,parameter
    }
    return 0;    
}

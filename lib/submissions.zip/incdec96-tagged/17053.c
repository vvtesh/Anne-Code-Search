#include <stdio.h>



int main(void) {

	int i,j,mid,n,sum,flag;

	scanf("%d %d",&n,&sum); 	// parameter

	int arr[n]; 	// array

	flag=0;

	for(i=0;i<n;i++) 	// loop,parameter

	{

		scanf("%d",&arr[i]); 	// array,parameter

	}

	mid=n/2;

	j=n-1;

	i=0;

	while((i<mid || j>=mid) && i!=j) 	// parameter

	{

		if(arr[i]+arr[j]==sum) 	// conditional,parameter,array,decrement,increment

		{

			printf("%d %d %d %d",i,j,arr[i],arr[j]); 	// array,parameter

			flag=1;

			break;

		}

		else if(arr[i]+arr[j]>sum) 	// parameter

		{

			j--; 	// decrement

		}

		else

		{

			i++; 	// increment

		}

	}

	if(flag==0) 	// conditional,parameter

	{

		printf("NO"); 	// parameter

	}

	

	return 0;

}

#include <stdio.h>
#include <stdlib.h>

int main()
{
    long long n,sum;
    scanf("%lld %lld", &n, &sum); 	// parameter
    long long arr[n]; 	// array
    long long i;
    for(i=0;i<n;i++){ 	// loop,parameter
        scanf("%lld", &arr[i]); 	// array,parameter
    }
    i=0;
    long long j=n-1;
    int flag=0;
    while(i<j){ 	// parameter
        if(arr[i]+arr[j]<sum){ 	// conditional,parameter,increment,decrement
            i++; 	// increment
        }
        else if(arr[i]+arr[j]>sum){ 	// conditional,parameter
            j--; 	// decrement
        }
        else{
            flag=1;
            break;
        }
    }
    if(flag==1){ 	// conditional,parameter,array
        printf("%lld %lld %lld %lld\n", i,j,arr[i],arr[j]); 	// array,parameter
    }
    else{
        printf("NO\n"); 	// parameter
    }
    return 0;
}

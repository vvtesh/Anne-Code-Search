#include <stdio.h>

int main () {
int arr[1000000],n,a,i,l,r; 	// array
	scanf("%d %d",&n,&a); 	// parameter
	for (i=0;i<n;i++){ 	// loop,parameter
		scanf("%d",&arr[i]); 	// array,parameter
	}
	l = 0;
	r = n-1;
	while (l<r){ 	// parameter
		if(arr[l]+arr[r]==a){ 	// conditional,parameter,increment,decrement
			printf("%d %d %d %d\n",l,r,arr[l],arr[r]); 	// array,parameter
			return 0;
		}
		else if ((arr[l]+arr[r]) < a){ 	// conditional,parameter
			l++; 	// increment
		}
		else{
			r--; 	// decrement
		}
	}
	printf("NO\n"); 	// parameter
	return 0;
}

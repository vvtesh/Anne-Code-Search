#include <stdio.h>

int func(int A[], int arr_size, int sum) 	// array,parameter
{
    int l, r;
    l = 0;
    r = arr_size-1; 
    while(l < r) 	// parameter
    {
         if(A[l] + A[r] == sum) {printf("%d %d %d %d\n",l,r,A[l],A[r]);return 1;}  	// conditional,array,parameter,decrement,increment
         else if(A[l] + A[r] < sum) l++; 	// array,parameter,increment
         else r--; 	// decrement
    }    
    return 0;
}

int main()
{
	int n,k,i;
	scanf("%d %d",&n,&k); 	// parameter
	int a[n]; 	// array
	for(i=0;i<n;i++) scanf("%d",&a[i]); 	// parameter
	if(func(a,n,k)==0) printf("NO\n"); 	// conditional,parameter
	return 0;
} 

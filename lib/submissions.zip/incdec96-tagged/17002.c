#include<stdio.h>

#include<stdlib.h>



int main()

{

    int i, j,found=0;

    int f,s,pos1,pos2,N,A;

    int *arr;

    scanf("%d %d",&N,&A); 	// parameter

    arr=(int*)malloc(sizeof(int)*N); 	// parameter

    for(i=0;i<N;i++) 	// loop,parameter,array

    {

        scanf("%d",&arr[i]); 	// array,parameter

    }

    for(i=0;i<N;) 	// loop,parameter

    {

        if(arr[i]+arr[N-1] == A) 	// conditional,parameter,array

        {

            found=1;

            f=arr[i]; 	// array

            s=arr[N-1]; 	// array

            pos1=i;

            pos2=N-1;

            printf("%d %d %d %d",pos1,pos2,f,s); 	// parameter

        }

        i++; 	// increment

    }

    if(found==0) 	// conditional,parameter

        printf("NO"); 	// parameter



    return 0;

}

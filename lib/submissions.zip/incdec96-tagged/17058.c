#include<stdio.h>

int main()

{

	int total,tt,i,kite,j,n,no;



	scanf("%d%d",&n,&no); 	// parameter

	int arr[n]; 	// array

	for(tt=0;tt<n;tt++) 	// loop,parameter

	{

		scanf("%d",&arr[tt]); 	// array,parameter

	}

	i=0;

	j=n-1;

	for(kite=0;kite<n;kite++) 	// loop,parameter

	{

		total=arr[i]+arr[j]; 	// array

		if (total==no) 	// conditional,parameter

        {

			break;

        }

		if(total>no) 	// parameter,decrement,increment

		{

			j--; 	// decrement

		} else if(total<no) 	// parameter

		{

			i++; 	// increment

		}

	}

	if(kite==n) 	// conditional,parameter

	{

		printf("NO"); 	// parameter

	}

	else

	{

		printf("%d ",i); 	// parameter

		printf("%d ",j); 	// parameter

		printf("%d ",arr[i]); 	// array,parameter

		printf("%d ",arr[j]); 	// array,parameter

	}

	return 0;

}

#include<stdio.h>

#include<stdlib.h>

int main(void)

{

int N,A,i,j,c=0,sum;

scanf("%d %d",&N,&A); 	// parameter

int *arry=(int *)malloc(N*sizeof(int)); 	// parameter

    for(i=0;i<N;i++) 	// loop,parameter

    {

    scanf("%d",&arry[i]); 	// array,parameter

    }

     i=0;

     j=N-1;

        while(i<=j) 	// parameter

        {sum=arry[i]+arry[j]; 	// array

            if(sum==A) 	// conditional,parameter,increment,decrement

            {

                    c=1;

                    break;

            }

            else if(sum<A) 	// parameter



            i++; 	// increment



            else if(sum>A) 	// parameter

            j--; 	// decrement

        }



        if(c==1) 	// conditional,parameter,array

        {

        printf("%d %d %d %d",i,j,arry[i],arry[j]); 	// array,parameter

        printf("\n"); 	// parameter

        }

        else

        printf("NO"); 	// parameter

                    printf("\n"); 	// parameter

return 0;

}

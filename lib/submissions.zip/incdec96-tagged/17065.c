,#include<stdio.h>

int main()

{

    int siz,s,sum,i,elem,pos1=0,pos2=0,elem1=0,elem2=0,top,last;

    scanf("%d %d",&siz,&sum); 	// parameter

    int arr[siz]; 	// array

    for(i=0;i<=(siz-1);i++) 	// loop,parameter

    {

        scanf("%d",&elem); 	// parameter

        arr[i]=elem; 	// array

    }

    top=0;

    last=siz-1;

    for(i=0;i<=siz-1;i++) 	// loop,parameter

    {

        if(top>=last) 	// parameter

        {

            break;

        }

        s=arr[top]+arr[last]; 	// array

        if(s>sum) 	// parameter,decrement,increment

        {

            last--; 	// decrement

        }

        else if(s<sum) 	// parameter

        {

            top++; 	// increment

        }

        else

        {

            if((arr[last]-arr[top])>(elem2-elem1)) 	// parameter,array,increment,decrement

            {

                pos1=top;

                pos2=last;

                elem1=arr[top]; 	// array

                elem2=arr[last]; 	// array

                top++; 	// increment

                last--; 	// decrement

            }

            else

            {

                top++; 	// increment

                last--; 	// decrement

            }

        }

    }

    if(elem1!=0 || elem2!=0) 	// conditional,parameter

    {

        printf("%d %d %d %d\n",pos1,pos2,elem1,elem2); 	// parameter

    }

    else

        printf("NO"); 	// parameter



    return 0;

}

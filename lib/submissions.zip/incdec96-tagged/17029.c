#include<stdio.h>

int main()

{

    int j; int n;int sum;

    scanf("%d",&n); int a[n]; 	// array,parameter

    scanf("%d",&sum); 	// parameter

    for(j=0;j<n;j++) 	// loop,parameter

        scanf("%d",&a[j]); 	// array,parameter

    int i=0,k=n-1;

    int tempsum;

    while(i < k) 	// parameter

    {

        tempsum=a[i]+a[k]; 	// array



            if(tempsum == sum) 	// conditional,parameter,array,decrement,increment

            {

                printf("%d %d %d %d\n",i,k,a[i],a[k]); 	// array,parameter

                break;

                i++;k--; 	// decrement,increment

            }

            else if(tempsum<sum) 	// parameter

            {

               i++; 	// increment

            }

            else

            {

              k--; 	// decrement

            }





    }

    if(i>=k){ 	// conditional,parameter

    printf("NO");} 	// parameter



  return 0;

}

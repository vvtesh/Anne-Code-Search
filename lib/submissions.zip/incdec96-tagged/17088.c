#include <stdio.h>

#include <stdlib.h>



int main()

{

    int n,sum;

    int *a;

    int i,j;

    scanf("%d %d",&n,&sum); 	// parameter

    a = malloc(sizeof(int)*n); 	// parameter

    for(i=0;i<n;i++) 	// loop,parameter

        scanf("%d",&a[i]); 	// array,parameter

    int beg,end;

    int l,r,diff;

    l = r =0;

    int min=0;

    beg = 0;

    end = n-1;

    while(beg<end) 	// parameter

    {

        if((a[beg]+a[end]) == sum) 	// conditional,parameter,array,increment,decrement

        {

            printf("%d %d %d %d\n",beg,end,a[beg],a[end]); 	// array,parameter

            break;

        }

        else if((a[beg]+a[end]) < sum) 	// parameter

            beg++; 	// increment

        else

            end--; 	// decrement

    }

    if(beg>=end) 	// parameter

        printf("NO"); 	// parameter

    return 0;

}

#include <stdio.h>
#include <stdlib.h>

#define si(a) scanf("%d",&a) 	// parameter

int main(){
	//freopen("in", "r", stdin);
	int n,k,a[1000010],i=0,j=0; si(n); si(k); 	// array,parameter
	for(i=0;i<n;i++) 	// loop,parameter
		si(a[i]); 	// array,parameter
	i=0; j=n-1;
	while(a[i]+a[j]!=k&&i<n&&j>0){ 	// parameter
		if(i+j<k)i++; 	// parameter,increment,decrement
		else j--; 	// decrement
	}
	if(a[i]+a[j]==k) 	// conditional,parameter,array
		printf("%d %d %d %d", i, j, a[i], a[j]); 	// array,parameter
	else printf("NO"); 	// parameter
	return 0;
}

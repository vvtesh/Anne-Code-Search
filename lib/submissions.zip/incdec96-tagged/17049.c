#include<stdio.h>

#include<stdlib.h>

#include<malloc.h>

#include<string.h>

struct node

{

    int data;

    struct node* next; 	// pointer

    struct node* prev; 	// pointer

};



struct node *head , *last; 	// pointer



void createlist() 	// function,parameter

{

    head=last=NULL;

}



int count=0;



void insertbeg(int d) 	// function,parameter

{

    struct node *next,*temp; 	// pointer

    next= (struct node*)malloc(sizeof(struct node)); 	// parameter

    next->data=d;

    if(head==NULL) 	// conditional,parameter

    {

        head=next;

        head->prev=NULL;

        head->next=NULL;

        last=head;

    }

    else

    {

        temp=next;

        (temp).prev=NULL; 	// parameter

        (*temp).next=head; 	// parameter

        (*head).prev=temp; 	// parameter

        head=temp;

    }

}



void insertend(int d) 	// function,parameter

{

    struct node *next,*temp; 	// pointer

    next=(struct node*)malloc(sizeof(struct node)); 	// parameter

    next->data=d;

    if(head==0) 	// conditional,parameter

    {

        head=next;

        (*head).prev=NULL; 	// parameter

        (*head).next=NULL; 	// parameter

        last=head;

    }

    else

    {

        (*last).next=next; 	// parameter

        (*next).prev=last; 	// parameter

        last=next;

        (*last).next=NULL; 	// parameter

    }

}



void deletebeg() 	// function,parameter

{

    struct node *temp; 	// pointer

    if(head==NULL) 	// conditional,parameter

    {

        return;

    }

    else if(head->next==NULL) 	// conditional,parameter

    {

        temp=head;

        free(temp); 	// parameter

        head=last=NULL;

    }

    else

    {

        temp=head;

        head=head->next;

        free(temp); 	// parameter

        head->prev=NULL;

    }

}



void deletelast() 	// function,parameter

{

    struct node *temp; 	// pointer

    temp=last;

    if(temp==NULL) 	// conditional,parameter

    {

        return;

    }

    else if(temp->prev==NULL) 	// conditional,parameter

    {

        free(temp); 	// parameter

        head=NULL;

        last=NULL;

    }

    else

    {

        last=temp->prev;

        last->next=NULL;

        free(temp); 	// parameter

    }

}



void printlist(int k) 	// function,parameter

{

    struct node *temp,*next; 	// pointer

    if(k==0) 	// conditional,parameter

    {

        temp=head;

        if(temp==NULL) 	// conditional,parameter

        {

            printf("NULL\n\n"); 	// parameter

        }

        else

        {

            while(temp!=NULL) 	// parameter

            {

                printf("%d \n",temp->data); 	// parameter

                temp=temp->next;

            }

    }

    }

    if(k==1) 	// conditional,parameter

    {

        next=last;

        if(next==NULL) 	// conditional,parameter

        {

            printf("NULL\n\n"); 	// parameter

        }

        else

        {

            while(next!=NULL) 	// parameter

            {

                printf("%d\n",next->data); 	// parameter

                next=next->prev;

            }

        }

    }

}

struct node* partition(struct node *m, struct node *n) 	// argument,parameter

{

    int x  = n->data;

    struct node *j; 	// pointer

    struct node *i = m->prev;



    for ( j= m; j != n; j = j->next) 	// loop,parameter

    {

        if (j->data <= x) 	// parameter,conditional

        {

            i = (i == NULL)? m : i->next; 	// parameter

            swap(&(i->data), &(j->data)); 	// conditional,parameter

        }

    }

    i = (i == NULL)? m : i->next; 	// parameter

    swap(&(i->data), &(n->data)); 	// conditional,parameter

    return i;

}





void quickSort(struct node* l, struct node *h) 	// argument,function,parameter

{

    if (h != NULL && l != h && l != h->next) 	// conditional,parameter

    {

        struct node *p = partition(l, h); 	// parameter

        quickSort(l, p->prev); 	// parameter

        quickSort(p->next, h); 	// parameter

    }

}



void sortlist(struct node *head) 	// argument,function,parameter

{



    struct node *h = last;

    quickSort(head, h); 	// parameter

}



void swap(int *a,int *b) 	// pointer,function,parameter

{

int temp;

temp=*a;

*a=*b;

*b=temp;

}





int main()

{

    int n;

    char ch[25]; 	// array

    createlist(); 	// parameter

struct node *h,*t; 	// pointer

h=head;

t=last;

    while(1) 	// parameter

    {

        scanf("%s %d",&str,&n); 	// parameter

        if(strcmp(ch,"insertbeg")==0) 	// conditional,parameter

        {

            insertbeg(n); 	// parameter

        }

        else if(strcmp(ch,"insertend")==0) 	// conditional,parameter

        {

            insertend(n); 	// parameter

        }

        else if(strcmp(ch,"deletebeg")==0) 	// conditional,parameter

        {

            deletebeg(); 	// parameter

        }

        else if(strcmp(ch,"deletelast")==0) 	// conditional,parameter

        {

            deletelast(); 	// parameter

        }

        else if((strcmp(ch,"stop")==0)&&(n==0)) 	// conditional,parameter

        {

            sortlist(head); 	// parameter

            printlist(0); 	// parameter

            break;

        }

      else if((strcmp(ch,"stop")==0)&&(n==1)) 	// conditional,parameter

        {

            sortlist(head); 	// parameter

            printlist(1); 	// parameter

            break;

        }

    }

        return 0;

}

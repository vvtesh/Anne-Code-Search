#include<stdio.h>

int N,x;


int main()
{
  scanf("%d %d",&N,&x); 	// parameter


   int a[N],k; 	// array
  
   int i=0;
   int j = N-1;		//decrement

   for(k=0;k<N;k++) 	// loop,parameter
   {
 		scanf("%d",&a[k]); 	// array,parameter

   }
  
  
  
  
  while(i<j) 	// parameter
  {
     if(a[i] + a[j] == x)  	// conditional,parameter,array,increment,decrement
     {printf("%d %d %d %d", i, j, a[i], a[j]); break; 	// array,parameter
     }

     else if(a[i] + a[j] < x) i++; 	// array,parameter,increment

     else if (a[i] + a[j] > x) j--; 	// parameter,decrement
     
     else break;
     
   }
   
   if(i>=j) 	// parameter
    printf("NO"); 	// parameter






	return 0;
	
}	

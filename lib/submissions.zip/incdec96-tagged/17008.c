#include<stdio.h>

int main()

{

	int N,A,l,r,i;

	scanf("%d",&N); 	// parameter

        scanf("%d",&A); 	// parameter

        int J[N]; 	// array

	for(i=0;i<N;i++) 	// loop,parameter

	{

		scanf("%d",&J[i]); 	// array,parameter

	}

	l=0;

	r=N-1;

	while(l<r) 	// parameter

	{

		if(J[l]+J[r]==A) 	// conditional,parameter,increment,decrement

		break;

		else if(J[l]+J[r]<A) 	// parameter

		l++; 	// increment

		else

		r--; 	// decrement

	}

	if(J[l]+J[r]==A) 	// conditional,parameter,array

		printf("%d %d %d %d",l,r,J[l],J[r]); 	// array,parameter

	else

	    printf("NO"); 	// parameter

		

return 0;

}

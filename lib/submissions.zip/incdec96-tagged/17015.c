#include<stdio.h>

#define sll(n) scanf("%lld",&n) 	// parameter
#define fo(i,a,b)	for(i=a;i<b;i++) 	// loop,parameter
typedef long long ll;

ll a[1000001]; 	// array

int main()
{
	int flag=0;
	ll A,n,i,j,temp1,temp2;
	sll(n); 	// parameter
	sll(A); 	// parameter
	fo(i,0,n) 	// parameter
		sll(a[i]); 	// array,parameter
	i=0;
	j=n-1;
	while(i!=j) 	// parameter
	{
		if(a[i]+a[j]==A) 	// conditional,parameter
		{
			temp1=i;
			temp2=j;
			flag=1;
			break;
		}
		if(a[i]+a[j]>A) 	// parameter,decrement,increment
			j--; 	// decrement
		else
			i++; 	// increment

	}
	if(flag==0) 	// conditional,parameter,array
		printf("NO"); 	// parameter
	else
	{
		printf("%lld %lld %lld %lld",i,j,a[i],a[j]); 	// array,parameter
	}
	return 0;
}

#include<stdio.h>

int main()

{

    int N,s,A,i,element,position1=0,position2=0,element1=0,element2=0;

    scanf("%d %d",&N,&A); 	// parameter

    int first,last;

    int j,k;

    int array[N]; 	// array

    for(i=0;i<=(N-1);i++) 	// loop,parameter

    {

        scanf("%d",&element); 	// parameter

        array[i]=element; 	// array

    }

    first=0;

    last=N-1;

    for(i=0;i<=N-1;i++) 	// loop,parameter

    {

        if(first>=last) 	// parameter

        {

            break;

        }

        s=array[first]+array[last]; 	// array

        if(s>A) 	// parameter,decrement,increment

        {

            last--; 	// decrement

        }

        else if(s<A) 	// parameter

        {

            first++; 	// increment

        }

        else

        {

            if((array[last]-array[first])>(element2-element1)) 	// parameter,array,increment,decrement

            {

                position1=first;

                position2=last;

                element1=array[first]; 	// array

                element2=array[last]; 	// array

                first++; 	// increment

                last--; 	// decrement

                j=first;

                k=last;

            }

            else

            {

                first++; 	// increment

                last--; 	// decrement

            }

        }

    }

    if(element1!=0 || element2!=0) 	// conditional,parameter

    {

        printf("%d %d %d %d\n",position1,position2,element1,element2); 	// parameter

    }

    else

    {

        printf("NO"); 	// parameter

    }



    return 0;

}

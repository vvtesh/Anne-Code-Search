#include<stdio.h>

int main()

{

    int n,a,i,j,p,q,flag=0;

    scanf("%d",&n); 	// parameter

    scanf("%d",&a); 	// parameter

    int s[n]; 	// array

    for(i=0;i<n;i++) 	// loop,parameter

    {

        scanf("%d",&s[i]); 	// array,parameter

    }

    for(i=0,j=n-1;i<j;) 	// loop,parameter

    {

        if(s[i]+s[j]==a) 	// conditional,parameter,increment,decrement

        {

            flag=1;

            p=i;

            q=j;

            break;

        }

        else if(s[i]+s[j]<a) 	// parameter

        {

            i++; 	// increment

        }

        else

        {

            j--; 	// decrement

        }

    }



    if (flag==0) 	// conditional,parameter,array

        printf("NO"); 	// parameter

    else

        printf("%d %d %d %d",p,q,s[p],s[q]); 	// array,parameter

    return 0;

}

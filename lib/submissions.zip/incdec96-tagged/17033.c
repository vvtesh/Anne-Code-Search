#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#define R(t) scanf("%lld",&t) 	// parameter
#define W(t) printf("%lld ",t) 	// parameter
#define ll long long

typedef struct node
{
	ll x;
	struct node *prev,*next; 	// pointer
}node;

node *top,*bottom,*itr;

void insertbeg(ll x) 	// function,parameter
{
	itr=(node*)malloc(sizeof(node)); 	// parameter
	itr->x=x;
	if(top) 	// parameter,conditional
	{
		itr->next=top;top->prev=itr; 	// conditional
		itr->prev=NULL;
		top=itr;
	}
	else
	{
		top=bottom=NULL;
		top=bottom=itr;
		top->prev=NULL;
		bottom->next=NULL;
	}
}

void insertend(ll x) 	// function,parameter
{
	itr=(node*)malloc(sizeof(node)); 	// parameter
	itr->x=x;
	if(bottom) 	// parameter,conditional
	{
		itr->prev=bottom;bottom->next=itr; 	// conditional
		itr->next=NULL;
		bottom=itr;
	}
	else
	{
		top=bottom=NULL;
		bottom=top=itr;
		top->prev=NULL;
		bottom->next=NULL;
	}
}

void printstart() 	// function,parameter
{
	itr=(node*)malloc(sizeof(node)); 	// parameter
	itr=top;
	if(top==bottom)W(top->x); 	// conditional,parameter
	else
	{
		while(itr) 	// parameter
		{
			W(itr->x);itr=itr->next; 	// conditional,parameter
		}
	}
}

void printend() 	// function,parameter
{
	itr=(node*)malloc(sizeof(node)); 	// parameter
	itr=bottom;
	if(top==bottom)W(top->x); 	// conditional,parameter
	else
	{
		while(itr) 	// parameter
		{
			W(itr->x);itr=itr->prev; 	// conditional,parameter
		}
	}
}

void deletebeg() 	// function,parameter
{
	itr=(node*)malloc(sizeof(node)); 	// parameter
	itr=top;
	if(top==bottom) 	// conditional,parameter
	{
		top=bottom=NULL;free(itr); 	// parameter
	}
	else
	{
		(itr->next)->prev=NULL; 	// conditional,parameter
		top=top->next;
		free(itr); 	// parameter
	}
}

void deleteend() 	// function,parameter
{
	itr=(node*)malloc(sizeof(node)); 	// parameter
	itr=bottom;
	if(top==bottom) 	// conditional,parameter
	{
		top=bottom=NULL;free(itr); 	// parameter
	}
	else
	{
		(itr->prev)->next=NULL; 	// conditional,parameter
		bottom=bottom->prev;
		free(itr); 	// parameter
	}
}

node* partition(node *l,node *h) 	// parameter
{
	if(l==h)return l; 	// conditional,parameter
	itr=(node*)malloc(sizeof(node)); 	// parameter
	itr=l;
	ll val;
	node *i,*j;
	i=(node*)malloc(sizeof(node)); 	// parameter
	j=(node*)malloc(sizeof(node)); 	// parameter
	i=j=l;
	while(i && i!=h) 	// parameter
	{
		if(i->x<h->x) 	// parameter
		{
			val=j->x;
			j->x=i->x;
			i->x=val;
			j=j->next;
		}
		i=i->next;
	}
	val=h->x;
	h->x=j->x;
	j->x=val;
	return j;
}

void quickdllsort(node *a,node *b) 	// function,parameter
{
	node *p=(node*)malloc(sizeof(node)); 	// parameter
	if(a && b && a!=b && b!=a->next) 	// conditional,parameter
	{
		p=partition(a,b); 	// parameter
		if(p->prev!=a && p->prev)quickdllsort(a,p->prev); 	// conditional,parameter
		if(p->next!=b && p->next)quickdllsort(p->next,b); 	// conditional,parameter
	}
}

int main()
{
	top=bottom=NULL;
	char a[20];scanf("%s",a); 	// array,parameter
	int flag=0;
	do
	{
		if(!strcmp(a,"insertbeg")) 	// parameter
		{
			ll x;R(x); 	// parameter
			insertbeg(x); 	// parameter
		}
		else if(!strcmp(a,"insertend")) 	// parameter
		{
			ll x;R(x); 	// parameter
			insertend(x); 	// parameter
		}
		else if(!strcmp(a,"deletebeg"))deletebeg(); 	// parameter
		else if(!strcmp(a,"deletelast"))deleteend(); 	// parameter
		else if(!strcmp(a,"stop")) 	// parameter
		{
			quickdllsort(top,bottom); 	// parameter
			int k;scanf("%d",&k); 	// parameter
			k==0?printstart():printend(); 	// parameter
			flag=1;break;
		}
		scanf("%s",a); 	// parameter
	}while(flag==0); 	// parameter
	return 0;
}

#include <stdio.h>
int main()
{
    long long int n,s;
    scanf("%lld %lld",&n,&s); 	// parameter
    long long int a[n],i,j; 	// array
    for(i=0;i<n;i++) 	// loop,parameter
    {
        scanf("%lld",&a[i]); 	// array,parameter
    }
    i=0;j=n-1;
    long long int sum;
    while(i!=j) 	// parameter
    {
        sum=a[i]+a[j]; 	// array
        if(sum>s) 	// parameter,decrement,increment,conditional,array
        {
            j--; 	// decrement
        }
        else if(sum<s) 	// parameter
        {
            i++; 	// increment
        }
        else if(sum==s) 	// conditional,parameter
        {
            printf("%lld %lld %lld %lld\n",i,j,a[i],a[j]); 	// array,parameter
            break;
        }
    }
    if(i==j) 	// conditional,parameter
    {
        printf("NO\n"); 	// parameter
    }
    return 0;
}

#include<stdio.h>

int main()

{

int n,sum,i,j,flag=0;

scanf("%d %d",&n,&sum); 	// parameter

int a[n]; 	// array

for(i=0;i<n;i++) 	// loop,parameter

{

scanf("%d",&a[i]); 	// array,parameter

}

i=0;

j=n-1;

while(i<j) 	// parameter

{

if(a[i]+a[j]==sum) 	// conditional,parameter,decrement,increment

   {

    printf("%d %d %d %d",i,j,a[i],a[j]); 	// array,parameter

    flag=1;

    break;

   }

else if(a[i]+a[j]>sum) 	// parameter

    j--; 	// decrement

else

    i++; 	// increment

}

if(!flag) 	// parameter

    printf("NO"); 	// parameter

return 0;

}

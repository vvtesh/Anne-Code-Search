#include <stdio.h>
#include <stdlib.h>


int main()
{
	int len, sum;

	scanf("%d %d", &len, &sum); 	// parameter

	int arr[len]; 	// array

	int i = 0;
	for (i;i<len;i++) scanf("%d",&arr[i]); 	// array,parameter

		int j = len-1;		//decrement

		for (j;j>0;j--) 	// loop,parameter
		{
			for (i = 0;i<j;i++) 	// loop,parameter
			{
				if (arr[i] + arr[j] == sum) 	// conditional,parameter,array, decrement
				{
					printf("%d %d %d %d\n", i, j, arr[i], arr[j] ); 	// array,parameter
					return 0;
				}
				else if (arr[i] + arr[j] > sum) 	// parameter
					i = j-1;	//decrement
			}
		}
		printf("NO\n"); 	// parameter
		return 0;
}

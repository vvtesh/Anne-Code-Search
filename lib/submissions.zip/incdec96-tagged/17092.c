#include <stdio.h>
#include <stdlib.h>

int main()
{
	int *arr = (int*)malloc(sizeof(int)); 	// parameter
	int n, a, i;
	scanf ("%d %d", &n, &a); 	// parameter
	
	if ((n<1) || (n>1000000) || (a<1) || (a>1000000000)) 	// parameter
	{
		return 0;
	}
	/*
	else if ((a<1) || a>1000000000) 	// parameter
	{
		return 0;
	}
	*/
	int x;
	for (i=0; i<n; i++) 	// loop,parameter
	{
		scanf("%d", &x); 	// parameter
		if (x<1 || x>1000000000) 	// parameter,array
		{
			return 0;
		}
		else
		{
			arr[i]=x; 	// array
		}
	}

	int j, count;
	
	i = 0;
	j = n-1;

	while (i<j) 	// parameter
	{
		if(arr[i]+arr[j]==a) 	// conditional,parameter,array,increment,decrement
		{
			printf("%d %d %d %d\n", i, j, arr[i], arr[j]); 	// array,parameter
			count =1;
			break;
		}
		else if (arr[i]+arr[j]<a) 	// parameter
		{
			i++; 	// increment
		} 
		else if (arr[i]+arr[j]>a) 	// parameter
		{
			j--; 	// decrement
		}
	}

	if (count!=1) 	// parameter
	{
		printf("NO"); 	// parameter
		return 0;
	}
	else
	{
		return 0;
	}
}

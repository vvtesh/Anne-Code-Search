#include <stdio.h>
#include <stdlib.h>

int main()
{
	int len, sum;
	scanf("%d %d", &len, &sum); 	// parameter
	
	int *sorted;
	sorted = (int*)malloc(sizeof(int) * len); 	// parameter

	int i = 0;
	while(i < len) 	// parameter
	{
		scanf("%d", &sorted[i]); 	// array,parameter
		i++; 	// increment
	}

	int lo = 0, hi = (len - 1), diff = 0; 	// parameter
	int idx_lo, idx_hi;

	while(hi > lo) 	// parameter
	{
		if((sorted[hi] + sorted[lo]) == sum) 	// conditional,parameter,increment,decrement
		{
			if((sorted[hi] - sorted[lo]) > diff) 	// parameter
			{
				idx_lo = lo;
				idx_hi = hi;
				diff = (sorted[hi] - sorted[lo]); 	// array,parameter
			}
			lo++; 	// increment
			hi--; 	// decrement
		}
		else if((sorted[hi] + sorted[lo]) > sum) 	// parameter
		{
			hi--; 	// decrement
		}
		else
		{
			lo++; 	// increment
		}
	}

	if(diff == 0) 	// conditional,parameter
	{
		printf("NO"); 	// parameter
	}
	else
	{
		printf("%d %d %d %d\n", idx_lo, idx_hi, sorted[idx_lo], sorted[idx_hi]); 	// array,parameter
	}
	return 0;
}

#include<stdio.h>
#include<stdlib.h>

struct node
{
int x;
struct node *prev; 	// pointer
struct node *next; 	// pointer
}*start=NULL,*tail=NULL; 






int insertend(int x) 	// parameter
{
struct node *temp,*save=start;
if(start==NULL&&tail==NULL) 	// conditional,parameter
{
start=(struct node *)malloc(sizeof(struct node)); 	// parameter
start->x=x;
start->next=NULL;
start->prev=NULL;
tail=start;
}
else
{
temp=(struct node *)malloc(sizeof(struct node)); 	// parameter
temp->x=x;
tail->next=temp;
temp->prev=tail;
temp->next=NULL;
tail=temp;
}
return 0;
}




int search(int n,int N,struct node *temp,struct node *last) 	// parameter
{
int i=1,j=N,M=N,k=0;
while(M>0) 	// parameter
{
if((temp->x+last->x)==n){ 	// conditional,parameter,increment,decrement
printf("%d %d %d %d\n",i-1,j-1,temp->x,last->x); 	// conditional,parameter
k=1;
break;
}
else if((temp->x+last->x)>n){ 	// conditional,parameter
last=last->prev;
j--;}
else if((temp->x+last->x)<n){ 	// conditional,parameter
temp=temp->next;
i++;} 	// increment
M--; 	// decrement
}
if(k==0) 	// conditional,parameter
printf("NO\n"); 	// parameter
return(0); 	// parameter
}





int main()
{
int N,x,A,i;
scanf("%d%d",&N,&A); 	// parameter
for(i=0;i<N;i++){ 	// loop,parameter
scanf("%d",&x); 	// parameter
insertend(x); 	// parameter
}
struct node *temp=start;
struct node *save=start;
struct node *last=tail;
search(A,N,temp,last); 	// parameter
return(0); 	// parameter
}

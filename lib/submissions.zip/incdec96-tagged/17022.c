#include<stdio.h>

#include<stdlib.h>



#define rep(i,s,e) for(i=s;i<=e;i++) 	// loop,parameter

#define rrep(i,s,e) for(i=s;i>=e;i--) 	// loop,parameter



long long ARR[1000100]; 	// array



long long main() 	// parameter

{

  long long i,N,A,j,flag=0;



  scanf("%lld%lld",&N,&A); 	// parameter

  rep(i,0,N-1) 	// parameter

  {

      scanf("%lld",&ARR[i]); 	// array,parameter

  }



  for(i=0,j=N-1;i<N/2,j>N/2;)

  {

      if(ARR[i]+ARR[j]<A) 	// parameter,increment,decrement,conditional

        i++; 	// increment

      else if(ARR[i]+ARR[j]>A) 	// parameter

        j--; 	// decrement

      else if(ARR[i]+ARR[j]==A) 	// conditional,parameter

      {

          flag=1;

          break;

      }

  }



  if(flag==1) 	// conditional,parameter

  {

       printf("%lld %lld %lld %lld",i,j,ARR[i],ARR[j]); 	// array,parameter

  }

  else

       printf("NO"); 	// parameter



  return 0;

}

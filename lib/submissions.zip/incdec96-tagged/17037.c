#include <stdio.h>
#include <stdlib.h>
int main()
{
	int n,a,i,j;
	int *x;
	scanf("%d", &n); 	// parameter
	x=malloc(sizeof(int)*n); 	// parameter
	scanf("%d", &a); 	// parameter
	for (i=0; i<n; i++) 	// loop,parameter
	{
		scanf("%d", x+i); 	// parameter
	}
	i=0;
	j=n-1;
	while (i<j) 	// parameter
	{
		if (x[i]+x[j]==a) 	// conditional,parameter,array,increment,decrement
		{
			printf("%d %d %d %d\n", i,j,x[i],x[j]); 	// array,parameter
			break;
			i++; 	// increment
			j--; 	// decrement
		}
		else if (x[i]+x[j]<a) 	// parameter
		{
			i++; 	// increment
		}
		else if (x[i]+x[j]>a) 	// parameter
			j--; 	// decrement
	}
	if (x[i]+x[j]!=a) 	// parameter
			printf("NO\n"); 	// parameter
		return 0;
}

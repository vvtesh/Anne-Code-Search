#include <stdio.h>

#include <string.h>



int main()

{

	int N,i,j;

	unsigned long A;

	scanf("%d %lu", &N, &A); 	// parameter

	unsigned long array[N]; 	// array

	

	for(i=0;i<N;i++) 	// loop,parameter

	{

		scanf("\n %lu", &array[i]); 	// array,parameter

	}

	

	i=0,j=N-1;

	

	while(i<j) 	// parameter

	{

		if(array[i]+array[j]==A) 	// conditional,parameter,array,increment,decrement

		{

			printf("%d %d %lu %lu\n",i,j,array[i],array[j]); 	// array,parameter

			return 0;

		

		}

		else if(array[i]+array[j]<A) 	// parameter

		{

			i++; 	// increment

		}

		else

		{

			j--; 	// decrement

		}

	}

	

	printf("NO \n"); 	// parameter

	return 0;

}

#include<stdio.h>

void main(){ 	// function

    int x,y,start=0,last=0,sum=0,e=0;



    scanf("%d %d",&x,&y); 	// parameter

    int a[x]; 	// array

    for (last=0;last<x;last++){ 	// loop,parameter

        scanf("%d",&a[last]); 	// array,parameter

    }

    last=last-1;

    while(start<last){ 	// parameter

        sum=a[start]+a[last]; 	// array

        if (sum==y){ 	// conditional,parameter,array,increment,decrement

                e=1;

                printf("%d %d %d %d",start,last,a[start],a[last]); 	// array,parameter

                break;



        }

        else if (sum<y){ 	// conditional,parameter

            start=start+1; //increment

        }

        else if (sum>y){ 	// conditional,parameter

            last=last-1; //decrement

        }

    }

    if (e==0){ 	// conditional,parameter

        printf("NO"); 	// parameter

    }



}

#include<stdio.h>

int main()

{

    int n,a,i,x,y,flag=0;

    scanf("%d %d", &n, &a); 	// parameter

    int *ptr;

    ptr=(int *)malloc(sizeof(int)*n); 	// parameter

    for(i=0;i<n;i++) 	// loop,parameter

    {

        scanf("%d",ptr+i); 	// parameter

    }

    x=0;

    y=n-1;

    while(x<y) 	// parameter

    {

        if(ptr[x]+ptr[y]<a) 	// parameter,increment,decrement

        {

            x++; 	// increment

        }

        else if(ptr[x]+ptr[y]>a) 	// parameter

        {

            y--; 	// decrement

        }

        else

        {

            printf("%d %d %d %d\n",x,y,ptr[x],ptr[y]); 	// array,parameter

            flag=1;

            break;

        }

    }

    if(flag==0) 	// conditional,parameter

        printf("NO\n"); 	// parameter

    return 0;

}

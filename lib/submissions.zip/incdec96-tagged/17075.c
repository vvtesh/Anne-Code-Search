#include<stdio.h>
#include<stdlib.h>

void pair(int *a,int size,int s) 	// function,parameter
{
	int i=0,j=(size-1),sum=0; 	// parameter
	while(i<j && i<(size-1) && j>0) 	// parameter
	{
		sum=a[i]+a[j]; 	// array
		if(s > sum) 	// parameter,increment,decrement
			i++; 	// increment
		else if(s < sum) 	// parameter
			j--; 	// decrement
		else
			break;
	}
	if(sum!=s) 	// parameter,array
		printf("NO\n"); 	// parameter
	else
		printf("%d %d %d %d\n",i,j,a[i],a[j]); 	// array,parameter
}

int main()
{
	int size=0,no=0,i=0;
	scanf("%d",&size); 	// parameter
	int *a=malloc(sizeof(*a)*size); 	// parameter
	scanf("%d",&no); 	// parameter
	while(i<size) 	// parameter
	{
		scanf("%d",&a[i]); 	// array,parameter
		i++; 	// increment
	}
	pair(a,size,no); 	// parameter
	return 0;
}

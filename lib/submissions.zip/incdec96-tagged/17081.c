#include <stdio.h>



int main(){

int min,max,i,size,num,j,flag;



scanf("%d%d",&size,&num); 	// parameter

int A[size]; 	// array

for(i=0;i<size;++i) 	// loop,parameter

    scanf("%d",&A[i]); 	// array,parameter



flag=0;

i=0;

j=size-1;



while(i<j){ 	// parameter

    if(A[i]+A[j]==num){ 	// conditional,parameter,array,increment,decrement

        flag=1;

        printf("%d %d %d %d",i,j,A[i],A[j]); 	// array,parameter

        break;

     }

     else if (A[i]+A[j]<num) 	// parameter

        i++; 	// increment

     else

        j--; 	// decrement

}



if (flag==0) 	// conditional,parameter

    printf("NO"); 	// parameter

return 0;

}

#include<stdio.h>
int main(){
	int A[1000000],N,b,i; 	// array
	scanf("%d",&N); 	// parameter
     	scanf("%d",&b); 	// parameter
	for(i=0;i<N;i++){ 	// loop,parameter
		scanf("%d",&A[i]); 	// array,parameter
	}
	int c=0,d=N-1;
	while(c<d){         	// parameter
		if(A[c]+A[d]==b){ 	// conditional,parameter,increment,decrement
		printf("%d %d %d %d\n",c,d,A[c],A[d]); 	// array,parameter
		break;
		}
			else if(A[c]+A[d]<b){ 	// conditional,parameter
			c=c+1; //increment
			}
				else if(A[c]+A[d]>b){ 	// conditional,parameter
 					d=d-1; //decrement
				}
	}
	if(A[c]+A[d]!=b){ 	// conditional,parameter
		printf("NO\n");	 	// parameter
	}
	return 0;
}

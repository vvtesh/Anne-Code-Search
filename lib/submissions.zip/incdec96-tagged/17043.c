#include <stdio.h>

#include <stdlib.h>

#include <math.h>



int main()

{

    int a, b,i=0, *arr,end,flag=1;

    scanf("%d%d",&a,&b); 	// parameter

    arr = (int*)malloc(a*sizeof(int)); 	// parameter

    while(i<a) 	// parameter

    {

        scanf("%d",arr+i); 	// parameter

        i++; 	// increment

    }

    i=0;

    end=a-1;

    while(i<end) 	// parameter

    {

        if(*(arr+i)+ *(arr+end)==b){ 	// conditional,parameter,increment,decrement

            printf("%d %d %d %d\n",i,end,*(arr+i),*(arr+end)); 	// parameter,increment

            flag=0;

            break;

        }

        else if(*(arr+i)+ *(arr+end)>=b) 	// parameter

            end--; 	// decrement

        else

            i++; 	// increment

    }

    if(flag==1) 	// conditional,parameter

        printf("NO"); 	// parameter

    return 0;

}

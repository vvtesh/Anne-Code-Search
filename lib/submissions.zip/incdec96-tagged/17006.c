#include<stdio.h>
int main()
{
    unsigned long A[1000000]; 	// array
    unsigned long n,sum,temp,k,i,j=0;
    int a=1;
    scanf("%lu %lu",&n,&sum); 	// parameter
    for(i=0;i<n;i++) 	// loop,parameter
    {
       scanf("%lu",&A[i]); 	// array,parameter
    }
    k=n-1;
while(j<k) 	// parameter
{
    temp=A[j]+A[k]; 	// array
    if(temp==sum) 	// conditional,parameter,decrement,increment
    {
        printf("%lu %lu %lu %lu\n",j,k,A[j],A[k]); 	// array,parameter
        a=0;
        break;
    }
    else if(temp>sum) 	// parameter
    {
        k--; 	// decrement
    }
    else
    {
       j++; 	// increment
    }
}
if(a!=0) 	// parameter
{
   printf("NO\n"); 	// parameter
}

return 0;
}

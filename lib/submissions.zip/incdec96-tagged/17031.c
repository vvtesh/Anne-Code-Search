#include<stdio.h>



int main()

{

    int n,a,i,d,index1,index2;

    scanf("%d %d",&n,&a); 	// parameter

    int arr[n]; 	// array

    for(i=0;i<n;i++) 	// loop,parameter

    {

        scanf("%d",&arr[i]); 	// array,parameter

    }

    index1=0;

    index2=n-1;

    while(index2>index1) 	// parameter

        {

            if(arr[index1]+arr[index2] < a) 	// parameter,increment,decrement,array

            {

                index1++; 	// increment

            }

            else if(arr[index1]+arr[index2] > a) 	// parameter

            {

                index2--; 	// decrement

                i=index1;

            }

            else

            {

                printf("%d %d %d %d",index1,index2,arr[index1],arr[index2]); 	// array,parameter

                return(0); 	// parameter

            }

        }

    printf("NO"); 	// parameter

    return(0); 	// parameter

}

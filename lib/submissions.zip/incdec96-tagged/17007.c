#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
struct point{ 	// function
    int x;
    int y;
    
};
struct node { 	// function
    struct point a;
    struct node * next; 	// pointer
    struct node * prev; 	// pointer
};

struct node *head=NULL;
struct node *tail=NULL;
struct node *new; 	// pointer


void create_list() 	// function,parameter
{
    new=(struct node*)malloc(1*sizeof(struct node)); 	// parameter
}

void insert_beg() 	// function,parameter
{   int data1;
    int data2;
    scanf("%d %d",&data1,&data2); 	// parameter
    //struct node * new;
    //new=(struct node*)malloc(1*sizeof(struct node));
    if(data1>=1 && data2<=pow(10.0,9) && data2>=1 && data2<=pow(10.0,9)) 	// conditional,parameter
    {
    new->a.x=data1;
    new->a.y=data2;
    if(head==NULL) 	// conditional,parameter
    {
        head=new;
        tail=new;
        new->next=NULL;
        new->prev=NULL;
        
    }
    else
    {
        new->next=head;
        head->prev=new;
        new->prev=NULL;
        head=new;
    }
    }
    
}

void insert_end() 	// function,parameter
{   int data1;
    int data2;
    scanf("%d %d",&data1,&data2); 	// parameter
    //struct node * new;
    //new=(struct node *)malloc(1*sizeof(struct node));
    if(data1>=1 && data2<=pow(10.0,9) && data2>=1 && data2<=pow(10.0,9)) 	// conditional,parameter
    {new->a.x=data1;
    new->a.y=data2;
    if(tail==NULL) 	// conditional,parameter
    {
        head=new;
        tail=new;
        new->next=NULL;
        new->prev=NULL;
    }
    else
    {
        tail->next=new;
        new->prev=tail;
        new->next=NULL;
        tail=new;
        
    }
    }
}


void print_list() 	// function,parameter
{   int type;
    scanf("%d",&type); 	// parameter
    if(type==0) 	// conditional,parameter
    //traverse from beginning
    {
        struct node *current; 	// pointer
        current=head;
        if(head==NULL && tail==NULL) 	// conditional,parameter
        {
            printf("NULL\n"); 	// parameter
            printf("\n"); 	// parameter
        }
        else{
        while(current->next!=NULL) 	// parameter
        {
            printf("%d %d\n",current->a.x,current->a.y); 	// conditional,parameter
            current=current->next;
        }
        printf("%d %d\n",tail->a.x,tail->a.y); 	// conditional,parameter
        printf("\n"); 	// parameter
        }
    }
    else if(type==1)//traverse from end 	// conditional,parameter
    {
        if(tail==NULL && head==NULL) 	// conditional,parameter
        {
            printf("NULL\n"); 	// parameter
            printf("\n"); 	// parameter
        }
        else
        {struct node *current;
        current=tail;
        while(current->prev!=NULL) 	// parameter
        {
            printf("%d %d\n",current->a.x,current->a.y); 	// conditional,parameter
            current=current->prev;
        }
        printf("%d %d\n",head->a.x,head->a.y); 	// conditional,parameter
        printf("\n"); 	// parameter
        }
    
    }
    
}



void delete_beg() 	// function,parameter
{
    struct node *temp; 	// pointer
    temp=head;
    if(head->next!=NULL) 	// parameter
    {
    head=head->next;
    head->prev=NULL;
    free(temp); 	// parameter
    }
    else
    {
        free(temp); 	// parameter
        tail=NULL;
        head=NULL;
    }
    
}


void delete_end() 	// function,parameter
{
    struct node *temp; 	// pointer
    temp=tail;
    if(tail->prev!=NULL) 	// parameter
    {   tail=tail->prev;
        tail->next=NULL;
        free(temp); 	// parameter
    }
    else
    {   free(temp); 	// parameter
        tail=NULL;
        head=NULL;
    }
}


void delete_list() 	// function,parameter
{   if(head==NULL && tail==NULL) 	// conditional,parameter
    {;}
   else{
    
    struct node *temp; 	// pointer
    while(head!=tail) 	// parameter
    {
        temp=head;
        head=head->next;
        free(temp); 	// parameter
        
    }
    free(tail); 	// parameter
    head=NULL;
    tail=NULL;
   }
}

int main()
{
    
    
    //printf("HELLO WORLD\n");
    char string[100]; 	// array
    int create=0;
    while(1) 	// parameter
    {
        
        scanf("%s",string); 	// parameter
        if(strcmp(string,"createlist")==0) 	// conditional,parameter,increment
        {   create++; 	// increment
            if(create==1) 	// conditional,parameter
            {
            create_list(); 	// parameter
            }
        }
        if(strcmp(string,"insertbeg")==0) 	// conditional,parameter
        {   if(create!=1) 	// parameter
            {create_list();} 	// parameter
            insert_beg(); 	// parameter
        }
        else if(strcmp(string,"insertend")==0) 	// conditional,parameter
        {   if(create!=1) 	// parameter
        {
            create_list(); 	// parameter
        }
            insert_end(); 	// parameter
        }
        else if(strcmp(string,"printlist")==0) 	// conditional,parameter
        {
            
            
            print_list(); 	// parameter
        }
        else if(strcmp(string,"deletebeg")==0) 	// conditional,parameter
        {
            delete_beg(); 	// parameter
        }
        else if(strcmp(string,"deleteend")==0) 	// conditional,parameter
        {
            delete_end(); 	// parameter
        }
        else if(strcmp(string,"deletelist")==0) 	// conditional,parameter
        {
            delete_list(); 	// parameter
        }
        else if(string[0]=='0') 	// conditional,parameter
        {
            goto exit;
        }
        
    }
    exit:;
    return 0;
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N,A;int j,i;
    scanf("%d %d",&N,&A); 	// parameter
    int B[N]; 	// array
    for(i=0;i<N;++i) 	// loop,parameter
        {scanf("%d",&B[i]);} 	// array,parameter
    j=N-1;i=0;
int flag=0;

    while(i<j)  	// parameter

    { 
        if(B[i]+B[j]<A) 	// parameter,increment,conditional,array,decrement
        {
            ++i; 	// increment
        }
        else if(B[i]+B[j]==A) 	// conditional,parameter
        {
            printf("%d %d %d %d",i,j,B[i],B[j]); 	// array,parameter
            flag=1;break;
        }
        else if (B[i]+B[j]>A) 	// parameter
        {
            --j; 	// decrement
        }


    }
    if(flag==0) 	// conditional,parameter
        printf("NO"); 	// parameter
return 0;
}

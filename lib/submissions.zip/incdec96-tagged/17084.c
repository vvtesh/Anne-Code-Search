#include <stdio.h>

#include <stdlib.h>



long int bin(long long int search,long int n,long long int array[]) 	// array

{

    long int first,last,middle;

    first = 0;

   last = n - 1;

   middle = (first+last)/2; 	// parameter



   while( first <= last ) 	// parameter

   {

      if ( array[middle] < search ) 	// parameter,conditional

         first = middle + 1;

      else if ( array[middle] == search ) 	// conditional,parameter

      {

         return middle;

      }

      else

         last = middle - 1; 



      middle = (first + last)/2; 	// parameter

   }

   return 0;

}



void main() 	// function,parameter

{

    long long int n,a,data;

    scanf("%lld %lld",&n,&a); 	// parameter

    long long int b[n]; 	// array

    int i,j,flag=0;

    for(i=0;i<n;i++) 	// loop,parameter

    {

        scanf("%lld",&b[i]); 	// array,parameter

    }

    for(i=0;i<n;i++) 	// loop,parameter

    {

        if (bin(a-b[i],n,b)!=0) 	// parameter,array

            {

                printf("%ld %ld %lld %lld\n",i,bin(a-b[i],n,b),b[i],a-b[i]); 	// array,parameter

                flag=1;

                break;

            }

        else

            continue;

    }

    if(flag==0) 	// conditional,parameter

        printf("NO\n"); 	// parameter

}

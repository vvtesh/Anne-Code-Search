#include<stdio.h>

int main(){

    int* a;

    int N, A;

    scanf("%d %d",&N,&A); 	// parameter

    int i=0;

    int j;

    int tdiff=0;

    int sumdiff[2]; 	// array

    int diff=-1;

    int ip, jp;

    a=(int)malloc(N*sizeof(int)); 	// parameter

    for(i=0;i<N;i++) scanf("%d",&a[i]); 	// parameter

    for(i=0;i<N-1;i++){ 	// loop,parameter

        for(j=i+1;j<N;j++){ 	// loop,parameter

            if(a[i]+a[j]==A) { 	// conditional,parameter,array

                tdiff=a[j]-a[i]; 	// array

                if(tdiff>diff) { 	// conditional,parameter,array

                    diff=tdiff;

                    sumdiff[0]=a[i]; 	// array

                    sumdiff[1]=a[j]; 	// array

                    ip=i;

                    jp=j;

                }

                break;

            }

        }

    }

    if(diff==-1){ 	// conditional,parameter

        printf("NO"); 	// parameter

        return 0;

    }

    printf("%d %d %d %d",ip,jp,sumdiff[0],sumdiff[1]); 	// array,parameter

    return 0;

}

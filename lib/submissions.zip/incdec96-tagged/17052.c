#include <stdio.h>

int main(){
	int n,k,i,j;
	scanf("%d",&n); 	// parameter
	scanf("%d",&k); 	// parameter
	long a[n]; 	// array
	for(i=0;i<n;i++) 	// loop,parameter
		scanf("%ld",&a[i]); 	// array,parameter
	i=0;
	j=n-1;
	while(i<j){ 	// parameter
		if((a[i]+a[j])==k) 	// conditional,parameter,increment,decrement
			break;
		else if((a[i]+a[j])<k) 	// parameter
			i++; 	// increment
		else
			j--; 	// decrement
	}
	if(i>=j) 	// parameter,array,parameter
		printf("NO\n"); 	// parameter
	else
		printf("%d %d %ld %ld\n",i,j,a[i],a[j]); 	// array,parameter
	return 0;
}

#include <stdio.h>

#include <stdlib.h>



int main()

{

    int num, sum;

    scanf("%d %d", &num, &sum); 	// parameter

    int arr[num]; 	// array

    int i=0;

    int j=num-1;

    int k=0;

   // int s;

    int flag=0;



    for(i=0;i<num;i++) 	// loop,parameter

    {

         scanf("%d",&arr[i]); 	// array,parameter

    }

    



    while(j>0 && k<num-1) 	// parameter

    {

        if(sum==arr[j]+arr[k]) 	// conditional,array,parameter,decrement,increment

        {

            printf("%d %d %d %d",k,j,arr[k],arr[j]); 	// array,parameter

            flag=1;

            break;

        }

        else if (sum<arr[j]+arr[k]) 	// parameter

        {

            j--; 	// decrement



        }

        else if(sum>arr[j]+arr[k]) 	// parameter

        {

            k++; 	// increment

        }

        else

        {

            flag=0;

        }

    }

    if(flag==0) 	// conditional,parameter

    {

        printf("NO"); 	// parameter

    }

    return 0;



}

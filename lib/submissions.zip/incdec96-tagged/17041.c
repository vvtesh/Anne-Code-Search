#include<stdio.h>

#include<string.h>

#include<stdlib.h>



int main(){

    int n,a,i,flag=0;

    scanf("%d %d",&n,&a); 	// parameter

    int *arr=(int *)malloc(n*sizeof(int)); 	// parameter



    for(i=0;i<n;i++){ 	// loop,parameter

        scanf("%d",&arr[i]); 	// array,parameter

        }



    int sum;int first=0,last=n-1;



    while(first<last){ 	// parameter

        if((arr[first]+arr[last])==a){ 	// conditional,parameter,array,increment,decrement

            flag=1;

            printf("%d %d %d %d\n",first,last,arr[first],arr[last]); 	// array,parameter

            break;

        }

        else if((arr[first]+arr[last])<a){ 	// conditional,parameter

            first++; 	// increment

        }

        else{

            last--; 	// decrement

        }

    }

    if(flag==0){ 	// conditional,parameter

        printf("NO"); 	// parameter

    }

return 0;

}

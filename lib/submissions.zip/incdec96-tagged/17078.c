#include <stdio.h>
#include <stdlib.h>
int main()
{
	int n, a;
	scanf("%d %d", &n, &a); 	// parameter
	int i, j;
	int *x;
	x = (int*)malloc(sizeof(int)*n); 	// parameter
	for(i = 0; i < n; i++) 	// loop,parameter
	{
		scanf("%d", (x + i)); 	// parameter
	}
	i = 0;
	j = n - 1;
	int f;
	f = 0;
	while(i < j) 	// parameter
	{
		if(*(x + i) + *(x + j) > a) 	// parameter,decrement,increment
		{
			j--; 	// decrement
		}
		else if(*(x + i) + *(x + j) < a) 	// parameter
		{
			i++; 	// increment
		}
		else
		{
			f = 1;
			break;
		}
	}
	if(f == 0) 	// conditional,parameter,increment
	{
		printf("NO\n"); 	// parameter
	}
	else
	{
		printf("%d %d %d %d\n", i, j, *(x + i), *(x + j)); 	// parameter,increment
	}
	return 0;
}

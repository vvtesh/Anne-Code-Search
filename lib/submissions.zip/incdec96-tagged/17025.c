#include<stdio.h>

#include<stdlib.h>



typedef struct node node;

typedef struct nodeData nodeData;

typedef struct list list;



/*

	In this deq next will be pointing towards front and prev would be towards rear

*/



// START OF DEQ TEMPLATE BY DG

/////////////////////////////////////////

/////////////////////////////////////////

/////////////////////////////////////////

/////////////////////////////////////////





struct nodeData

{

	long data;

};



struct  node

{

	nodeData data;

	node * next;

	node * prev;	

};



// LIST TEMPLATE



struct list

{

	node * front;

	node * rear;

};



void insertAfter(node ** front , node ** rear , node* selector , node * toBeInserted) // insterr towards next 	// function,parameter

{

	node * towardsFront = selector->next;

	node * towardsRear = selector->prev;



	if(towardsFront != NULL) 	// parameter

	{

		towardsFront->prev = toBeInserted;

	}

	else

	{

		*front = toBeInserted;

	}





	selector->next = toBeInserted;

	toBeInserted->next = towardsFront;

	toBeInserted->prev = selector;



}



void insertBefore(node ** front , node ** rear , node* selector , node * toBeInserted) // insterr towards rear 	// function,parameter

{

	node * towardsFront = selector->next;

	node * towardsRear = selector->prev;



	if(towardsRear != NULL) 	// parameter

	{

		selector->prev = toBeInserted;

		toBeInserted->prev = towardsRear;

		toBeInserted->next = selector;

		towardsRear->next = toBeInserted;

	}

	else

	{

		*rear = toBeInserted;

		selector->prev = toBeInserted;

		toBeInserted->prev = towardsRear;

		toBeInserted->next = selector;

	}

}





node * addFront(node ** front , node ** rear , nodeData data) 	// parameter

{

	node * temp =(node *) malloc(sizeof(node)); 	// parameter

	temp->data = data;

	temp->next = NULL;

	temp ->prev= NULL;



	if(*front == NULL) // deq empty 	// conditional,parameter

	{

		*front = temp;

		*rear = temp;	

	}

	else

	{

		(*front)->next = temp; 	// parameter

		temp->prev = *front;

		*front = temp;

	}





	return temp;



}



node * addRear(node ** front , node ** rear , nodeData data) 	// parameter

{

	node * temp = (node *) malloc(sizeof(node)); 	// parameter

	temp->data = data;

	temp->next = NULL;

	temp->prev = NULL;



	if(*rear == NULL) 	// conditional,parameter

	{

		*front = temp;

		*rear = temp;

	}

	else

	{

		(*rear)->prev = temp; 	// parameter

		temp->next = *rear;

		*rear = temp;

	}



	



	return temp;



}





void addRearNode(node ** front , node ** rear , node * data) 	// function,parameter

{

	

	data->next = NULL;

	data->prev = NULL;



	if(*rear == NULL) 	// conditional,parameter

	{

		*front = data;

		*rear = data;

	}

	else

	{

		(*rear)->prev = data; 	// parameter

		data->next = *rear;

		*rear = data;

	}



	





}





void deleteNode(node ** front , node ** rear , node * toBeDeletad) 	// function,parameter

{

	if(*front == NULL && *rear == NULL) 	// conditional,parameter

		return;



	node * towardsFront = toBeDeletad->next;

	node * towardsRear = toBeDeletad->prev;



	if(towardsFront != NULL) 	// parameter

	{

		towardsFront->prev = towardsRear;

	}

	else

	{

		*front = towardsRear;

	}



	if(towardsRear != NULL) 	// parameter

	{

		towardsRear->next = towardsFront;

	}

	else

	{

		*rear = towardsFront;

	}



	// free(tobedeleted)

}



void printDeq(node ** front , node ** rear ) 	// function,parameter

{

	node * temp;

	temp = *front;

	while(temp != NULL) 	// parameter

	{

		printf("%d\n", (temp->data).data); 	// parameter

		temp = temp->prev;

	}

	 

}



void printDeqRev(node ** front , node ** rear ) 	// function,parameter

{

	// printf("rev\n");

	node * temp;

	temp = *rear;

	while(temp != NULL) 	// parameter

	{

		printf("%d\n", (temp->data).data); 	// parameter

		temp = temp->next;

	}

	 

}



void swapNodes(node * n1 , node*n2) 	// function,parameter

{

	nodeData tempdata = n1->data;

	n1->data = n2->data;

	n2->data = tempdata;

}



// END OF DEQ TEMPLATE BY DG

/////////////////////////////////////////

/////////////////////////////////////////

/////////////////////////////////////////

/////////////////////////////////////////













void initList(list * l) 	// function,parameter

{

	l->front = NULL;

	l->rear = NULL;

}



void listInsertAfter(list * l  , node* selector , node * toBeInserted) 	// function,parameter

{

	insertAfter(&(l->front) , &(l->rear) , selector , toBeInserted); 	// conditional,parameter

}



void listInsertBefore(list * l  , node* selector , node * toBeInserted) 	// function,parameter

{

	insertBefore(&(l->front) , &(l->rear) , selector , toBeInserted); 	// conditional,parameter

}





node * listAddFront(  list * l  , nodeData data) 	// parameter

{

	addFront(&(l->front) , &(l->rear) ,  data); 	// conditional,parameter

}



node * listAddRear(  list * l  , nodeData data) 	// parameter

{

	addRear(&(l->front) , &(l->rear) ,  data); 	// conditional,parameter

}



void listDeleteNode(list * l, node * toBeDeletad) 	// function,parameter

{

	 deleteNode(  &(l->front) ,   &(l->rear)  ,  toBeDeletad); 	// conditional,parameter

}



void listPrint(list * l) 	// function,parameter

{

	printDeq(&(l->front) ,   &(l->rear)); 	// conditional,parameter

}



void listPrintRev(list * l) 	// function,parameter

{

	// printf("pr \n");

	printDeqRev(&(l->front) ,   &(l->rear)); 	// conditional,parameter

}



void listAddRearNode(list * l  , node * data) 	// function,parameter

{

	addRearNode( &(l->front) ,   &(l->rear) ,   data); 	// conditional,parameter

}



list * jonLists(list * l1 , list * l2) 	// parameter

{



	if(l1->rear == NULL) 	// conditional,parameter

		return l2;

	if(l2->rear == NULL) 	// conditional,parameter

		return l1;



	(l1->rear)->prev = l2->front; 	// conditional,parameter

	(l2->front)->next = l1->rear; 	// conditional,parameter



	list * l;

	l->front = l1->front;

	l->rear = l2->rear;



	(l->front)->next = NULL; 	// conditional,parameter

	(l->rear)->prev = NULL; 	// conditional,parameter





	return l; 

}



//END OF LIST TEMPLATE

list * mergeLists(list * l1 , list * l2) 	// parameter

{

	list * l = (list *)malloc(sizeof(list)); 	// parameter

	initList(l); 	// parameter



	node * tempI = l1->front;



	node * tempJ = l2->front;



	while( 1 ) 	// parameter

	{

		if(tempI==NULL) 	// conditional,parameter

			break;



		if(tempJ==NULL) break; 	// conditional,parameter





		

		if(tempI->data.data < tempJ->data.data) 	// parameter

		{

			node * nextTempI = tempI->prev;

			listAddRearNode(l , tempI); 	// parameter

			tempI = nextTempI;

			//printf("%d n \n", nextTempI->data.data);

			//printf("if 1\n");

		}

		else

		{

			node * nextTempJ = tempJ->prev;

			listAddRearNode(l , tempJ); 	// parameter

			tempJ = nextTempJ;



		}

	}

 

 

	while(tempI != NULL ) 	// parameter

	{

		node * nextTempI = tempI->prev;

		listAddRearNode(l , tempI); 	// parameter

		tempI = nextTempI;

	}

 



	while(tempJ != NULL) 	// parameter

	{

		node * nextTempJ = tempJ->prev;

		listAddRearNode(l , tempJ); 	// parameter

		tempJ = nextTempJ;

	}



	return l;



}



node * getMidList(list * l) 	// parameter

{

	node * temp = l->front;

	int n = 0;

	while(temp != NULL) 	// parameter

	{

		temp = temp->prev;

		n++; 	// increment

	}

	// printf("%d\n",n );

	int i;

	temp =  l->front;

	for(i=0;i<n/2-1 ; i++)

	{

		temp = temp->prev;

	}

	return temp;

}





list *mSortList(list * l) 	// parameter

{



	if(l->front == l->rear)  	// conditional,parameter

		return l;



	list * l1 = (list*)malloc(sizeof(list)); 	// parameter

	list * l2 = (list*)malloc(sizeof(list)); 	// parameter



	l1->front = l->front;

	l2->rear = l->rear;



	node * mid = getMidList(l); 	// parameter

	node * midNext = mid->prev;



	mid->prev = NULL;

	midNext->next = NULL;



	l2->front = midNext;

	l1->rear = mid;



 

	l1 = mSortList(l1); 	// parameter

	// printf("sorted ");

 

	l2 = mSortList(l2); 	// parameter

 

 

	list * lll = mergeLists(l1 , l2); 	// parameter

 



	return lll;

}



void findSumWithMaxDiff(list * l1 , long n ,long num) 	// function,parameter

{

	node * tempI = l1->front;

	node * tempJ = l1->rear;



	long i = 0;

	long j = n-1;



	while(1) 	// parameter

	{

		// printf("ha\n");

		if( (tempJ != NULL &&  tempJ->prev == tempI) || (tempI != NULL &&  tempI->next == tempJ)   ) 	// conditional,parameter

		{

			printf("NO"); 	// parameter

			return;

		}







		long curSum = tempI->data.data + tempJ->data.data;



		if(curSum > num) 	// parameter,decrement,increment

		{

			tempJ = tempJ->next;

			j--; 	// decrement

		}

		else if(curSum < num) 	// parameter

		{

			tempI = tempI->prev;

			i++; 	// increment

		}

		else

		{

			printf("%d %d %d %d", i , j , tempI->data.data , tempJ->data.data); 	// conditional,parameter

			return;

		}





	}



}



int main()

{



    long n , num;

 

	scanf("%lld" , &n); 	// parameter



	scanf("%lld" , &num); 	// parameter

 

	list l;

	initList(&l); 	// parameter



	nodeData tempdata;



	long inCode;

	long i;

 





	for( i=0;i<n;i++) 	// loop,parameter

	{



		scanf("%lld" , &inCode); 	// parameter

		tempdata.data = inCode;

		listAddRear(&l , tempdata); 	// parameter

	}



	// listPrint(&l);



	findSumWithMaxDiff(&l , n , num); 	// parameter

	



	



	return 0;





}

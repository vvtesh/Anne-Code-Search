#include<stdio.h>

typedef long long ll;

ll a[1000001]; 	// array

int main()
{
int flag=0;
ll A,n,i,j,p,q;
scanf("%lld",&n); 	// parameter
scanf("%lld",&A); 	// parameter
for(i=0;i<n;i++) 	// loop,parameter
{scanf("%lld",&a[i]);} 	// array,parameter
i=0;
j=n-1;
while(i!=j) 	// parameter
{
if(a[i]+a[j]==A) 	// conditional,parameter
{
p=i;
q=j;
flag=1;
break;
}
if(a[i]+a[j]>A) 	// parameter,decrement,increment
j--; 	// decrement
else
i++; 	// increment

}
if(flag==0) 	// conditional,parameter,array
printf("NO\n"); 	// parameter
else
{
printf("%lld %lld %lld %lld\n",i,j,a[i],a[j]); 	// array,parameter
}
return 0;
}

#include <stdio.h>

int main(int argc, char const *argv[]) 	// array
{
	int n,i,j;

	unsigned long A;

	scanf("%d %lu",&n,&A); 	// parameter
	unsigned long ar[n]; 	// array

	for(i=0;i<n;i++){ 	// loop,parameter
		scanf("%lu",&ar[i]); 	// array,parameter
	}
	
	i=0;j=n-1;

	//printf("%lu %lu\n",sizeof(ar[0]),sizeof(long));

	while(i<j){ 	// parameter
		if(ar[i]+ar[j]==A){ 	// conditional,parameter,array,increment,decrement
			printf("%d %d %lu %lu\n",i,j,ar[i],ar[j]); 	// array,parameter
			return 0;
		}
		else if(ar[i]+ar[j]<A){ 	// conditional,parameter
			i++; 	// increment
		}
		else{
			j--; 	// decrement
		}
	}

	printf("NO\n"); 	// parameter
	return 0;
}

#include<stdio.h>

int main(){int n,a,i,flag=0,flagbreak=0;scanf("%d%d",&n,&a);int arr[n]; 	// array

	for(i=0;i<n;i++)scanf("%d",&arr[i]); 	// parameter

	int	low = 0;

	int high= n-1;

	while(low <= high) 	// parameter

	{

   int x = arr[low]; 	// array

   int y = arr[high]; 	// array

   long long int total = x+y;

   if(total == a) 	// conditional,parameter,decrement,increment

      flag=1;

   else if(total> a) 	// parameter

      high--; 	// decrement

   else low++;   	// increment

    

   if(flag==1){ 	// conditional,parameter

    printf("%d %d %d %d",low,high,x,y);flagbreak=1;break;}  	// parameter

	}if(flagbreak==0)printf("NO"); 	// conditional,parameter

	return 0;

	}

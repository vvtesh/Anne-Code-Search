#include <stdio.h>

#include <malloc.h>



int main()

{

	int N, A, i;

	scanf("%d", &N); 	// parameter

	scanf("%d", &A); 	// parameter

	int arr[N]; 	// array

	//int arr = (int *)malloc(N*sizeof(int));

	for(i=0; i<N; ++i) { 	// loop,parameter

		scanf("%d", (arr+i)); 	// parameter

	}

	findpair(N, A, arr); 	// parameter

    return 0;

}



void findpair(int N, int A, int *arr) { 	// function

    int f=0;

	int r=N-1;

	while(f < r) { 	// parameter

		if(arr[f] + arr[r] == A) 	// conditional,parameter,increment,decrement

            break;

		else if(arr[f] + arr[r] < A) 	// parameter

            f++; 	// increment

		else

            r--; 	// decrement

	}

	if(arr[f]+arr[r]==A) 	// conditional,parameter,array

		printf("%d %d %d %d\n", f, r, arr[f], arr[r]); 	// array,parameter

	else

	    printf("NO\n"); 	// parameter

}

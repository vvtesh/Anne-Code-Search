#include<stdio.h>

int main()

{

    int A[1000010]; 	// array

    int n,sum,temp,i=0,k,j=0,a=1;

    scanf("%d %d",&n,&sum); 	// parameter

    for(i=0;i<n;i++) 	// loop,parameter

    {

       scanf("%d",&A[i]); 	// array,parameter

    }

    k=n-1;

while(j<k) 	// parameter

{

    temp=A[j]+A[k]; 	// array

    if(temp==sum) 	// conditional,parameter,array,decrement,increment

    {

        printf("%d %d %d %d",j,k,A[j],A[k]); 	// array,parameter

        a=0;

        break;

    }

    else if(temp>sum) 	// parameter

    {

        k--; 	// decrement

    }

    else if(temp<sum) 	// parameter

    {

       j++; 	// increment

    }

}

if(a!=0) 	// parameter

{

   printf("NO"); 	// parameter

}



    return 0;



}

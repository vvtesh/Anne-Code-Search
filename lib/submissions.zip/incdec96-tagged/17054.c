#include<stdio.h>



int main()

{

    int N,K,flag=0;

    scanf("%d %d",&N,&K); 	// parameter

    int i;

    int a[1000000]; 	// array

    for (i=0;i<N;i++) 	// loop,parameter

    {

        scanf("%d",&a[i]); 	// array,parameter

    }

    int sum,lo,hi;

    lo=0;

    hi=N-1;

    while (lo<=hi) 	// parameter

    {

        sum=a[lo]+a[hi]; 	// array

        if (sum==K) 	// conditional,parameter,array,increment,decrement

        {

            printf("%d %d %d %d",lo,hi,a[lo],a[hi]); 	// array,parameter

            flag=1;

            break;

        }

        else if (sum<K) 	// parameter

            lo++; 	// increment

        else

            hi--; 	// decrement

    }

    if (flag==0) 	// conditional,parameter

        printf("NO\n"); 	// parameter





    return 0;

}

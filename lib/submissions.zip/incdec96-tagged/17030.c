#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int bin_srch (int Arr[], int beg, int end, int Val) 	// array,parameter
{
	int mid = (beg + end)/2; 	// parameter
	if (end < beg) 	// parameter,conditional
		return -1;
	else if (Arr[mid] == Val) 	// conditional,parameter
		return mid;
	else if (Arr[mid] > Val) 	// parameter
		return bin_srch (Arr, beg, mid-1, Val); 	// parameter
	else if (Arr[mid] < Val) 	// parameter
		return bin_srch (Arr, mid+1, end, Val); 	// parameter
}
	
void search (int Arr[], int size, int A) 	// array,parameter
{
	int i, temp, index1, found = 0;
	for (i=0; Arr[i] <= (A/2); i++)
	{	
		index1 = bin_srch (Arr, 0, size-1, A-(Arr[i])); 	// array,parameter
		if (index1 == -1) 	// conditional,parameter,array
			continue;
		else
		{
			found = 1;
			printf ("%d %d %d %d", i, index1, Arr[i], Arr[index1]); 	// array,parameter
			break;
		}
		printf (" "); 	// parameter
	}
	
	if (found == 0) 	// conditional,parameter
		printf ("NO\n\n"); 	// parameter
	else
		printf ("\n\n"); 	// parameter
}
			
		
int main()
{
	int size, A, i = 0;
	scanf ("%d %d", &size, &A); 	// parameter
	int *str_arr;
	str_arr = (int *) malloc (sizeof(int) * size); 	// parameter
	while (i < size) 	// parameter
	{
		scanf ("%d", &str_arr[i]); 	// array,parameter
		i++; 	// increment
	}
	
	//for (i=0; i<size; i++)
	//	printf ("%d ", str_arr[i]);
	
	search (str_arr, size, A); 	// parameter
	return 0;
}

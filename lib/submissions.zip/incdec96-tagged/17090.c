#include<stdio.h>
int main()
{
	unsigned long a[1000000],N,A; 	// array
	scanf("%lu",&N); 	// parameter
	scanf("%lu",&A); 	// parameter
	unsigned long i,j,k,lr=0,ur=N-1;
	for(i=0;i<N;i++) 	// loop,parameter
	{	scanf("%lu",&a[i]); 	// array,parameter
	}
	unsigned long a1,a2;
	unsigned long a1p,a2p;
	int flag=1;
	while(lr<ur) 	// parameter
	{	if((a[lr]+a[ur])==A)	 	// conditional,parameter,increment,decrement
		{	flag=0;
			a1p=lr;
			a2p=ur;
			break;
		}
		else if((a[lr]+a[ur])<A) 	// parameter
		lr++; 	// increment
		else ur--; 	// decrement
	}
	if(flag==0) printf("%lu %lu %lu %lu\n",a1p,a2p,a[a1p],a[a2p]); 	// conditional,array,parameter
	else printf("NO\n"); 	// parameter
	return 0;
}

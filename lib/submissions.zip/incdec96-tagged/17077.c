#include<stdio.h>
#include<stdlib.h>

int main()
{
	int t;
	long a, n, i, temp, j;
	scanf("%ld %ld", &n, &a); 	// parameter
	long arr[1000000]; 	// array

	for(i = 0; i < n; i++) 	// loop,parameter
	{
		scanf("%ld", &arr[i]); 	// array,parameter
	}

	for(i = 0, j = n - 1; i < j; ) 	// loop,parameter
	{
		temp = a - arr[i]; 	// array
		if(temp == arr[j]) 	// conditional,parameter,array,decrement,increment
		{
			printf("%ld %ld %ld %ld", i, j, arr[i], arr[j]); 	// array,parameter
		 	break;
		}
		else if(temp < arr[j]) 	// parameter
			j--; 	// decrement
		else if(temp > arr[j]) 	// parameter
			i++; 	// increment
	}

	if (i >= j) 	// parameter
		printf("NO"); 	// parameter

	printf("\n"); 	// parameter

	return 0;
}

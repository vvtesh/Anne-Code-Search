#include<stdio.h>

int main()

{

    int arr[50]; 	// array

    int i,j,k,N,A,flag=0,pos,pos1;

    scanf("%d %d",&N,&A); 	// parameter

    for(i=0;i<N;i++) 	// loop,parameter

    {

        scanf("%d",&arr[i]); 	// array,parameter

    }

    j = 0;

    k = N-1;

    while(j!=k) 	// parameter

     {

        if(arr[j]+arr[k]==A) 	// conditional,parameter,decrement,increment

        {

            pos = j;

            pos1 = k;

            flag = 1;

            break;

        }

        else if(arr[j]+arr[k]>A) 	// parameter

        {



            k--; 	// decrement

        }

        else if(arr[j]+arr[k]<A) 	// parameter

        {

            j++; 	// increment

        }



    }

    if(flag==1) 	// conditional,parameter,array

    {

        printf("%d %d %d %d",pos,pos1,arr[pos],arr[pos1]); 	// array,parameter

    }

    else

    {

        printf("NO"); 	// parameter

    }

    return 0;



}

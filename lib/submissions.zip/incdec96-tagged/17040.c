#include<stdio.h>

int main()

{

 int n,*a,i=0,sum,s;

 scanf("%d",&n); 	// parameter

 scanf("%d",&sum); 	// parameter

 a=(int *)malloc(n*sizeof(int)); 	// parameter

 for (i=0;i<n;i++) 	// loop,parameter

 {

     scanf("%d",&a[i]); 	// array,parameter



 }



 i=0;

 int j=n-1,checks=-1,subij=0;

 int r,b;

 while(i<j) 	// parameter

 {

     s=a[i]+a[j]; 	// array

     if(s==sum) 	// conditional,parameter,array,increment,decrement

      {

        checks=s;

        printf("%d %d %d %d",i,j,a[i],a[j]); 	// array,parameter

        break;

      }

     else if(s<sum) 	// parameter

     {

         i=i+1;		//increment

     }

     else if(s>sum) 	// parameter

     {

         j=j-1;		//decrement

     }

}







  if (checks==-1) 	// conditional,parameter

    {

        printf("NO"); 	// parameter

    }



return 0;

}

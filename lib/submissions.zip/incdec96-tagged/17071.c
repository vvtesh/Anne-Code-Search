#include <stdio.h>

#include <stdlib.h>

int bin(int search,int n,int array[]) 	// array,parameter

{

    int first,last,middle;

    first=0;

   last=n-1;

   middle=(first+last)/2; 	// parameter



   while( first<=last ) 	// parameter

   {

      if ( array[middle] < search ) 	// parameter,conditional,increment,decrement

         first = middle + 1;	//increment

      else if ( array[middle] == search ) 	// conditional,parameter

      {

         return middle;

      }

      else

         last = middle - 1; //decrement



      middle = (first + last)/2; 	// parameter

   }

   return 0;

}

void main() 	// function,parameter

{

    int n,a,data;

    scanf("%d %d",&n,&a); 	// parameter

    int b[n]; 	// array

    int i,j,flag=0;

    for(i=0;i<n;i++) 	// loop,parameter

    {

        scanf("%d",&b[i]); 	// array,parameter

    }

    for(i=0;i<n;i++) 	// loop,parameter

    {

        if (bin(a-b[i],n,b)!=0) 	// parameter,array

            {

                printf("%d %d %d %d\n",i,bin(a-b[i],n,b),b[i],a-b[i]); 	// array,parameter

                flag=1;

                break;

            }

        else

            continue;

    }

    if(flag==0) 	// conditional,parameter

        printf("NO\n"); 	// parameter

}

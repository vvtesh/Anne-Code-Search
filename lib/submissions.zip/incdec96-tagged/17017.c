#include<stdio.h>

int main()

{

    int N,A,i;

    scanf("%d%d",&N,&A); 	// parameter

    int arr[N]; 	// array

    for(i=0;i<N;i++) 	// loop,parameter

        scanf("%d",&arr[i]); 	// array,parameter

    int index1=N-1,index2=0,c=0;

    while(index1>=index2) 	// parameter

    {

        if(arr[index1]+arr[index2]==A) 	// conditional,parameter,decrement,increment

        {

            c=1;

            break;

        }

        else if(arr[index1]+arr[index2]>A) 	// parameter

            index1--; 	// decrement

        else

            index2++; 	// increment

    }

    if(c==1) 	// conditional,parameter,array

        printf("%d %d %d %d",index2,index1,arr[index2],arr[index1]); 	// array,parameter

    else

        printf("NO"); 	// parameter

    return 0;

}

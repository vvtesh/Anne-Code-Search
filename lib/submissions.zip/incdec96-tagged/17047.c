#include <stdio.h>

#include<string.h>

#include<stdlib.h>

int main(void)

{

	int n,l,x=0,i,j,s=0;

	scanf("%d%d",&n,&l); 	// parameter

	int *c=(int *)malloc(n*sizeof(int)); 	// parameter

for(i=0;i<n;i++) 	// loop,parameter

{

	scanf("%d",&c[i]); 	// array,parameter

}

i=0;

j=n-1;

while(i<=j) 	// parameter

{

	s=c[i]+c[j]; 	// array

	if(s==l) 	// conditional,parameter

	{

	x=1;

	break;

	}

	if(s<l) 	// parameter,increment,decrement

	i++; 	// increment

	else

	j--; 	// decrement

	}

	if(x==1) 	// conditional,parameter,array

	printf("%d %d %d %d",i,j,c[i],c[j]); 	// array,parameter

	else

	printf("NO"); 	// parameter

	return 0;

}

#include<stdio.h>
#include<stdlib.h>

int main()
{
int N, A, i, d=0;
scanf("%d%d", &N, &A); 	// parameter
int arr[N], b=0, c=(N-1); 	// array,parameter


for(i=0; i<N; i++) 	// loop,parameter
{
 scanf("%d", &arr[i]); 	// array,parameter
}

while(b<c) 	// parameter
{
if ( arr[b]+arr[c]==A) 	// conditional,parameter,increment,decrement
{
 printf("%d %d ",b,c); 	// parameter
 printf("%d %d ", arr[b], arr[c]); 	// array,parameter
 d++; 	// increment
 exit(0); 	// parameter
}
else if (arr[b]+arr[c]<A) 	// parameter
{
b++; 	// increment
}
else
{
c--; 	// decrement
}
}


if (d==0) 	// conditional,parameter
{
 printf("NO"); 	// parameter
}
return 0;
}

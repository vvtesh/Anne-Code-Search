#include<stdio.h>

int main()

{

	int s,n,i,sum,c=0,f,l,b[3]; 	// array

	scanf("%d %d",&n,&s); 	// parameter

	int a[n]; 	// array

	for(i=0 ; i<n ; i++) 	// loop,parameter

		scanf("%d",&a[i]); 	// array,parameter

	f=0;

	l=n-1;

	//sum=a[f]+a[l];

	//if(sum==s)

	//	printf("%d %d %d %d\n",f,l,a[f],a[l]);

	while(sum!=s) 	// parameter

	{

		sum=a[f]+a[l]; 	// array

		if(f==l) 	// conditional,parameter

			break;

		if(sum==s) 	// conditional,parameter,array,increment

		{

			b[0]=f;b[1]=l;b[2]=a[f];b[3]=a[l]; 	// array

			c++; 	// increment

		}

		if(sum<s) 	// parameter,increment,decrement

			f++; 	// increment

		else if(sum>s) 	// parameter

			l--; 	// decrement

	}

	if(c==0) 	// conditional,parameter,array

		printf("NO\n"); 	// parameter

	else

		printf("%d %d %d %d\n",b[0],b[1],b[2],b[3]); 	// array,parameter

	return 0;

}

#include<stdio.h>

#include<stdlib.h>

int main(void)

{

int a,b,i,j,c=0;

scanf("%d %d",&a,&b); 	// parameter

int *arr=(int *)malloc(a*sizeof(int)); 	// parameter

    for(i=0;i<a;i++) 	// loop,parameter

    {

    scanf("%d",&arr[i]); 	// array,parameter

    }

     i=0;

     j=a-1;

        while(i<=j) 	// parameter

        {

            if((arr[j]+arr[i])==b) 	// conditional,parameter,increment,decrement

            {

                    c=1;

                    break;

            }

            else if((arr[j]+arr[i])<b){ 	// conditional,parameter



            i++;} 	// increment



            else if((arr[j]+arr[i])>b){ 	// conditional,parameter

            j--;} //decrement

        }



        if(c==1) 	// conditional,parameter,array

        {

        printf("%d %d %d %d",i,j,arr[i],arr[j]); 	// array,parameter

        printf("\n"); 	// parameter

        }

        else{

        printf("NO"); 	// parameter

        printf("\n");} 	// parameter

return 0;

}

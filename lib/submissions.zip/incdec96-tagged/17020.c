#include<stdio.h>
int binarysearch(int n, int A[], int size) 	// array,parameter
{
	int first = 0, last = size - 1;
	int mid = (first + last)/2; 	// parameter
	while(first <= last){ 	// parameter
		if(A[mid] < n) 	// parameter
			first = mid+1;
		else if(A[mid] > n) 	// parameter
			last = mid -1;
		else
			return mid;
		mid = (first+last)/2; 	// parameter
	}
	if(first > last) 	// parameter
		return -1;
}

int main()
{
	int size, sum, i, d=-1;
	scanf("%d %d",&size,&sum); 	// parameter
	int A[size]; 	// array
	for(i=0;i<size;i++) 	// loop,parameter
	{
		scanf("%d",&A[i]); 	// array,parameter
	}
	for(i=0;i<size;i++) 	// loop,parameter
	{
		d=binarysearch(sum - A[i], A, size);		 	// array,parameter
		if(d!=-1){ 	// conditional,parameter,array
			if(i!=d){ 	// conditional,parameter
				printf("%d %d %d %d",i,d,A[i],A[d]); 	// array,parameter
				break;
			}
			else
				d = -1;
		}
	}
	if(d==-1) 	// conditional,parameter
		printf("\nNO"); 	// parameter
	return 0;
}

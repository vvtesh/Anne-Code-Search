# include <stdio.h>



int main()

{

    int n;

    scanf("%d",&n); 	// parameter



    int sum;

    scanf("%d",&sum); 	// parameter



    int array[n]; 	// array



    int i;

    for(i=0;i<=n-1;i++) 	// loop,parameter

    {

        int d;

        scanf("%d",&d); 	// parameter

        array[i]=d; 	// array

    }



    int a, b;



    a = 0;

    b = n-1;

    int count=0;

    while(a < b) 	// parameter

    {

         if(array[a] + array[b] == sum) 	// conditional,parameter,array,increment,decrement

              {

                  printf("%d %d %d %d",a,b,array[a],array[b]); 	// array,parameter

                  count++; 	// increment

                  break;

              }

         else if(array[a] + array[b] < sum) 	// parameter

              a++; 	// increment

         else if( array[a] + array[b] > sum) 	// parameter

              b--; 	// decrement



    }

    if(count==0) 	// conditional,parameter

    {

        printf("NO\n"); 	// parameter

    }



    return 0;

}

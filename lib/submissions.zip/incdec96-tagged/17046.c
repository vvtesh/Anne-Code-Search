#include <stdio.h>

int main(void)

{

    int n,b;

    scanf("%d%d",&n,&b); 	// parameter

    int *c=(int *)malloc(n*sizeof(int)); 	// parameter

    int f=0;

    int i;

    for(i=0;i<n;i++) 	// loop,parameter

    {

        scanf("%d",&c[i]); 	// array,parameter

    }

    i=0;

    int s=0;

    int j=n-1;

    while(i<=j) 	// parameter

    {

        s=c[i]+c[j]; 	// array

        if(s==b) 	// conditional,parameter

        {

            f=1;

            break;

        }

        if(s<b) 	// parameter,increment,decrement

            i++; 	// increment

        else

            j--; 	// decrement

    }

    if(f==1) 	// conditional,parameter,array

        printf("%d %d %d %d",i,j,c[i],c[j]); 	// array,parameter

    else

        printf("NO"); 	// parameter

    return 0;

}

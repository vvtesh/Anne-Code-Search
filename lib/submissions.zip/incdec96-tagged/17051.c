#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n, a, i, head, tail;
    
    scanf("%d %d", &n, &a); 	// parameter
    int arr[n]; 	// array
    
    for (i = 0; i < n; i++) 	// loop,parameter
    {
        scanf("%d", &arr[i]); 	// array,parameter
    }
    
    head = 0;
    tail = n - 1;
    
    for(;;) 	// loop,parameter
    {
        if (arr[head]+arr[tail] > a && head < tail) 	// parameter,decrement,increment,conditional
            tail--; 	// decrement
        else if (arr[head]+arr[tail] < a && head < tail) 	// parameter
            head++; 	// increment
        else if((arr[head]+arr[tail]) == a) 	// conditional,parameter
        {
            printf("%d %d %d %d\n", head, tail, arr[head], arr[tail]); 	// array,parameter
            exit(0); 	// parameter
        }
        else
        {
            printf("NO\n"); 	// parameter
            exit(0); 	// parameter
        }
    }
    
    return 0;
}

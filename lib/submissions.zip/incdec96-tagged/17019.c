#include<stdio.h>



int main()

{

    long long int n,x,*a,i,found=0;

    scanf("%lld%lld",&n,&x); 	// parameter

    a=(long long int*)malloc(n*sizeof(long long int)); 	// parameter

    for(i=0;i<n;i++) 	// loop,parameter

        scanf("%lld",&a[i]); 	// array,parameter

    int s=0,e=n-1;

    while(s<e){ 	// parameter

        if(a[s]+a[e]==x){ 	// conditional,parameter,array,increment,decrement

            printf("%lld %lld %lld %lld",s,e,a[s],a[e]); 	// array,parameter

            found=1;

            break;

         }

         else if(a[s]+a[e]<x) 	// parameter

            s++; 	// increment

         else

            e--; 	// decrement

    }

    if(found==0) 	// conditional,parameter

        printf("NO\n"); 	// parameter

    free(a); 	// parameter

    return 0;

}

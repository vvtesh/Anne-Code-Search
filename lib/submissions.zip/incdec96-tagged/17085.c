#include<stdio.h>
#include<stdlib.h>
int i,j;

int main()
{
 
 int size,a;
 scanf("%d %d",&size,&a); 	// parameter
 int *arr= (int *)malloc(size*sizeof(int)); 	// parameter
 for(i=0;i<size;i++) 	// loop,parameter
 {
    scanf("%d",&arr[i]); 	// array,parameter
 }
 for(i=0,j=size-1;i<j;) 	// loop,parameter
 {
   if(arr[i]+arr[j]==a) 	// conditional,parameter,array,decrement,increment
       {printf("%d %d %d %d",i,j,arr[i],arr[j]); 	// array,parameter
        return 0;
       }
   else
   if(arr[i]+arr[j]>a) 	// parameter
      j--;  	// decrement
   else
      i++; 	// increment
   
 }
    
    printf("NO"); 	// parameter
    return 0;

}
	
	

#include<stdio.h>

#include<stdlib.h>

int binary_search(int l,int h,int a,int arr[]) 	// array,parameter

{

    int mid=(h+l)/2; 	// parameter

    if(arr[mid]==a) return mid; 	// conditional,parameter,array

    else if(l>=h) return -h; 	// parameter

    else if (arr[mid]<a) return binary_search(mid+1,h,a,arr); 	// array,parameter

    else return binary_search(l,mid,a,arr); 	// parameter



}

int main()

{

    int n,a,i;

    scanf("%d %d",&n,&a); 	// parameter

    int *arr=(int *)malloc(n*sizeof(int)); 	// parameter

    for(i=0;i<n;i++) 	// loop,parameter

        scanf("%d",&arr[i]); 	// array,parameter

    int maxsearch=binary_search(0,n-1,a/2,arr);

    int m=binary_search(0,n-1,a,arr); 	// parameter

    if (maxsearch<0) 	// parameter

        maxsearch*=-1;

    if(m<0) m*=-1; 	// parameter

    int diff=0,j,fpos,spos;

    for(i=0;i<=maxsearch;i++) 	// loop,parameter

    {

        j=binary_search(i+1,m,a-arr[i],arr); 	// array,parameter

        if(j<0); 	// parameter

        else {

        if(diff<j-i){ 	// conditional,parameter

            diff=j-i;

            fpos=i;

            spos=j;}

        }

    }

    if(diff==0) 	// conditional,parameter,array

        printf("NO"); 	// parameter

    else printf("%d %d %d %d",fpos,spos,arr[fpos],arr[spos]); 	// array,parameter

    return 0;

}

#include <stdio.h>

#include<string.h>

#include<stdlib.h>

int main(void)

{

    int n,b,f=0,s=0;

    scanf("%d%d",&n,&b); 	// parameter

    

	int *temp=(int *)malloc(n*sizeof(int)); 	// parameter

    int i;

    for(i=0;i<n;++i) 	// loop,parameter

    {

    	scanf("%d",&temp[i]); 	// array,parameter

    }

    i=0;

    int j;

    j=n-1;

   

	while(i<=j) 	// parameter

    {

        s=temp[i]+temp[j]; 	// array

        if(s==b) 	// conditional,parameter,increment,decrement

        {

            f=1;

            break;

        }

        if(s<b) 	// parameter

            ++i; 	// increment

        else

            --j; 	// decrement

    }

    if(f==1) 	// conditional,parameter

    printf("%d %d %d %d",i,j,temp[i],temp[j]); 	// array,parameter

    else

    printf("NO"); 	// parameter

    return 0;

}

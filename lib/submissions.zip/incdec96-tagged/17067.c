#include <stdio.h>

int main() 

{



	int N;

	int i,A,a,b;

	scanf("%d  %d",&N,&A); 	// parameter

	int arr[N]; 	// array

	for(i=0;i<N;i++) 	// loop,parameter

	 {

	  scanf("%d",&arr[i]); 	// array,parameter

	 }

	 a=0;

	 b=N-1;

    

    while(a<b) 	// parameter

    {

        

        	 if (arr[a]+arr[b]==A) 	// conditional,parameter,increment,decrement

        	   break;

        	 else if(arr[a]+arr[b] < A) 	// parameter

        	   a++; 	// increment

        	 else

        	   b--; 	// decrement

        	    

    }

        	    if(arr[a]+arr[b]==A) 	// conditional,parameter,array

        	    printf("%d %d %d %d",a,b,arr[a],arr[b]); 	// array,parameter

        	     

        	   else

        	     printf("NO"); 	// parameter

       

    

		return 0;

}

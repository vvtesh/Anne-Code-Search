#include<stdio.h>

#include<stdlib.h>



int main(){

    int nnn,aaa,i,j,sum,flag;

    flag=0;

    int *arr;

  //  puts("enter n and a");

    scanf("%d%d",&nnn,&aaa); 	// parameter

    i=nnn;

    arr=(int*)malloc(nnn*sizeof(int)); 	// parameter

    while(i>0){ 	// parameter

        scanf("%d",&arr[nnn-i]); 	// array,parameter

        i--; 	// decrement

    }

   // for(i=0;i<nnn;i++){

   //     printf("%d ",arr[i]);

  //  }

    j=nnn-1;



    for(i=0;i<=j;i++){ 	// loop,parameter

            j=nnn-1;



        sum=arr[i]+arr[j]; 	// array

        while(sum>aaa && j>=i){ 	// parameter

        sum=arr[i]+arr[j]; 	// array

            j--; 	// decrement

        }

        if (sum==aaa){ 	// conditional,parameter,array

            printf("%d %d %d %d\n",i,j,arr[i],arr[j]); 	// array,parameter

            flag=1;

            break;

        }



    }

    if(flag==0) printf("NO\n"); 	// conditional,parameter



    return 0;

}

#include <stdio.h>



int Work(int *a,int n,int sum) 	// parameter

{

    int start,last,check=0;

    start=0;last=n-1;

    while(start<last) 	// parameter

    {

        if(a[last]+a[start]==sum) 	// conditional,parameter,array,increment,decrement



            {

                printf("%d %d %d %d\n",start,last,a[start],a[last]); 	// array,parameter

                check+=1; 	//increment

                break;

            }



        else if(a[last]+a[start]>sum) 	// parameter

        {

            last-=1;	//decrement

        }

        else if(a[last]+a[start]<sum) 	// parameter

        {



            start+=1;	//increment

        }



    }

    if(check==0) 	// conditional,parameter

        printf("NO\n"); 	// parameter

    return 0;





}







int main()

{

    int size;int sum;int i=0;//int t=1;

   // while(t<=100)

    //{

        scanf("\n%d %d",&size,&sum); 	// parameter

        int *a=(int*)malloc(size*sizeof(int)); 	// parameter



        for(i=0;i<size;i++) 	// loop,parameter

            scanf("%d",&a[i]); 	// array,parameter

        Work(a,size,sum); 	// parameter

    //}



return 0;

}

#include<stdio.h>

#include<string.h>

#include<stdlib.h>





int main()

{

    long a,*arr,n,i,j,k;

    scanf("%ld%ld",&n,&a); 	// parameter

    arr=(long*)malloc(1000000*sizeof(long)); 	// parameter

    for(i=0;i<n;i++) 	// loop,parameter

    {

        scanf("%ld",&arr[i]); 	// array,parameter

    }

    j=n;

    i=0;



    for(k=0;k<n;k++) 	// loop,parameter

    {

        //printf("sd");

        if(i>=j-1) 	// parameter

        {

            printf("NO\n"); 	// parameter

            break;

        }

        if((arr[i]+arr[j-1])==a) 	// conditional,parameter,array,decrement,increment

        {

            printf("%ld %ld %ld %ld\n",i,j-1,arr[i],arr[j-1]); 	// array,parameter

            break;

        }

        else if((arr[i]+arr[j-1])>a) 	// parameter

        {

            j--; 	// decrement

        }

        else

        {

            i++; 	// increment

        }



    }



    return 0;

}

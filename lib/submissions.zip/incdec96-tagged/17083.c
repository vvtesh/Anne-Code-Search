#include<stdio.h>

#include<stdlib.h>

int main()

{

    int *a,t,b,c,n,*arr,l,r,i; 	// pointer

    int flag=0;

    int found=0;

    scanf("%d %d",&n,&b); 	// parameter

    a=(int*)malloc(n*sizeof(int*)); 	// parameter

    arr=(int*)malloc(n*sizeof(int*)); 	// parameter

    c=n;

    i=0;

    while(i<c) 	// parameter

    {

        scanf("%d",&a[i]); 	// array,parameter

        i++; 	// increment

    }

    a[n]='\0'; 	// array

    //for(i=0;i<n;i++)

        //printf("%lld ",a[i]);

    l=0;

    r=n-1;

    while(l<r) 	// parameter

    {

        if(a[l]+a[r]==b && found==0) 	// conditional,parameter,array,increment,decrement

        {

            flag=1;

            found=1;

            arr[0]=l; 	// array

            arr[1]=r; 	// array

            arr[2]=a[l]; 	// array

            arr[3]=a[r]; 	// array

            //printf("%d %d %d %d\n",l,r,a[l],a[r]);

            l++; 	// increment

            r--; 	// decrement

        }

        else if(a[l]+a[r]==b && found==1) 	// conditional,parameter

        {

            flag=1;

            //printf("%d %d %d %d\n",l,r,a[l],a[r]);

            if ((a[r]-a[l])>(arr[3]-arr[2])) 	// parameter

            {

                arr[0]=l; 	// array

                arr[1]=r; 	// array

                arr[2]=a[l]; 	// array

                arr[3]=a[r]; 	// array

            }

            r--; 	// decrement

            l++; 	// increment

        }

        else if(a[l]+a[r]<b) 	// parameter

            l++; 	// increment

        else

            r--; 	// decrement

}

    if (flag==1) 	// conditional,parameter,array

        printf("%d %d %d %d",arr[0],arr[1],arr[2],arr[3]); 	// array,parameter

    else

    printf("NO"); 	// parameter

    return 0;

}

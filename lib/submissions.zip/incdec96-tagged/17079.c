#include<stdio.h>

int main()

{

int n,sum;

    int ele;

int flag=0;

    int i=0;

int k;

    //printf("enter no of elements and sum");

    scanf("%d%d", &n, &sum); 	// parameter

    int arr[n]; 	// array

     int j=n-1;

    for(k=0;k<n;k++) 	// loop,parameter

        scanf("%d", &arr[k]); 	// array,parameter



    while(i<j) 	// parameter

    {

        if((arr[i]+arr[j])==sum) 	// conditional,parameter,increment,decrement,array

            {printf("%d %d %d %d",i,j,arr[i], arr[j]); 	// array,parameter

            flag=1;

            break;}

        else if((arr[i]+arr[j])<sum) 	// parameter

        {

            i=i+1; //increment

           // printf("go\n");



        }

        else

    {

        j=j-1; //decrement

       // printf("jo\n");

    }



    }

    if(flag==0) 	// conditional,parameter

        printf("NO"); 	// parameter

return 0;}

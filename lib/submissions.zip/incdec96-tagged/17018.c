#include<stdio.h>

void main() 	// function,parameter

{

	int i,n,a;

	scanf("%d %d",&n,&a); 	// parameter

	int A[n]; 	// array

	for(i=0;i<n;i++) 	// loop,parameter

	{

		scanf("%d",&A[i]); 	// array,parameter

	}

	int l=0,flag=0;

	int r=n-1;

	while(l<r) 	// parameter

	{

		if(A[l]+A[r]==a) 	// conditional,parameter,array,increment,decrement

		{

			printf("%d %d %d %d",l,r,A[l],A[r]); 	// array,parameter

			flag=1;

			break;

		}

		else if(A[l]+A[r]<a) 	// parameter

		{

			l++; 	// increment

		}

		else

		{

			r--; 	// decrement

		}

	}

	if(flag==0) 	// conditional,parameter

	{

		printf("NO"); 	// parameter

	}

	

}

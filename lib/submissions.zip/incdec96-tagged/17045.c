#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>

int main(int argc, char const *argv[]) 	// array
{
	int i,j,n,k,g,s;
	scanf("%d",&i); 	// parameter
	scanf("%d",&n); 	// parameter
	int a[i]; 	// array
	for (j = 0; j < i; ++j) 	// loop,parameter
	{
		scanf("%d",&a[j]); 	// array,parameter
	}
	for (j = 0,k=i-1; j < k;) 	// loop,parameter
	{
		if (a[j]+a[k]<n) 	// parameter,increment,decrement,conditional
			j++; 	// increment
		else if(a[j]+a[k]>n) 	// parameter
			k--; 	// decrement
		else if(a[j]+a[k]==n) 	// conditional,parameter
		{
			s=j;
			g=k;
			break;
		}
		else
			g=-1;
	}

	if (g==-1) 	// conditional,parameter,array
		printf("NO"); 	// parameter
	
	else
		printf("%d %d %d %d",s,g,a[s],a[g]); 	// array,parameter
	
	return 0;
}

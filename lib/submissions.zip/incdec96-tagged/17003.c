#include<stdio.h>

#include<stdlib.h>



int main()

{

    int n;

    int s,i,j;

    int sum=0;

    scanf("%d %d",&n,&s); 	// parameter

    int *a=(int*)malloc(sizeof(int)*n); 	// parameter

    for(i=0;i<n;i++) 	// loop,parameter

        scanf("%d",&a[i]); 	// array,parameter

    i=0;

    j=n-1;

    while(i<j) 	// parameter

    {

        if(a[i]+a[j]==s) 	// conditional,parameter,increment,decrement

            break;

        else if(a[i]+a[j]<s) 	// parameter

            i++; 	// increment

        else

            j--; 	// decrement

    }

    if(i==j) 	// conditional,parameter

        printf("NO"); 	// parameter

    else

    {

        printf("%d %d %d %d",i,j,a[i],a[j]); 	// array,parameter

    }

    return 0;

}

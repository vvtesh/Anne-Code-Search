#include <stdio.h>
int main(){
     {
        int length,sum,i,j=0,k=0,testsum;
        scanf("%d",&length); 	// parameter
        scanf("%d",&sum); 	// parameter
        int array[length]; 	// array
        for (i=0; i<length; i++) { 	// loop,parameter
            scanf("%d",&array[i]); 	// array,parameter
        }
        k=length-1;
        j=0;
        testsum=array[k]+array[j]; 	// array
        while ((testsum!=sum)&&(k>j)) { 	// parameter
            if (testsum<sum){ 	// conditional,parameter,increment,decrement
                j++; 	// increment
            }
            else if (testsum>sum){ 	// conditional,parameter
                k--; 	// decrement
            }
            testsum=array[k]+array[j]; 	// array
        }
        if (testsum==sum) { 	// conditional,parameter,array
            printf("%d %d %d %d",j,k,array[j],array[k]); 	// array,parameter
        }
        else{
            printf("NO"); 	// parameter
        }
        

    }
    return 0;
}

#include <stdio.h>

int main()

{

    int N,A;

    scanf("%d%d",&N,&A); 	// parameter

    int arr[N]; 	// array

    int i,left,right,flag=0,sum;

    for (i=0;i<N;i++) 	// loop,parameter

    {

        scanf("%d",&arr[i]); 	// array,parameter

    }

    left=0;right=N-1;

    while (left!=right) 	// parameter

    {

        sum=arr[left]+arr[right]; 	// array

        if (sum<A) 	// parameter,increment,decrement

            left++; 	// increment

        else if (sum>A) 	// parameter

            right--; 	// decrement

        else

        {

        flag=1;break;

        }

    }

    if (flag==0) 	// conditional,parameter,array

        printf("NO"); 	// parameter

    else

        printf("%d %d %d %d",left,right,arr[left],arr[right]); 	// array,parameter

    return 0;

}

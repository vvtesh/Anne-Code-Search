#include<stdio.h>

int main()

{int i,n,arr[1000000],num,peh,aak; 	// array

 scanf("%d",&n); 	// parameter

 scanf("%d",&num); 	// parameter

 for(i=0;i<n;i++) 	// loop,parameter

 {scanf("%d",&arr[i]); 	// array,parameter

}

  peh=0;

  aak=(n-1); 	// parameter

  while(peh<aak) 	// parameter

  {if((arr[peh]+arr[aak])<num) 	// parameter,increment,decrement,array,conditional

  { peh++; 	// increment

  }

   else if (arr[peh]+arr[aak]>num) 	// parameter

   {aak--; 	// decrement

    }

   else{printf("%d %d %d %d",peh,aak,arr[peh],arr[aak]);break;} 	// array,parameter

    }

  if(peh>=aak){printf("NO");} 	// conditional,parameter



return 0;

}

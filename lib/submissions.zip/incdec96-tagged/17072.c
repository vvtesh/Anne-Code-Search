#include <stdio.h>

#include <malloc.h>



int main() {

	int i,n,s,*a,b,c=0;

	scanf("%d %d",&n,&s); 	// parameter

	//printf("a");

	a=(int*)malloc(sizeof(int)*n); 	// parameter

	//printf("b");

	//printf("%d",n);

	for(i=0;i<n;i++) { 	// loop,parameter

		//printf("c");

		scanf("%d",&a[i]); } 	// array,parameter

	i=0;

	int j=n-1;

	while(i<j) { 	// parameter

		b=a[i]+a[j]; 	// array

		if(b==s) { 	// conditional,parameter,array

			c=1;

			printf("%d %d %d %d", i, j, a[i], a[j]); 	// array,parameter

			break;

		}

		if(b<s) i++; 	// parameter,increment,decrement

		else if(b>s) j--;  	// parameter,decrement

	}

	if(c==0) printf("NO"); 	// conditional,parameter

	return 0;

}

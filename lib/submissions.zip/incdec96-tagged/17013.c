#include<stdio.h>
int main()
{
	int N,A,l,r,i;
	scanf("%d",&N); 	// parameter
        scanf("%d",&A); 	// parameter
        int Arr[N]; 	// array
		for(i=0;i<N;i++) 	// loop,parameter
		{
			scanf("%d",&Arr[i]); 	// array,parameter
		}
		l=0;
		r=N-1;
	while(l<r) 	// parameter
	{
		if(Arr[l]+Arr[r]==A) 	// conditional,parameter,increment,decrement
	break;
		else if(Arr[l]+Arr[r]<A) 	// parameter
		l++; 	// increment
		else
		r--; 	// decrement
	}
	if(Arr[l]+Arr[r]==A) 	// conditional,parameter,array
		printf("%d %d %d %d",l,r,Arr[l],Arr[r]); 	// array,parameter
	else
    		printf("NO"); 	// parameter
return 0;
}

#include<stdio.h>

int main()
{	
	int n,a,i;
	scanf("%d",&n); 	// parameter
	scanf("%d",&a); 	// parameter
	int Arr[n]; 	// array
	for(i=0;i<n;i++) 	// loop,parameter
	{	
		scanf("%d",&Arr[i]); 	// array,parameter
	}
	int *p1=Arr;
	int *p2=&Arr[n-1]; 	// array
	//printf("%d  %d",*p1,*p2);
	i=0;
	int flag=0,j=n-1;
	while(p1!=p2 && flag==0) 	// parameter
	{	
		if((*p1)+(*p2)==a) 	// conditional,parameter,increment,decrement
		{
			flag++; 	// increment
		}
		else if((*p1)+(*p2)>a) 	// parameter
		{
			p2--; 	// decrement
			j--;	 	// decrement
		}
		else
		{
			p1++; 	// increment
			i++; 	// increment
		}
	}
	if(flag!=0) 	// parameter
	{
		printf("%d %d %d %d",i,j,*p1,*p2); 	// parameter
	}
	else
		printf("NO"); 	// parameter
	return 0;
}

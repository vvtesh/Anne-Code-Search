#include <stdio.h>

#include<string.h>

#include<stdlib.h>

int main()

{

int n,b,z=0,i=0,j,s=0;

scanf("%d",&n); 	// parameter

scanf("%d",&b); 	// parameter

int *arr=(int *)malloc(n*sizeof(int)); 	// parameter

while(i!=n) 	// parameter

{

scanf("%d",&arr[i]); 	// array,parameter

i++; 	// increment

}

i=0;

j=n-1;

while(i<=j) 	// parameter

{

s=arr[i]+arr[j]; 	// array

if(s==b) 	// conditional,parameter

{

z=1;

break;

}

if(s<b) 	// parameter,increment,decrement

i++; 	// increment

else

j--; 	// decrement

}

if(z==1) 	// conditional,parameter,array

printf("%d %d %d %d",i,j,arr[i],arr[j]); 	// array,parameter

else

printf("NO"); 	// parameter



return 0;

}

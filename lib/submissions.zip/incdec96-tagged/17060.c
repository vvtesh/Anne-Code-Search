#include<stdio.h>
int main()
{
	int t;
	long long int i,j,diff,ipos,jpos,flag,a,n,arr[1000001]; 	// array
		scanf("%lld %lld",&n,&a); 	// parameter
		for(i=0;i<n;++i) 	// loop,parameter
		{
			scanf("%lld",arr+i); 	// parameter
		}
		i=0;j=n-1;diff=0;flag=0;
		while((j-i)>=1) 	// parameter
		{
			if((arr[i]+arr[j])<a) 	// parameter,increment,decrement
			{
				i++; 	// increment
			}
			else if((arr[i]+arr[j])>a) 	// parameter
			{
				j--; 	// decrement
			}
			else
			{
				/*if((arr[j]-arr[i])>diff)
				{	
					diff=arr[j]-arr[i]; 	// array
					ipos=i;jpos=j;
					flag=1;
				}
				i++;j--;*/ 	// increment
				flag=1;
			}
		}
		if(flag) 	// parameter,array
			printf("%lld %lld %lld %lld\n",i,j,arr[i],arr[j]); 	// array,parameter
		else
			printf("NO\n"); 	// parameter
	return 0;
}

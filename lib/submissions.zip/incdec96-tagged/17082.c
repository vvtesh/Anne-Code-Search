#include<stdio.h>

int main(void)

{

    int N,rsum;

    scanf("%d%d",&N,&rsum); 	// parameter

    int *ar=(int *)malloc(N*sizeof(int)); 	// parameter

    int found=0;

    int i;

    for(i=0;i<N;i++) 	// loop,parameter,array

    {

        scanf("%d",&ar[i]); 	// array,parameter

    }

    i=0;

    int sum=0;

    int j=N-1;

    while(i<=j) 	// parameter

    {

        sum=ar[i]+ar[j]; 	// array

        if(sum==rsum) 	// conditional,parameter,increment,decrement

        {

            found=1;

            break;

        }

        if(sum<rsum) 	// parameter

            i++; 	// increment

        else

            j--; 	// decrement

    }

    if(found==1) 	// conditional,parameter,array

        printf("%d %d %d %d",i,j,ar[i],ar[j]); 	// array,parameter

    else

        printf("NO"); 	// parameter

    return 0;

}

#include<stdio.h>

#include<stdlib.h>



int main()

{

    int n,a,i,j=0,k,sum;

    int* arr=(int*)malloc(100000000*sizeof(int)); 	// parameter

    scanf("%d %d",&n,&a); 	// parameter

    for(i=0;i<n;i++) 	// loop,parameter

    {

        scanf("%d",arr+i); 	// parameter

    }

    k=n-1;

    if(n<2) 	// parameter

    {

        printf("NO"); 	// parameter

    }

  else{

   while(j!=k) 	// parameter

    {

        sum=arr[j]+arr[k]; 	// array

        if(sum==a) 	// conditional,parameter,increment,decrement

        {

            printf("%d %d %d %d",j,k,arr[j],arr[k]); 	// array,parameter

            break;

        }

        else if(sum<a) 	// parameter

        {

            j++; 	// increment

        }

        else if(sum>a) 	// parameter

        {

            k--; 	// decrement

        }



    }

    if(j==k) 	// conditional,parameter

        {

            printf("NO"); 	// parameter

        }

  }



    return 0;

}

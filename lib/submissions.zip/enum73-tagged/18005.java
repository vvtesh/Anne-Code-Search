public enum Planet //enum,parameter
{
    MERCURY (3.303e+23, 2.4397e6),/* THIS DATA HAS BEEN TAKEN FROM THE INTERNET*/ 	// parameter
    VENUS   (4.869e+24, 6.0518e6), 	// parameter
    EARTH   (5.976e+24, 6.37814e6), 	// parameter
    MARS    (6.421e+23, 3.3972e6), 	// parameter
    JUPITER (1.9e+27,   7.1492e7), 	// parameter
    SATURN  (5.688e+26, 6.0268e7), 	// parameter
    URANUS  (8.686e+25, 2.5559e7), 	// parameter
    NEPTUNE (1.024e+26, 2.4746e7); 	// parameter
    private double mass;  
    private double radius;
    public static double G = 6.67300E-11;/*TILL HERE*/
    Planet(double m, double r)  	// parameter
    {
        this.mass = m;
        this.radius = r;
    }
    private double mass() 
    {
    	return mass;
    }
    private double radius() 
    {
    	return radius;
    }
    double GRAVITY_ON_SURFACE()  	// parameter
    {
        return (G *mass/(radius*radius));
    }
    double surfaceWeight(double earthMass) 	// parameter
    {
    	return earthMass * GRAVITY_ON_SURFACE(); 	// parameter
    }
    public static void main(String[] args)
    {
        double earthWeight = Double.parseDouble(args[0]); 	// array,parameter
        double m = earthWeight/EARTH.GRAVITY_ON_SURFACE();
        for (Planet p : Planet.values()) 	// parameter
           System.out.printf("Your weight on %s is %f%n",p, p.surfaceWeight(m)); 	// parameter
    }
}


enum Planets {
	Mercury, 
	Venus, 
	Earth,
	Mars, 
	Jupiter,
	Saturn,
	Uranus,
	Neptune
}

class weight {
	
Planets p;
	
	public weight(Planets p)
	{
		this.p=p;
	}
	
	public void WaightOnPlanet(float w) {
	    switch (p) { 	// parameter
	        case Mercury:
	            System.out.println("Weight on Mercury is: "+w*0.38+"kg"); 	// parameter,increment
	            break;
	                
	        case Venus:
	            System.out.println("Weight on Venus is: "+w*0.91+"kg"); 	// parameter,increment
	            break;
	                     
	        case Earth:
	            System.out.println("Weight on Earth is: "+w*1+"kg"); 	// parameter,increment
	            break;
	            
	        case Mars:
	            System.out.println("Weight on Mars is: "+w*0.38+"kg"); 	// parameter,increment
	            break;
	            
	        case Jupiter:
	            System.out.println("Weight on Jupiter is: "+w*2.34+"kg"); 	// parameter,increment
	            break;
	            
	        case Saturn:
	            System.out.println("Weight on Saturn is: "+w*0.93+"kg"); 	// parameter,increment
	            break;
	            
	        case Uranus:
	            System.out.println("Weight on Uranus is: "+w*0.92+"kg"); 	// parameter,increment
	            break;
	            
	        case Neptune:
	            System.out.println("Weight on Neptune is: "+w*1.12+"kg"); 	// parameter,increment
	            break;   
	    }
	}
	
}

public class Question6 {
		
	
	public static void main(String[] args) {
		float w = Float.parseFloat(args[0]); 	// array,parameter
		
		 weight one = new weight(Planets.Mercury); 	// parameter
	        one.WaightOnPlanet(w); 	// parameter
	     weight two = new weight(Planets.Venus); 	// parameter
	        two.WaightOnPlanet(w);    	// parameter
	     weight three = new weight(Planets.Earth); 	// parameter
	        three.WaightOnPlanet(w); 	// parameter
	     weight four = new weight(Planets.Mars); 	// parameter
	        four.WaightOnPlanet(w); 	// parameter
	     weight five = new weight(Planets.Jupiter); 	// parameter
	        five.WaightOnPlanet(w); 	// parameter
	     weight six = new weight(Planets.Saturn); 	// parameter
	        six.WaightOnPlanet(w); 	// parameter
	     weight seven = new weight(Planets.Uranus); 	// parameter
	        seven.WaightOnPlanet(w); 	// parameter
	     weight eight = new weight(Planets.Neptune); 	// parameter
	        eight.WaightOnPlanet(w); 	// parameter
	}
	
}

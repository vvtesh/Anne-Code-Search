public enum Planet { //enum,parameter
	Earth (1.0), 	// parameter
	Mercury (6.8), 	// parameter
	Venus (1.85), 	// parameter
	Mars (4.85), 	// parameter
	Jupiter (3.85), 	// parameter
	Saturn (8.85), 	// parameter
	Uranus (6.5), 	// parameter
	Neptune (2.5), 	// parameter
	Pluto (5.6); 	// parameter

    public double ratio_wrt_earth;

    Planet(double ratio_wrt_earth) { 	// parameter
        this.ratio_wrt_earth = ratio_wrt_earth;
    }
}

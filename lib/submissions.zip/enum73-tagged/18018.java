
public enum Planet  //enum,parameter
{
	
			MERCURY(0.378), 	// parameter
			VENUS(0.907), 	// parameter
			EARTH(1.00), 	// parameter
			MARS(0.377), 	// parameter
			SATURN(0.916), 	// parameter
			JUPITER(2.360), 	// parameter
			URANUS (0.889), 	// parameter
			NEPTUNE (1.120); 	// parameter
			
			private double gravityvalue;
			
			private Planet(double gravity )
			{
				this.gravityvalue=gravity;
			}
			public double getgravity()
			{
				return this.gravityvalue;
			}


}

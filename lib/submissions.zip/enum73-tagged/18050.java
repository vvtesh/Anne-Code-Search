package Q6;
import java.util.*;
public class weight {
	public enum planets {
		Mercury,Venus,Earth,Mars,Jupiter,Saturn,Uranus,Neptune,Pluto;	
	}
	
	planets name;
	
	public weight(planets name)
	{
		this.name = name;
	}
	
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in); 	// parameter
		System.out.println("Enter your weight:"); 	// parameter
		double w = input.nextDouble(); 	// parameter
		System.out.println("Your weight on all the planets are:"); 	// parameter
		double w2;
		System.out.print("On Mercury: "); 	// parameter
		w2=w*0.38;
		System.out.println(w2); 	// parameter
		
		System.out.print("On Venus: "); 	// parameter
		w2=w*0.91;
		System.out.println(w2); 	// parameter
		
		System.out.print("On Earth: "); 	// parameter
		w2=w*1.0;
		System.out.println(w2); 	// parameter
		
		System.out.print("On Mars: "); 	// parameter
		w2=w*0.38;
		System.out.println(w2); 	// parameter
		
		System.out.print("On Jupiter: "); 	// parameter
		w2=w*2.54;
		System.out.println(w2); 	// parameter
		
		System.out.print("On Saturn: "); 	// parameter
		w2=w*1.08;
		System.out.println(w2); 	// parameter
		
		System.out.print("On Uranus: "); 	// parameter
		w2=w*0.91;
		System.out.println(w2); 	// parameter
		
		System.out.print("On Neptune: "); 	// parameter
		w2=w*1.19;
		System.out.println(w2); 	// parameter
		
		System.out.print("On Pluto: "); 	// parameter
		w2=w*0.06;
		System.out.println(w2); 	// parameter
	}
}


public class Question6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ManWeight = Integer.parseInt(args[0]); 	// array,parameter
		int i;
		
		Planets mercury = Planets.Mercury;
		Planets venus = Planets.Venus;
		Planets earth = Planets.Earth;
		Planets mars = Planets.Mars;
		Planets jupiter = Planets.Jupiter;
		Planets saturn = Planets.Saturn;
		Planets uranus = Planets.Uranus;
		Planets neptune = Planets.Neptune;
		
		mercury.weight = 0.378 * ManWeight;
		venus.weight = 0.907 * ManWeight;
		earth.weight = ManWeight;
		mars.weight = 0.377 * ManWeight;
		jupiter.weight = 2.364 * ManWeight;
		saturn.weight = 1.064 * ManWeight;
		uranus.weight = 0.889 * ManWeight;
		neptune.weight = 1.125 * ManWeight;
		
		System.out.println("Planet			Weight"); 	// parameter
		System.out.println(); 	// parameter
		System.out.println("Mercury			"+ mercury.weight); 	// parameter
		System.out.println("Venus			"+ venus.weight); 	// parameter
		System.out.println("Earth			"+ earth.weight); 	// parameter
		System.out.println("Mars			"+ mars.weight); 	// parameter
		System.out.println("Jupiter			"+ jupiter.weight); 	// parameter
		System.out.println("Saturn			"+ saturn.weight); 	// parameter
		System.out.println("Uranus			"+ uranus.weight); 	// parameter
		System.out.println("Neptune			"+ neptune.weight); 	// parameter
	}

}

package question6;

public class WeightCalculate {
	//Planet p;
	/*public WeightCalculate(Planet pl)
	{
		this.p = pl;
	}*/
	public static void TellWeight(float w , Planet p)
	{
		float weightonp;
		 switch (p) { 	// parameter
         case Mercury:
        	 weightonp = (float)(w*0.38); 	// parameter
             System.out.println("weight on mercury is "+weightonp); 	// parameter
             break;
                 
         case Venus:
        	 weightonp = (float)(w*0.91); 	// parameter
             System.out.println("weight on venus is "+ weightonp); 	// parameter
             break;
         
         case Earth:
        	 weightonp = (float)(w); 	// parameter
             System.out.println("weight on earth is "+ weightonp); 	// parameter
             break;    
                      
         case Mars:
        	 weightonp = (float)(w*0.38); 	// parameter
             System.out.println("weight on mars is "+ weightonp); 	// parameter
             break;
             
         case Jupiter:
        	 weightonp = (float)(w*2.34); 	// parameter
             System.out.println("weight on jupiter is "+ weightonp); 	// parameter
             break;
             
         case Saturn:
        	 weightonp = (float)(w*0.93); 	// parameter
             System.out.println("weight on saturn is "+ weightonp); 	// parameter
             break;    
               
         case Uranus:
        	 weightonp = (float)(w*0.92); 	// parameter
             System.out.println("weight on Uranus is "+ weightonp); 	// parameter
             break;
           
         case Neptune:
        	 weightonp = (float)(w*1.12); 	// parameter
             System.out.println("weight on neptune is "+ weightonp); 	// parameter
             break;    
         default:
             System.out.println("these are your weights"); 	// parameter
             break;
     }
	}

}

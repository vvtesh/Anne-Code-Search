package ap2014.asgnmnt1.question6;

public enum planets //enum,parameter
{
	 MERCURY (3.303* Math.pow(10,23),2.4397 * Math.pow(10,6)), 	// parameter
	 VENUS (4.869* Math.pow(10,24),6.0518*Math.pow(10,6)), 	// parameter
	 EARTH (5.976*Math.pow(10,24),6.37814*Math.pow(10,6)), 	// parameter
	 MARS (6.421*Math.pow(10,23),3.3972*Math.pow(10,6)), 	// parameter
	 JUPITER (1.9*Math.pow(10,27),7.1492*Math.pow(10,7)), 	// parameter
	 SATURN (5.688*Math.pow(10,26),6.0268*Math.pow(10,7)), 	// parameter
	 URANUS (8.686*Math.pow(10,25),2.5559*Math.pow(10,7)), 	// parameter
	 NEPTUNE (1.024*Math.pow(10,26),2.4746*Math.pow(10,7)); 	// parameter
	 private final double mass;
	 private final double radius;
	  planets(double mass, double radius)  	// parameter
	  {
	      this.mass = mass;
	      this.radius = radius;
	  }
	  public double mass()   { return mass; }
	  public double radius() { return radius; }
	 
	  public static final double G = 6.67300*Math.pow(10,-11);
	 
	  public double surfaceG()
	  {
	      return G*(mass/(radius*radius));
	  }
	  public double surfaceWeight(double Mass2) {
	      return Mass2 * surfaceG(); 	// parameter
	  }
}

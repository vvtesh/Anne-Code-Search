import java.util.*;


public class wop
{
	public enum Planet
{
	MERCURY,VENUS,EARTH,MARS,JUPITER,SATURN,URANUS,NEPTUNE
}

	Planet p;
	public wop(Planet p)
	{
		this.p = p;
	}
	public void calculate(double n)
	{
		
		switch(p) 	// parameter
		{
		case MERCURY:
		double a = (n * 0.38); 	// parameter
		System.out.println("weight on mercury" + a); 	// parameter
		break;
		
		case VENUS:
		double b = (n * 0.91); 	// parameter
		System.out.println("weight on venus" + b); 	// parameter
		break;
		
		case EARTH:
		double c = (n); 	// parameter
		System.out.println("weight on earth" + c); 	// parameter
		break;
		
		case MARS:
		double d = (n * 0.38); 	// parameter
		System.out.println("weight on mars" + d); 	// parameter
		break;
		
		case JUPITER:
		double e = (n * 2.34); 	// parameter
		System.out.println("weight on jupiter" + e); 	// parameter
		break;
		
		case SATURN:
		double f = (n * 1.06); 	// parameter
		System.out.println("weight on saturn" + f); 	// parameter
		break;
		
		case URANUS:
		double g = (n * 0.92); 	// parameter
		System.out.println("weight on uranus" + g); 	// parameter
		break;
		
		case NEPTUNE:
		double h = (n * 1.19); 	// parameter
		System.out.println("weight on neptune" + h); 	// parameter
		break;
		}
	}
	public static void main(String [] args)
		{
		double n = Integer.parseInt(args[0]); // weight on earth 	// array,parameter
		wop firstPlanet = new wop(Planet.MERCURY); 	// parameter
        firstPlanet.calculate(n); 	// parameter
		wop secondPlanet = new wop(Planet.VENUS); 	// parameter
        secondPlanet.calculate(n); 	// parameter
        wop thirdPlanet = new wop(Planet.EARTH); 	// parameter
        thirdPlanet.calculate(n); 	// parameter
		wop fourthPlanet = new wop(Planet.MARS); 	// parameter
        fourthPlanet.calculate(n); 	// parameter
        wop fifthPlanet = new wop(Planet.JUPITER); 	// parameter
        fifthPlanet.calculate(n); 	// parameter
        wop sixthPlanet = new wop(Planet.SATURN); 	// parameter
        sixthPlanet.calculate(n); 	// parameter
        wop seventhPlanet = new wop(Planet.URANUS); 	// parameter
        seventhPlanet.calculate(n); 	// parameter
		wop eighthPlanet = new wop(Planet.NEPTUNE); 	// parameter
        eighthPlanet.calculate(n); 	// parameter
		}
	}

		
		

	                                                                                                       

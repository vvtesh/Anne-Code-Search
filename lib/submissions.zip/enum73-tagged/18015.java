package q6;

	//Each planet has its surface gravity associated with it.
	//Source of surface gravities: http://www.smartconversion.com/otherInfo/gravity_of_planets_and_the_sun.aspx	
	public enum Planet { //enum,parameter
		MERCURY (3.7), 	// parameter
		VENUS (8.87), 	// parameter
		EARTH (9.798), 	// parameter
		MARS (3.71), 	// parameter
		JUPITER (24.92), 	// parameter
		SATURN (10.44), 	// parameter
		URANUS (8.87), 	// parameter
		NEPTUNE (11.15); 	// parameter
		//Format is PlanetName(SurfaceGravityOnThatPlanet in m/s^2)
		private double surfaceGravity;
		
		private Planet(double surfaceGravity) {
			this.surfaceGravity = surfaceGravity;
		}
		
		public double getSG() {
			return surfaceGravity;
		}
	}

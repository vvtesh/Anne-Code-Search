
public class weight {
	public enum Planet{
		mercury,venus,earth,mars,jupiter,saturn,uranus,neptune;
	}
	Planet planet;
	private static double[] arrs;
	
	public static void main(String[] args)
{
		String  s = args[0]; 	// string,array
		double input = Double.parseDouble(s);; 	// parameter
		arrs = new double[] {0.378,0.907,1,0.377,2.36,0.916,0.889,1.12};
		Planet[] values = Planet.values(); 	// array,parameter
		for (int i = 0; i < values.length; i++) { 	// loop,parameter
			Planet p = values[i]; 	// array
			System.out.println("The weight on " + p + " is " + arrs[i]*input); 	// array,parameter,increment
		}
		}
}

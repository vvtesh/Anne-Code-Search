package Question_6;

public enum Planets { //enum,parameter

MERCURY (0.38), 	// parameter
VENUS (0.91), 	// parameter
MARS (0.38), 	// parameter
JUPITER (2.34), 	// parameter
SATURN (1.06), 	// parameter
NEPTUNE (1.19), 	// parameter
PLUTO (0.06); 	// parameter
private double ratio;
Planets(double r) 	// parameter
{ ratio = r;
}
public double weightonotherplanets(double eweight)
{
 return eweight*ratio;
}
 }
 

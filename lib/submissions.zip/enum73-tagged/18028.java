public enum Planets { //enum,parameter
	mercury(0.38), 	// parameter
	venus(0.91), 	// parameter
	earth(1), 	// parameter
	mars(0.38), 	// parameter
	jupiter(2.36), 	// parameter
	saturn(0.91), 	// parameter
	uranus(0.89), 	// parameter
	neptune(1.12); 	// parameter
	
	public final double multiplier;
	
	Planets(double X){ 	// parameter
		multiplier = X;
	}
	
	public double getMultiplier(){
		return multiplier;
	}
}

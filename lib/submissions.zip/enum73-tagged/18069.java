enum Planet{
MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, NEPTUNE, URANUS;
}

public class Questionsix{

Planet planets;


    public Questionsix(Planet planets) {
        this.planets = planets;
    }
    
    public void weight(int n) {
	
	//int n = Integer.parseInt(args[0]);
	double a,b,c,d,e,f,g,h;
        switch (planets) { 	// parameter
            case MERCURY:
			    a = n*0.38;
                System.out.println("Mercury     " +a); 	// parameter
                break;
                    
            case VENUS:
			    b = n*0.91;
                System.out.println("Venus       " +b); 	// parameter
                break;
                         
            case EARTH :
			    c = n*1;
                System.out.println("Earth       "  +c) ; 	// parameter
                break;
				
			case MARS :
			    d = n*0.38;
                System.out.println("Mars        " +d); 	// parameter
                break;
				
			case JUPITER :
			    e = n*2.36;
                System.out.println("Jupiter     "+e); 	// parameter
                break;
			
			case SATURN :
			    f = n*0.91;
                System.out.println("Saturn      " +f); 	// parameter
                break;
				
			case URANUS :
			    g = n*0.89;
                System.out.println("Uranus      " +g); 	// parameter
                break;
				
	    	case NEPTUNE :
			    h = n*1.12;
                System.out.println("Neptune     " +h); 	// parameter
                break;
                        
            default:
                System.out.println("Midweek days are so-so."); 	// parameter
                break;
        }
    }
    
    public static void main(String[] args) {
    	
    	int c = Integer.parseInt(args[0]); 	// array,parameter
        Questionsix first = new Questionsix(Planet.MERCURY); 	// parameter
        first.weight(c); 	// parameter
        
		Questionsix second = new Questionsix(Planet.VENUS); 	// parameter
        second.weight(c); 	// parameter
		
		Questionsix third = new Questionsix(Planet.EARTH); 	// parameter
        third.weight(c); 	// parameter
		
		Questionsix four = new Questionsix(Planet.MARS); 	// parameter
        four.weight(c); 	// parameter
		
		Questionsix five = new Questionsix(Planet.JUPITER); 	// parameter
        five.weight(c); 	// parameter
		
		Questionsix six = new Questionsix(Planet.SATURN); 	// parameter
        six.weight(c); 	// parameter
		
		Questionsix seven = new Questionsix(Planet.URANUS); 	// parameter
        seven.weight(c); 	// parameter
		
		Questionsix eight = new Questionsix(Planet.NEPTUNE); 	// parameter
        eight.weight(c); 	// parameter
    }
}

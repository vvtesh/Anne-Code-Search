package Question6;

public class enums {
	public enum Planet { //enum,parameter
		MERCURY ( 3.30e+23,  2440), 	// parameter
		VENUS   (4.87e+24 ,  6052), 	// parameter
		EARTH   (5.976e+24,  6378), 	// parameter
		MARS    (6.421e+23, 3397), 	// parameter
		JUPITER (1.9e+27,    71492 ), 	// parameter
		SATURN  (5.688e+26, 60268 ), 	// parameter
		URANUS  (8.686e+25, 25559), 	// parameter
		NEPTUNE (1.024e+26, 24766), 	// parameter
		PLUTO (1.27e+22, 1150); 	// parameter
	
	public double mass;
	public double radius;
	
	Planet(double mass, double radius) { 	// parameter
        this.mass = mass;
        this.radius = radius;
    }
	public static final double G = 6.67300E-11;
	public double surfaceGravity() {
        return G * mass / (radius * radius);
    }
	public double surfaceWeight(double otherMass) {
        return otherMass * surfaceGravity(); 	// parameter
    }
	
	
}
}

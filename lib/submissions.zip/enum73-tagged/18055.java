//mdm

public enum Planet {


                            MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE;

  int w;
  
  
	public static void weightConversion(Planet x,int w){
		
	 if(x==MERCURY) 	// conditional,parameter
	    	System.out.println("Equivalent weight on Mercury is : " + w*0.378); 	// parameter
	 else if(x==VENUS) 	// conditional,parameter
	    	System.out.println("Equivalent weight on Venus is : " + w*0.907); 	// parameter
	 else if(x==EARTH) 	// conditional,parameter
	    	System.out.println("Equivalent weight on Earth is : " + w); 	// parameter
	 else if(x==MARS) 	// conditional,parameter
	    	System.out.println("Equivalent weight on Mars is : " + w*0.377); 	// parameter
	 else if(x==JUPITER) 	// conditional,parameter
	    	System.out.println("Equivalent weight on Jupiter is : " + w*2.364); 	// parameter
	 else if(x==SATURN) 	// conditional,parameter
	    	System.out.println("Equivalent weight on Saturn is : " + w*0.916); 	// parameter
	 else if(x==URANUS) 	// conditional,parameter
	    	System.out.println("Equivalent weight on Uranus is : " + w*0.889); 	// parameter
	 else if(x==NEPTUNE) 	// conditional,parameter
	    	System.out.println("Equivalent weight on Neptune is : " + w*1.125); 	// parameter
	
	}

}

import java.util.*;
import java.lang.*;

public class WeightPlanet  {

 public enum Planets {
    MERCURY, VENUS, MARS, EARTH, JUPITER, 
	SATURN, URANUS, NEPTUNE  }

	
Planets plan ;
public WeightPlanet(Planets plan)  {
  this.plan = plan;
}

public void funct(double n)  {
    switch(plan) { 	// parameter
			case MERCURY:
			    double a = (n*0.38); 	// parameter
			    System.out.println("Weight on mercury:" + a); 	// parameter
			    break;
			case VENUS:
				double b = (n*0.91);  	// parameter
			     System.out.println("Weight on VENUS:" + b); 	// parameter
				break;
			case MARS:
			    double c = (n*0.38);  	// parameter
				System.out.println("Weight on MARS:" + c); 	// parameter
			    break;
			case EARTH:
			    double d = (n*1.0);  	// parameter
				System.out.println("Weight on EARTH:" + d); 	// parameter
			    break;
			case JUPITER:
			    double e = (n*2.34);  	// parameter
				System.out.println("Weight on JUPITER:" + e); 	// parameter
			    break;
			case SATURN:
			    double f = (n*1.06); 	// parameter
				System.out.println("Weight on SATURN:" + f); 	// parameter
			    break;
			case URANUS:
			    double g = (n*0.92); 	// parameter
				System.out.println("Weight on URANUS:" + g); 	// parameter
			    break;
			case NEPTUNE:
			     double h = (n*1.19); 	// parameter
				System.out.println("Weight on NEPTUNE:" + h); 	// parameter
				break;
		}		
	}	
	public static void main(String[] args)  {
	   double n = Double.parseDouble(args[0]); 	// array,parameter
	   WeightPlanet mercury = new WeightPlanet(Planets.MERCURY); 	// parameter
	   mercury.funct(n); 	// parameter
	 WeightPlanet venus = new WeightPlanet(Planets.VENUS); 	// parameter
	   venus.funct(n); 	// parameter
	 WeightPlanet mars = new WeightPlanet(Planets.MARS); 	// parameter
	   mars.funct(n); 	// parameter
	 WeightPlanet earth = new WeightPlanet(Planets.EARTH); 	// parameter
	   earth.funct(n); 	// parameter
	 WeightPlanet jupiter = new WeightPlanet(Planets.JUPITER); 	// parameter
	   jupiter.funct(n); 	// parameter
	 WeightPlanet saturn = new WeightPlanet(Planets.SATURN); 	// parameter
	   saturn.funct(n); 	// parameter
	 WeightPlanet uranus = new WeightPlanet(Planets.URANUS); 	// parameter
	   uranus.funct(n); 	// parameter
	 WeightPlanet neptune = new WeightPlanet(Planets.NEPTUNE); 	// parameter
	   neptune.funct(n); 	// parameter
	 }
}	 

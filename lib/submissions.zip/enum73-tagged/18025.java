/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ques6;
import java.util.Scanner;
public class Ques6 {





  public enum Planets { //enum,parameter
  Mercury (3.303e+23, 2.4397e6), 	// parameter
  Venus   (4.869e+24, 6.0518e6), 	// parameter
  Earth   (5.976e+24, 6.37814e6), 	// parameter
  Mars    (6.421e+23, 3.3972e6), 	// parameter
  Jupiter (1.9e+27,   7.1492e7), 	// parameter
  Saturn  (5.688e+26, 6.0268e7), 	// parameter
  Uranus  (8.686e+25, 2.5559e7), 	// parameter
  Neptune (1.024e+26, 2.4746e7), 	// parameter
  Pluto   (1.27e+22,  1.137e6); 	// parameter
 
  private final double mass_inKg,radius_inMeter;   
  public static final double G = 6.67300E-11;
  
  Planets(double mass_inKg, double radius_inMeter) { 	// parameter
      this.mass_inKg = mass_inKg;
      this.radius_inMeter = radius_inMeter;
  }
  
  public double surfaceGravity() {
      return G * mass_inKg / (radius_inMeter * radius_inMeter);
  }
  public double mass_inKg()   { 
      return mass_inKg;
  }
  
  
  public double radius_inMeter() 
  { 
      return radius_inMeter;
  }
  
   
  
  public double surfaceWeight(double otherMass) {
      return otherMass * surfaceGravity(); 	// parameter
  }
}
 

public static void main(String[] args) {
    Planets pE = Planets.Earth;
    double earthRadius = pE.radius_inMeter();  	// parameter
 
    
Scanner inputReader = new Scanner(System.in); 	// parameter

System.out.println("Please enter ur weight:"); 	// parameter
double earthWeight = inputReader.nextInt(); 	// parameter
   
double mass_inKg = earthWeight/pE.surfaceGravity();
for (Planets p : Planets.values()) 	// parameter
System.out.printf("On %s---> %f%n",p, p.surfaceWeight(mass_inKg)); 	// parameter


    
}
}

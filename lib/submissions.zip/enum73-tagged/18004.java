package ap2014.asgnmnt1.question6;

import java.util.Scanner;

public class Question6 {
{

    public static void main(String[] args) {
    
System.out.println("Enter your mass(Kg)"); 	// parameter
Scanner scan;
    scan = new Scanner(System.in); 	// parameter
    double weight;
    weight = scan.nextDouble(); 	// parameter
for (Planets planet : Planets.values()) 	// parameter
{
System.out.println("Weight on planet "+ planet.toString() +" = "+ (planet.gravity*weight)+" Newton"); 	// parameter,increment
}
}
 
    /**
     *
     */
    public enum Planets //enum,parameter
{
Mercury(0.38),  	// parameter
Venus(0.91),  	// parameter
Earth(0.98),  	// parameter
Mars(0.38), 	// parameter
Jupiter(2.54),  	// parameter
Saturn(1.07),  	// parameter
Uranus(0.9), 	// parameter
Neptune(1.15), 	// parameter
Pluto(0.08); 	// parameter

    private double gravity;

    private Planets(double value) 
    {
            this.setGravity(value); 	// parameter
    }

public double getGravity() 
{
return gravity;
}
 
        /**
         *
         * @param gravity
         */
        public void setGravity(double gravity) 
{
this.gravity = gravity;
}   };  

    /**
     *
     * @param args
     */
    @SuppressWarnings("resource") 	// parameter

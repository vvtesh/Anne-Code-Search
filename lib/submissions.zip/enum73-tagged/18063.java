package question6;
import java.util.Scanner;

public class myWeight {
	public enum Planets {
		MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE
	}
	
	Planets myPlanet;
	public myWeight(Planets inputPlanet){
		this.myPlanet = inputPlanet;
	}
	
	public void tellMyWeight(double w) {
		switch (myPlanet){ 	// parameter
		case MERCURY:
			System.out.printf("Mercury = %.3f kg\n",w*0.378); 	// parameter
			break;
		case VENUS:
			System.out.printf("Venus = %.3f kg\n",w*0.907); 	// parameter
			break;
		case EARTH:
			System.out.printf("Earth = %.3f kg\n", w);				 	// parameter
			break;
		case MARS:
			System.out.printf("Mars = %.3f kg\n", w*0.377);	 	// parameter
			break;
		case JUPITER:
			System.out.printf("Jupiter = %.3f kg\n", w*2.364);			 	// parameter
			break;
		case SATURN:
			System.out.printf("Saturn = %.3f kg\n", w*1.064);	 	// parameter
			break;
		case URANUS:
			System.out.printf("Saturn = %.3f kg\n", w*1.064);	 	// parameter
			break;
		case NEPTUNE:
			System.out.printf("Neptune = %.3f kg\n", w*1.125);	 	// parameter
			break;
		}
	}
	
	public static void main(String[] args){
		Scanner obj = new Scanner(System.in); 	// parameter
		double w = obj.nextDouble(); 	// parameter
		myWeight Planet1 = new myWeight(Planets.MERCURY); 	// parameter
		Planet1.tellMyWeight(w); 	// parameter
		
		myWeight Planet2 = new myWeight(Planets.VENUS); 	// parameter
		Planet2.tellMyWeight(w); 	// parameter
		
		myWeight Planet3 = new myWeight(Planets.EARTH); 	// parameter
		Planet3.tellMyWeight(w); 	// parameter
		
		myWeight Planet4 = new myWeight(Planets.MARS); 	// parameter
		Planet4.tellMyWeight(w); 	// parameter
		
		myWeight Planet5 = new myWeight(Planets.JUPITER); 	// parameter
		Planet5.tellMyWeight(w); 	// parameter
		
		myWeight Planet6 = new myWeight(Planets.SATURN); 	// parameter
		Planet6.tellMyWeight(w); 	// parameter
		
		myWeight Planet7 = new myWeight(Planets.URANUS); 	// parameter
		Planet7.tellMyWeight(w); 	// parameter
		
		myWeight Planet8 = new myWeight(Planets.NEPTUNE); 	// parameter
		Planet8.tellMyWeight(w); 	// parameter
	}
}

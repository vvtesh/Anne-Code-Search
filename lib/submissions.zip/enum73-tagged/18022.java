package ap2014asgnmnt1Ques6;

public enum Planets //enum,parameter
	{
		Mercury(0.38),  	// parameter
	    Venus(0.91),  	// parameter
	    Earth(1.0),  	// parameter
	    Mars(0.38),  	// parameter
	    Jupiter(2.36),  	// parameter
	    Saturn(0.91),  	// parameter
	    Uranus(0.89), 	// parameter
	    Neptune(1.12); 	// parameter
		
		double value;
	    
	    private Planets(double value)
	    {
	        this.value = value;
	    }
	}
	

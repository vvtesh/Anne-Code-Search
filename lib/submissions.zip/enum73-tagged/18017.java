package mainclasses;

import java.util.*;
import java.util.Scanner;

public class question6 {

		public enum planet {

			MERCURY, VENUS,EARTH,MARS,JUPITOR,SATURN,URANUS,NEPTUNE,PLUTO,
		}
		
		planet name;
		
		
		public question6(planet name) {
	       this.name=name; 
	    }
		 
		public void calc(int n){
			switch(name){ 	// parameter
			case MERCURY: {  double x;
							x = n * 0.38;
							System.out.println("mercury " +x); 	// parameter
							break;
			               }
			case VENUS: { double x;
			              x= n *0.91;
			              System.out.println("venus " +x); 	// parameter
				          break;
			            }
			case EARTH: { double x;
						 x= n * 1.0;
						 System.out.println("earth " +x); 	// parameter
						 break;
						}
			case MARS: { double x;
	        			x= n * 0.38;
	        			System.out.println("mars " +x); 	// parameter
	        			break;
	                      }
			case JUPITOR: { double x;
							x= n * 2.34;
							System.out.println("jupitor " +x); 	// parameter
							break;
	                        }
			case SATURN: { double x;
	        			  x= n * 1.06;
	        			  System.out.println("saturn " +x); 	// parameter
	        			  break;
	                     }
			case URANUS : { double x;
	        			   x= n * 0.92;
	        			   System.out.println("uranus " +x); 	// parameter
	        			   break;
	                       }
			case NEPTUNE: { double x;
	               		 x= n * 1.19;
	               		 System.out.println("neptune " +x); 	// parameter
	               		 break;
	                      }
			case PLUTO: { double x;
	        			x= n * 0.06;
	        			System.out.println("pluto " +x); 	// parameter
	        			break;
	                    }
			}
		}
		
		
		public static void main(String[] args) {
			
	     int n;
	     System.out.println("Enter the weight of the user(in kgs): "); 	// parameter
	     Scanner integer = new Scanner(System.in); 	// parameter
	 	  n = integer.nextInt(); 	// parameter
	 
	 	 question6 mercury = new question6 (planet.MERCURY); 	// parameter
	 	 mercury.calc(n); 	// parameter
	 	 question6 venus = new question6 (planet.VENUS); 	// parameter
	 	 venus.calc(n); 	// parameter
	 	 question6 earth = new question6 (planet.EARTH); 	// parameter
	 	 earth.calc(n); 	// parameter
	 	 question6 mars = new question6 (planet.MARS); 	// parameter
	 	 mars.calc(n); 	// parameter
	 	 question6 jupitor = new question6 (planet.JUPITOR); 	// parameter
	 	 jupitor.calc(n); 	// parameter
	 	 question6 saturn = new question6 (planet.SATURN); 	// parameter
	 	 saturn.calc(n); 	// parameter
	 	 question6 uranus = new question6 (planet.URANUS); 	// parameter
	 	 uranus.calc(n); 	// parameter
	 	 question6 neptune = new question6 (planet.NEPTUNE); 	// parameter
	 	 neptune.calc(n); 	// parameter
	 	 question6 pluto = new question6 (planet.PLUTO); 	// parameter
	 	 pluto.calc(n); 	// parameter
		}
	}

		

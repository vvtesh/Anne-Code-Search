package q6;

public class q6 { 
	enum Planet{ //enum,parameter
		MERCURY(0.378), 	// parameter
	    VENUS(0.907), 	// parameter
	    EARTH(1), 	// parameter
	    MARS(0.377), 	// parameter
	    JUPITER(2.364), 	// parameter
	    SATURN(0.916), 	// parameter
	    URANUS(0.889), 	// parameter
	    NEPTUNE(1.125), 	// parameter
	    PLUTO(0.067); 	// parameter
	
		private final double factor;
		Planet(double factor){ 	// parameter
			this.factor = factor;
		}
		private double factor(){return factor;}
		
		double calculate(double weight){ 	// parameter
			return weight*factor;
		}
	}

	public int weight(int w){
		System.out.println("Your Weight on Mercury is : " + 0.378*w); 	// parameter
		System.out.println("Your Weight on Venus is : " + 0.907*w); 	// parameter
		System.out.println("Your Weight on Mars is : " + 0.377*w); 	// parameter
		System.out.println("Your Weight on Jupiter is : " + 2.364*w); 	// parameter
		System.out.println("Your Weight on Saturn is : " + 0.916*w); 	// parameter
		System.out.println("Your Weight on Uranus is : " + 0.889*w); 	// parameter
		System.out.println("Your Weight on Neptune is : " + 1.125*w); 	// parameter
		System.out.println("Your Weight on Pluto is : " + 0.067*w + " (We pity the poor chap)"); 	// parameter,increment
		return 0;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double weight = Double.parseDouble(args[0]); 	// array,parameter
		for (Planet p : Planet.values()){ 	// parameter
			System.out.println("Your weight on " + p + " is " + p.calculate(weight) + "\n"); 	// parameter,increment
		}
	          
	                             
		
	}

}

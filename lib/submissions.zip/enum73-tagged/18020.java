

package assignment1;

import java.util.Scanner;
public class Question6 {
    
    enum Planets { //enum,parameter
   Mercury(0.38),Venus(0.91),Earth(1),Mars(0.38),Jupiter(2.54),Saturn(1.08),Uranus(0.91),Neptune(1.19),Pluto(0.06); 	// parameter
   private double weight;
   Planets(double p) { 	// parameter
      weight = p;
   }
   double getWeight() { 	// parameter
      return weight;
   } 
}
    
    
    public static void main(String[] args) {
        System.out.println(" Grvitation factor of every planet relative to earth ---- >"); 	// parameter
        System.out.println("Mercury gravitation factor => 0.38"); 	// parameter
        System.out.println("Venus   gravitation factor => 0.91"); 	// parameter
        System.out.println("Earth   gravitation factor =>    1"); 	// parameter
        System.out.println("Mars    gravitation factor => 0.38"); 	// parameter
        System.out.println("Jupiter gravitation factor => 2.54"); 	// parameter
        System.out.println("Saturn  gravitation factor => 1.08"); 	// parameter
        System.out.println("Uranus  gravitation factor => 0.91"); 	// parameter
        System.out.println("Neptune gravitation factor => 1.19"); 	// parameter
        System.out.println("Pluto   gravitation factor => 0.06"); 	// parameter
        System.out.println("cirits claim that pluto isn't a panet because it's orbit intersects with the orbit of neptunes"); 	// parameter
        System.out.println(" some may call it a dwarf planet"); 	// parameter
        System.out.println("but i have added it into my list coz i still consider it as a planet"); 	// parameter
        System.out.println("because it satisfies all the other properties of a planet except the orbit exception"); 	// parameter
        System.out.println(""
                + "");
        try{
        System.out.println("Please enter your weight(in kgs) to calculate your weight on every planet of our solar system listed above"); 	// parameter
      Scanner input = new Scanner(System.in); 	// parameter
 
      double x = input.nextInt(); 	// parameter
      
      System.out.println("Your weight on every abovementioned 9 planets of our solar system is  --->:"); 	// parameter
      for (Planets c : Planets.values()) 	// parameter
      System.out.println(" You shall weigh on Planet   " + c + "     =>  "
      + c.getWeight()*x + "kgs"); 	// parameter,increment
      
        }
        catch(Exception e) 	// parameter
        {
            System.out.println("Exception occoured : "+e); 	// parameter
        }
                
    }
    
    
    
    
    
    
}

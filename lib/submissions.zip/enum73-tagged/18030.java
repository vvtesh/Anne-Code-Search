import java.util.*;

public enum Question6
{
	MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE;

	static int w;
	public static void printWeight(Question6 P)
	{
		switch(P) 	// parameter
		{
			case MERCURY : System.out.println("Weight on Mercury is : " + w*0.38); 	// parameter
						   break;
			case VENUS : System.out.println("Weight on Venus is : " + w*0.91); 	// parameter
						   break;
			case EARTH : System.out.println("Weight on Earth is : " + w); 	// parameter
						   break;
			case MARS : System.out.println("Weight on Mars is : " + w*0.38); 	// parameter
						   break;
			case JUPITER : System.out.println("Weight on Jupiter is : " + w*2.36); 	// parameter
						   break;
			case SATURN : System.out.println("Weight on Saturn is : " + w*0.91); 	// parameter
						   break;
			case URANUS : System.out.println("Weight on Uranus is : " + w*0.89); 	// parameter
						   break;
			case NEPTUNE : System.out.println("Weight on Neptune is : " + w*1.12); 	// parameter
						   break;
		}
	}

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in); 	// parameter
		System.out.print("Enter your weight on Earth : "); 	// parameter
		w = in.nextInt(); 	// parameter
		for(Question6 P: Question6.values()) 	// parameter
		{
			printWeight(P); 	// parameter
		}
	}
}

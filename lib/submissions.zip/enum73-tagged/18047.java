import java.util.Scanner;

public class Question6 {
	public enum Planet { //enum,parameter
		MERCURY(0.38), VENUS(0.91), EARTH(1.00), MARS(0.38), JUPITER(2.34), SATURN( 	// parameter
				1.06), URANUS(0.92), NEPTUNE(1.19); 	// parameter
		private double mass;

		private Planet(double mass) {
			this.mass = mass;
		}
	}

	public static void main(String[] args) {
		double a;
		System.out.println("Enter your weight on earth in Kgs:"); 	// parameter
		Scanner in = new Scanner(System.in); 	// parameter
		a = in.nextInt(); 	// parameter
		System.out.println("----------------"); 	// parameter
		in.close(); 	// parameter
		for (Planet p : Planet.values()) { 	// parameter
			float myfloat = (float) (a * p.mass); 	// parameter
			System.out.println(p+"\t|  " + myfloat); 	// parameter,increment
		}
		System.out.println("----------------"); 	// parameter
	}
}

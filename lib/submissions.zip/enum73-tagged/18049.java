package ap2014.assignment1.Question6;

public enum Planets { //enum,parameter

	  MERCURY(0.38), 	// parameter
	  VENUS(0.91), 	// parameter
	  EARTH(1.00), 	// parameter
	  MARS(0.38), 	// parameter
	  JUPITER(2.34), 	// parameter
	  SATURN(1.06), 	// parameter
	  URANUS(0.92), 	// parameter
	  NEPTUNE(1.19); 	// parameter
	  private final double factor;
	  
	  Planets(double f) { 	// parameter
	        this.factor = f;
	    }
	  
	  public static void calcvals(double weight) {
		  for (Planets p : Planets.values()) 	// parameter
	            System.out.println("Your weight on "+p+" is "+(weight*p.factor)+"(kgs/pounds)"); 	// parameter,increment
	  }
}

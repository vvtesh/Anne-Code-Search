
public enum Planets { //enum,parameter
	moon(0.165),mercury(0.38),venus(0.91),mars(0.38),earth(1.00),jupiter(2.34),saturn(1.06),uranus(0.92),neptune(1.19),pluto(0.06); 	// parameter
	private double price; 
	// Constructor
	Planets(double p)  	// parameter
	{ 
	//int n,sum;
	price = p; 
	}
	double get(double as)  	// parameter
	{ 

	return price*as; 
	}

}

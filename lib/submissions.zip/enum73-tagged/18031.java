package Question6;

public enum Question6 { //enum,parameter
	
	    Mercury (3.303e+23, 2.4397e6), 	// parameter
	    Venus   (4.869e+24, 6.0518e6), 	// parameter
	    Earth   (5.976e+24, 6.37814e6), 	// parameter
	    Mars    (6.421e+23, 3.3972e6), 	// parameter
	    Jupiter (1.9e+27,   7.1492e7), 	// parameter
	    Saturn  (5.688e+26, 6.0268e7), 	// parameter
	    Uranus  (8.686e+25, 2.5559e7), 	// parameter
	    Neptune (1.024e+26, 2.4746e7); 	// parameter

	     final double mass;   
	     final double radius;  
	    Question6(double mass, double radius) { 	// parameter
	        this.mass = mass;
	        this.radius = radius;
	    }
	    double mass() {  	// parameter
	        return mass;
	        }
	    double radius() {  	// parameter
	        return radius;
	        }

	    
	    public static double G = 6.67300E-11;

	    double surfaceGravity() { 	// parameter
	       double val1=G * mass / (radius * radius);
	        return val1;
	    }
	    double surfaceWeight(double otherMass) { 	// parameter
	        double val2=otherMass*surfaceGravity(); 	// parameter
	        return val2;
	    }
	    public static void main(String[] args) {
	        if (args.length != 1) { 	// conditional,parameter
	            System.err.println("oops you forgot to enter your weight"); 	// parameter
	            System.exit(0); 	// parameter
	        }
	        double UserWeight = Double.parseDouble(args[0]); //input from user 	// array,parameter
	        double mass = UserWeight/Earth.surfaceGravity();
	        for (Question6 w : Question6.values()) 	// parameter
	           System.out.printf("Weight on %s is %f%n",
	                             w, w.surfaceWeight(mass)); 	// parameter
	    }

	}

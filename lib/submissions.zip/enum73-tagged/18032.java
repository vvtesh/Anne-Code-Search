package assignment1;

//import java.util.Scanner;

public enum Q6 //enum,parameter
{
    MERCURY (0.38), 	// parameter
    VENUS   (0.91), 	// parameter
    EARTH   (1.0), 	// parameter
    MARS    (1.03), 	// parameter
    JUPITER (0.41), 	// parameter
    SATURN  (0.43), 	// parameter
    URANUS  (0.75), 	// parameter
    NEPTUNE (0.67); 	// parameter

    double gravity;
	//private static Scanner input;
    
    Q6(double gravity) 	// parameter
    {
        this.gravity = gravity;
    }
    
    double getWeight(double mass) 	// parameter
    {
    	return mass * this.gravity;
    }

    public static void main(String[] args) 
    {
    	//input = new Scanner(System.in);
    	//System.out.print("Enter weight on Earth : ");
    	//double mass = input.nextDouble();
    	double mass = Double.parseDouble(args[0]); 	// array,parameter
        for (Q6 p : Q6.values()) 	// parameter
           System.out.printf("Your weight on %s is %f%n",
                             p, p.getWeight(mass)); 	// parameter
    }
}

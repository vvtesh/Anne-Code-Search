package question6;

import java.io.*;
import java.util.*;
import java.lang.*;

enum Planet{ //enum,parameter
	MERCURY(0.38), VENUS(0.91), EARTH(1), MARS(0.38), JUPITER(2.54), SATURN(1.08), URANUS(0.91), NEPTUNE(1.19); 	// parameter
	private double rg;
    Planet(double p) { 	// parameter
      rg = p;
    }
   double getRelativeG(){ 	// parameter
      return rg;
   } 
}

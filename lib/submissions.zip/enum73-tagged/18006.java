package q6;
import java.util.*;

enum Planet //enum,parameter
{
	MERCURY(0.38), VENUS(0.91), EARTH(1.00), MARS(0.38), JUPITER(2.54), SATURN(1.08), URANUS(.91), NEPTUNE(1.19); 	// parameter
	
	double relation;
	
	Planet(double x) //enum constructor 	// parameter
	{
		this.relation = x;
	}
	

	
}; //datatype Planet with attribute

public class planets 
{
	public static void main(String[] args) 
	{
		
		double weight = Double.parseDouble(args[0]); 	// array,parameter
		
		for(Planet p : Planet.values()) 	// parameter
		{
				double weightNew = weight*(p.relation); 	// parameter
				
				System.out.println("Your weight on "+p+" is "+weightNew+" kilograms."); //provided the input is also in kgs. 	// parameter,increment
		}
		
	}

}

//Planet planetName; //every class planets has an attribute planetName

	/*public planets(Planet planetName) //constructor for every class planets
	{
		this.planetName = planetName;
	}*/
	
	/*public double convert(double wt) //converts weight respectively
	{
		double wtnew = 0;
		
		switch(planetName) 	// parameter
		{
		case MERCURY: wtnew = wt*0.38; break;
		case VENUS: wtnew = wt*0.91; break;
		case EARTH: wtnew =  wt; break;
		case MARS: wtnew =  wt*0.38; break;
		case JUPITER: wtnew =  wt*2.54; break;
		case SATURN: wtnew = wt*1.08; break;
		case URANUS: wtnew = wt*0.91; break;
		case NEPTUNE: wtnew = wt*1.19; break;
		}
		
		return wtnew;
	}*/

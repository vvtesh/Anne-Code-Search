package Q6;

public enum quest6 { //enum,parameter
    Mars    (6.421e+23, 3.3972e6), 	// parameter
    Jupiter (1.9e+27,   7.1492e7), 	// parameter
    Mercury (3.303e+23, 2.4397e6), 	// parameter
    Venus   (4.869e+24, 6.0518e6), 	// parameter
    Earth   (5.976e+24, 6.37814e6), 	// parameter
    Saturn  (5.688e+26, 6.0268e7), 	// parameter
    Uranus  (8.686e+25, 2.5559e7), 	// parameter
    Neptune (1.024e+26, 2.4746e7); 	// parameter

    private double m;   
    private double r; 
    
    quest6(double m, double r) { 	// parameter
        this.m = m;
        this.r = r;
    }
    
    // univ. gravitational const.
    public static double G = 6.67300E-11;

    double surfg() { 	// parameter
        return G * m / (r * r);
    }
    double surfwt(double extmass) { 	// parameter
        return extmass * surfg(); 	// parameter
    }
    public static void main(String[] args) {
	
    	double earthwt = Double.parseDouble(args[0]); 	// array,parameter
    	double m = earthwt/Earth.surfg();
    	for (quest6 a : quest6.values()) 	// parameter
    		System.out.printf("Your weight on %s is %f%n",
                    a, a.surfwt(m));    } 	// parameter
}

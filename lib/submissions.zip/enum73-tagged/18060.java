public class CalculateAndDisplay
{
	CalculateAndDisplay(int n ) 	// parameter
	{
		Planets obj = (Planets) Enum.valueOf(Planets.class , "MERCURY") ; 	// parameter
		System.out.println("The weights on the planets are : "); 	// parameter
		switch(obj) 	// parameter
		{
			case MERCURY : System.out.println("Mercury : " + "\t" + n*0.378); 	// parameter,increment
			case VENUS :  System.out.println("Venus : " + "\t" + n*0.907); 	// parameter,increment
			case EARTH :  System.out.println("Earth : " + "\t" + n); 	// parameter,increment
			case MARS :  System.out.println("Mars : " + "\t\t" + n*0.377); 	// parameter,increment
			case JUPITER :  System.out.println("Jupiter : " + "\t" + n*2.364); 	// parameter,increment
			case SATURN :  System.out.println("Saturn : " + "\t" + n*0.916); 	// parameter,increment
			case URANUS :  System.out.println("Uranus : " + "\t" + n*0.889); 	// parameter,increment
			case NEPTUNE :  System.out.println("Neptune : " + "\t" + n*1.25); 	// parameter,increment
			case PLUTO :  System.out.println("Pluto : " + "\t" + n*0.067); 	// parameter,increment
		}
	}
}

package solarsystem;
public enum Planet //enum,parameter
{
	 MERCURY (3.7), 	// parameter
	 VENUS   (8.87), 	// parameter
	 EARTH   (9.758), 	// parameter
	 MARS    (3.711), 	// parameter
	 JUPITER (24.79), 	// parameter
	 SATURN  (10.44), 	// parameter
	 URANUS  (8.69), 	// parameter
	 NEPTUNE (11.65), 	// parameter
	 PLUTO   (0.658); 	// parameter
	 
	 private final double SurfaceGravity; 
	 Planet(double g)  	// parameter
	 {
		 this.SurfaceGravity=g;
	 }
	 private double surfaceGravity() 
	 { 
		 return SurfaceGravity; 
	 }
	 double surfaceWeight(double otherMass)  	// parameter
	 {
		 return otherMass * surfaceGravity(); 	// parameter
	 }
	 public static void PlanetsSurfaceWeightCalculator(double Weight)
	 {
		 double earthWeight=Weight;
		 double mass=earthWeight/EARTH.surfaceGravity();
		 System.out.println("Planet\t\tSurface Weight\n"); 	// parameter
		 for (Planet p : Planet.values()) 	// parameter
	           System.out.printf("%s\t\t%f%n",p, p.surfaceWeight(mass)); 	// parameter
	 }
}

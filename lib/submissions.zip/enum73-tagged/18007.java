package ap2014.asgnmnt1.mainclasses;

public class Question6 {

	
	public enum Planets {
		mercury, venus, earth, mars, jupiter, saturn, uranus, neptune
	}
	
	Planets planetname;
	public Question6(Planets inPlanet){
		this.planetname = inPlanet;
	}
	
	public void wght(double w) {
		if(planetname.equals(Planets.mercury)) 	// parameter
			System.out.println(planetname+" "+w*0.378+" kg"); 	// parameter,increment
		else if(planetname.equals(Planets.venus)) 	// parameter
			System.out.println(planetname+" "+ w*0.907+" kg"); 	// parameter,increment
		else if(planetname.equals(Planets.earth)) 	// parameter
			System.out.println(planetname+" "+w+" kg");				 	// parameter,increment
		else if(planetname.equals(Planets.mars)) 	// parameter
			System.out.println(planetname+" "+ w*0.377+" kg");	 	// parameter,increment
		else if(planetname.equals(Planets.jupiter)) 	// parameter
			System.out.println(planetname+" "+ w*2.364+" kg");		 	// parameter,increment
		else if(planetname.equals(Planets.saturn)) 	// parameter
			System.out.println(planetname+" "+ w*1.064+" kg");	 	// parameter,increment
		else if(planetname.equals(Planets.uranus)) 	// parameter
			System.out.println(planetname+" "+ w*1.064+" kg");	 	// parameter,increment
		else if(planetname.equals(Planets.neptune)) 	// parameter
			System.out.println(planetname+" "+ w*1.125+" kg");	 	// parameter,increment
	}
	
	public static void main(String args[])
	{
		
		double w = Double.parseDouble(args[0]); 	// array,parameter
		
		Question6 P1 = new Question6(Planets.mercury); 	// parameter
		P1.wght(w); 	// parameter
		
		Question6 P2 = new Question6(Planets.venus); 	// parameter
		P2.wght(w); 	// parameter
		
		Question6 P3 = new Question6(Planets.earth); 	// parameter
		P3.wght(w); 	// parameter
		
		Question6 P4 = new Question6(Planets.mars); 	// parameter
		P4.wght(w); 	// parameter
		
		Question6 P5 = new Question6(Planets.jupiter); 	// parameter
		P5.wght(w); 	// parameter
		
		Question6 P6 = new Question6(Planets.saturn); 	// parameter
		P6.wght(w); 	// parameter
		
		Question6 P7 = new Question6(Planets.uranus); 	// parameter
		P7.wght(w); 	// parameter
		
		Question6 P8 = new Question6(Planets.neptune); 	// parameter
		P8.wght(w); 	// parameter
		
	}
}

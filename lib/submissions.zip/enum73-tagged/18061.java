//Note: First take Command argument through run configuration then run your own choices of input
package apAssignment1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class EnumPlanet {
	public enum Planets { //enum,parameter

		MERCURY (0.38), 	// parameter
		VENUS   (0.91), 	// parameter
		EARTH   (1.0), 	// parameter
		MARS    (0.38), 	// parameter
		JUPITER (2.34), 	// parameter
		SATURN  (0.93), 	// parameter
		URANUS  (0.92), 	// parameter
		NEPTUNE (1.12); 	// parameter

		private final double sg;  // in kilograms
    
		Planets(double surfaceG){ 	// parameter
			this.sg = surfaceG ;
		}
    
		double getwgt(){ 	// parameter
			return sg ;
		}	
   }
	
    public static void main(String[] args) throws IOException {
    	System.out.print("Enter Your Weight in kg: ") ; 	// parameter
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 	// parameter
		if (args.length>0) { 	// conditional,parameter
			args[0]=br.readLine(); 	// array,parameter
			try{
				double earth_wgt = Double.parseDouble(args[0]); 	// array,parameter
				for (Planets p : Planets.values()) 	// parameter
					System.out.printf("Your weight on " + p + " is " + (p.getwgt()*earth_wgt) + " kg\n"); 	// parameter,increment
				}
			catch (NumberFormatException e) { 	// parameter
		        System.err.println("Command Line input '" + args[0] + "' must be an integer."); 	// array,parameter,increment
		        System.exit(1); 	// parameter
			}
		}
    }
}


public class Weight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int WeightofMan = Integer.parseInt(args[0]); 	// array,parameter
		
		
		Planet mercury = Planet.Mercury;
		Planet venus = Planet.Venus;
		Planet earth = Planet.Earth;
		Planet mars = Planet.Mars;
		Planet jupiter = Planet.Jupiter;
		Planet saturn = Planet.Saturn;
		Planet uranus = Planet.Uranus;
		Planet neptune = Planet.Neptune;
		


		mercury.w = 0.378 * WeightofMan;
		venus.w = 0.907 * WeightofMan;
		earth.w = WeightofMan;
		mars.w = 0.377 * WeightofMan;
		jupiter.w = 2.364 * WeightofMan;
		saturn.w = 1.064 * WeightofMan;
		uranus.w = 0.889 * WeightofMan;
		neptune.w =1.125 * WeightofMan;
		
		System.out.println("Weight on mercury is " +mercury.w); 	// parameter
		System.out.println("Weight on venus is " +venus.w); 	// parameter
		System.out.println("Weight on earth is " +earth.w); 	// parameter
		System.out.println("Weight on mars is " +mars.w); 	// parameter
		System.out.println("Weight on jupiter is " +jupiter.w); 	// parameter
		System.out.println("Weight on saturn is " +saturn.w); 	// parameter
		System.out.println("Weight on uranus is " +uranus.w); 	// parameter
		System.out.println("Weight on neptune is " +neptune.w); 	// parameter
		
		
		
	}

}

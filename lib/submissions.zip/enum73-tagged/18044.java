 
import java.util.*;
import java.lang.*;
import java.io.*;

enum Planet{ //enum,parameter
	Sun	(274), 	// parameter
	Jupiter	(24.92), 	// parameter
	Neptune	(11.15), 	// parameter
	Saturn	(10.44), 	// parameter
	Earth	(9.798), 	// parameter
	Uranus	(8.87), 	// parameter
	Venus	(8.87), 	// parameter
	Mars	(3.71), 	// parameter
	Mercury	(3.7), 	// parameter
	Moon	(1.62), 	// parameter
	Pluto	(0.58); 	// parameter

    double val;
    Planet(double x) 	// parameter
    {
    	val=x;
    }

    double ReturnValue() 	// parameter
    {
    	return val;
    }

}
 
class question6
{
	public static void main (String[] args) throws java.lang.Exception
	{
			double a;

			System.out.println("Hey, This is ultra advanced program which tells you your weight on any of the planet (of our galaxy) and the sun."); 	// parameter

			System.out.println("What are you waiting for ehh??? Input your mass!"); 	// parameter
			Scanner in = new Scanner(System.in); 	// parameter
			a = in.nextDouble(); 	// parameter

			for(Planet m : Planet.values()) { 	// parameter
			System.out.println(m + ":" + m.ReturnValue()*a);  	// parameter,increment


 			
	}
}
}

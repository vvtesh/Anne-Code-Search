package planets;

public enum question6 { //enum,parameter
	Mercury (3.303e+23, 2.4397e6), 	// parameter
    Venus   (4.869e+24, 6.0518e6), 	// parameter
    Earth   (5.976e+24, 6.37814e6), 	// parameter
    Mars    (6.421e+23, 3.3972e6), 	// parameter
    Jupiter (1.9e+27, 7.1492e7), 	// parameter
    Saturn  (5.688e+26, 6.0268e7), 	// parameter
    Uranus  (8.686e+25, 2.5559e7), 	// parameter
    Neptune (1.024e+26, 2.4746e7); 	// parameter

	public static double G = 6.67300e-11;
	private double m;
    private double r;
	
	public static void main(String[] args) 
	{
    System.out.println("enter weight of the person in kg \n"); 	// parameter
	int w;
	w = Integer.parseInt(args[0]); 	// array,parameter
	double m = w/Earth.gravity();
    for (question6 pl : question6.values()) 	// parameter
		System.out.printf("planet :- %s  \tweight = %f kg.\n", pl,pl.weight(m)); 	// parameter
    }
	
    question6(double mass, double radius) 	// parameter
	{
        this.m = mass;
        this.r = radius;
    }
    
    double gravity() 	// parameter
	{	return (G*m)/(r*r); 	// parameter
    }
    double weight(double M) 	// parameter
	{	double g = gravity(); 	// parameter
        return M*g;
    }
    

}

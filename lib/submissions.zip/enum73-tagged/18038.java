package commandline;

		public class Question6{
			public enum Planets {Mercury,Venus,Earth,Mars,Jupiter,Saturn,Uranus,Neptune};
			public static void main(String[] args) {
				// TODO Auto-generated method stub
				System.out.println("Enter weight in kgs:->"); 	// parameter
				int weight=Integer.parseInt(args[0]); 	// array,parameter
				double Mercury = (weight * .38);  	// parameter
				double Venus = (weight * .91);  	// parameter
				double Earth = (weight * 1);  	// parameter
				double Mars = (weight * .38);  	// parameter
				double Jupiter = (weight * 2.34);  	// parameter
				double Saturn = (weight * 1.06);  	// parameter
				double Uranus = (weight * .92);  	// parameter
				double Neptune = (weight * 1.19);  	// parameter
				
				System.out.println(Mercury); 	// parameter
				System.out.println(Venus); 	// parameter
				System.out.println(Earth); 	// parameter
				System.out.println(Mars); 	// parameter
				System.out.println(Jupiter); 	// parameter
				System.out.println(Saturn); 	// parameter
				System.out.println(Uranus); 	// parameter
				System.out.println(Neptune); 	// parameter
				
				   
				
			}

		}

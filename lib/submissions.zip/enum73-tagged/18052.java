package ap2014.asgnmnt1.question6;


public enum Planets  //enum,parameter
{
	MERCURY (3.303e+23, 2.4397e6), 	// parameter
    VENUS   (4.869e+24, 6.0518e6), 	// parameter
    EARTH   (5.976e+24, 6.37814e6), 	// parameter
    MARS    (6.421e+23, 3.3972e6), 	// parameter
    JUPITER (1.9e+27,   7.1492e7), 	// parameter
    SATURN  (5.688e+26, 6.0268e7), 	// parameter
    URANUS  (8.686e+25, 2.5559e7), 	// parameter
    NEPTUNE (1.024e+26, 2.4746e7); 	// parameter

    double mass;   // Kg
    double radius; // meters
    double G = 6.67300E-11; // universal gravitational constant 
    
    Planets(double mass, double radius)  	// parameter
    {
        this.mass = mass;
        this.radius = radius;
    }
    
    public double mass()
    {
    	return mass; 
    }
    
    public double radius()
    {
    	return radius; 
    }

    public double gravityFactor()
    {
        return G * mass / (radius * radius);
    }
    public double planetWeight(double mass1)
    {
        return mass1 * gravityFactor(); 	// parameter
    }
}

package planets;

import java.util.Scanner;

public class planetsenum  {
 
    public enum Planets{
        MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE
    }
 
    Planets cName;
 
    public planetsenum(Planets cName) {
        this.cName = cName;
    }
    
    
 
    public void weightcalculate(float weight) {
    	float finalweight;
        switch (cName) 	// parameter
        {
        
        case MERCURY:
        {finalweight = (float)(weight * (0.38)); 	// parameter
            System.out.println(finalweight+ "is the user weight on Mercury"); 	// parameter
            break;
        }
        
        case VENUS:
        {finalweight = (float)(weight*0.91); 	// parameter
            System.out.println(finalweight + "is the user weight on Venus"); 	// parameter
            break;
        }
      
        case EARTH:
        {finalweight = weight*1;
            System.out.println(finalweight+"is the user weight on Earth"); 	// parameter
            break;
        }
        
        case MARS:
        {finalweight = (float)(weight*(0.38)); 	// parameter
            System.out.println(finalweight + "is the user weight on Mars"); 	// parameter
            break;
        }
        
        case JUPITER:
        {finalweight = (float)(weight*2.34); 	// parameter
            System.out.println(finalweight + "is the user weight on Jupiter"); 	// parameter
            break;
        }
        
        
        case SATURN:
        {finalweight = (float)(weight*0.93); 	// parameter
            System.out.println(finalweight + "is the user weight on Saturn"); 	// parameter
            break;
        }
        
        
        case URANUS:
        {finalweight = (float)(weight*0.92); 	// parameter
            System.out.println(finalweight + " is the user weight on Uranus"); 	// parameter
            break;
        }
        
        case NEPTUNE:
        {finalweight = (float)(weight*1.12); 	// parameter
            System.out.println(finalweight + " is the user weight on Neptune"); 	// parameter
            break;
        }
        
        
        
        
        }
    }
 
    public static void main(String[] args) {
    	
    	float userweight;
    	Scanner in = new Scanner(System.in); 	// parameter
        System.out.println("Enter user weight:"); 	// parameter
        userweight = in.nextFloat(); 	// parameter
                
        
        planetsenum mercury = new planetsenum(Planets.MERCURY); 	// parameter
        mercury.weightcalculate(userweight); 	// parameter
    
         
        planetsenum venus = new planetsenum(Planets.VENUS); 	// parameter
        venus.weightcalculate(userweight); 	// parameter
        
        planetsenum earth = new planetsenum(Planets.EARTH); 	// parameter
        earth.weightcalculate(userweight); 	// parameter
        
        planetsenum mars = new planetsenum(Planets.MARS); 	// parameter
        mars.weightcalculate(userweight); 	// parameter
        
        planetsenum jupiter = new planetsenum(Planets.JUPITER); 	// parameter
        jupiter.weightcalculate(userweight); 	// parameter
        
        planetsenum saturn = new planetsenum(Planets.SATURN); 	// parameter
        saturn.weightcalculate(userweight); 	// parameter
        
        
        planetsenum uranus = new planetsenum(Planets.URANUS); 	// parameter
        uranus.weightcalculate(userweight); 	// parameter
        
        planetsenum neptune = new planetsenum(Planets.NEPTUNE); 	// parameter
        neptune.weightcalculate(userweight); 	// parameter
    }
}

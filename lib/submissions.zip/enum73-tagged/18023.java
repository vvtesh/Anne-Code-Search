package quest6;
import java.util.*;

import java.util.Scanner;

public class planet {
	static planeum p;
	public static void main(String[] args){
		
	/*public planet(planeum p){
		this.p= p;
	}*/
	System.out.println("Enter the weight"); 	// parameter
	float n, x;
	Scanner in = new Scanner(System.in); 	// parameter
	n = in.nextInt(); 	// parameter
	public void tellweight(n){
		
		switch (p){ 	// parameter
		case mercury:{
			x = (float)(n * 0.38); 	// parameter
			System.out.println(x+ " weight on the mercury"); 	// parameter
			break;}
		case venus:{
			x = (float)(n * 0.91); 	// parameter
			System.out.println(x + "weight on the venus"); 	// parameter
			break;}
		case earth:{
			x = (float)(n *1.0); 	// parameter
			System.out.println(x+"weight on the earth"); 	// parameter
			break;}
		case mars:{
			x = (float)(n*1.52); 	// parameter
			System.out.println(x+"weight on the mars"); 	// parameter
			break;
		}
		case jupitar:{
			x = (float)(n* 5.2); 	// parameter
			System.out.println(x+"weight on jupitar"); 	// parameter
			break;}
		case saturn:{
			x = (float)(n* 9.45); 	// parameter
			System.out.println(x + "weight on saturn"); 	// parameter
			break;
		}
		case uranus:{
			x = (float)(n*19.2); 	// parameter
			System.out.println(x+"weight on uranus"); 	// parameter
			break;
		}
		case neptune:{
			x = (float)(n* 30.06); 	// parameter
			System.out.println(x+"weight on neptune"); 	// parameter
			break;}
			
		}
	planet mercury = new planet(planets.MERCURY); 	// parameter
	mercury.tellweight(); 	// parameter
	planet venus = new planet(planets.VENUS); 	// parameter
	venus.tellweight(); 	// parameter
	planet earth = new planet(planeta, EARTH); 	// parameter
	earth.tellweight(); 	// parameter
	planet mars = new planet(planet.MARS); 	// parameter
	earth.tellweight(); 	// parameter
	planet jupiter = new planet(planet.JUPITER); 	// parameter
	jupiter.tellweight(); 	// parameter
	planet saturn = new planet(planet.SATURN); 	// parameter
	saturn.tellweight(); 	// parameter
	planet uranus = new planet(planet.URANUS); 	// parameter
	uranus.tellweight(); 	// parameter
	planet neptune = new planet(planets.NEPTUNE); 	// parameter
	neptune.tellweight(); 	// parameter
	
	
}

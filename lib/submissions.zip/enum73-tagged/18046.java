package Question6;

//import java.io.*;
//import java.util.*;

enum Planets
{
	MERCURY,
	VENUS,
	EARTH,
	MARS,
	JUPITER,
	SATURN,
	URANUS,
	NEPTUNE
};

public class Question6 
{	
    public void calculate(int weight) 
    {
        
            System.out.println("Your weight on Mercury is : " + (0.38*weight)); 	// parameter
            System.out.println("Your weight on Venus is : " + (0.91*weight)); 	// parameter
            System.out.println("Your weight on Earth is : " + (weight)); 	// parameter
            System.out.println("Your weight on Mars is : " + (0.38*weight)); 	// parameter
            System.out.println("Your weight on Jupiter is : " + (2.54*weight)); 	// parameter
            System.out.println("Your weight on Saturn is : " + (1.08*weight)); 	// parameter
            System.out.println("Your weight on Uranus is : " + (0.91*weight)); 	// parameter
            System.out.println("Your weight on Neptune is : " + (1.19*weight)); 	// parameter
     }
    

    public static void main(String[] args) 
    {
    	int weight = Integer.parseInt(args[0]); 	// array,parameter
       //Scanner scan = new Scanner(System.in);
       // System.out.println("Enter your weight on Earth : ");
       // weight = scan.nextInt();
        Question6 call = new Question6(); 	// parameter
        call.calculate(weight);     	// parameter
    }
}

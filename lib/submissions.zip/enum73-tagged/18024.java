package question6;

public enum Planets{ //enum,parameter
	   MERCURY(0.38),VENUS(0.91),EARTH(1.0),MARS(0.38),JUPITER(2.36),SATURN(0.91),URANUS(0.89),NEPTUNE(1.12); 	// parameter
	   
	   private double factor;
	   Planets(double factor) 	// parameter
	   {
		   this.factor = factor;
	   }
	   
	  
	   public double Weight(double EarthMass) {
	        return EarthMass * factor;
	    }

}

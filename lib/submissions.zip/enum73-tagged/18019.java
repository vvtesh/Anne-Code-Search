package ap2014.assignment1.question6;

public enum Planets{ //enum,parameter
	MARS		(0.38), 	// parameter
	JUPITER		(2.54), 	// parameter
	MERCURY		(0.38), 	// parameter
	PLUTO		(0.06), 	// parameter
	EARTH		(1), 	// parameter
	SATURN		(1.08), 	// parameter
	VENUS		(0.91), 	// parameter
	URANUS		(0.91), 	// parameter
	NEPTUNE		(1.19); 	// parameter

	private final double gravityconstant;
	Planets(double gravityconstant) 	// parameter
	{
		this.gravityconstant=gravityconstant;
	}
	public double getPlanets()
	{
		return this.gravityconstant;
	}
}

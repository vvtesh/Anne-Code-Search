package question6;

public enum Planet{//enum,parameter 
	MERCURY	(3.7), 		//parameter
	VENUS	(8.872), 	// parameter
	EARTH	(9.78), 	// parameter
	MARS	(3.7), 		// parameter
	JUPITER	(24.79), 	// parameter
	SATURN	(10.44), 	// parameter
	URANUS	(8.87), 	// parameter
	NEPTUNE	(11.15); 	// parameter

	private final double surfaceGravity;
	
	PlaneT (double surfaceGravity){ 	// parameter
		this.surfaceGravity = surfaceGravity;
	}

	public double getSG() {
		return surfaceGravity;
	}

	
}

package q6;



public class planet {

	public enum Planets{
		Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
	}
	
	Planets	pname;
	
	public planet (Planets pname){
	this.pname=pname;
	}
	
	public void planetweight(double weight){
		switch(pname) 	// parameter
		{
		case Mercury:{
			weight= weight * 0.38;
			System.out.println(pname+" "+weight); 	// parameter,increment
			break;
			
		}
		case Venus:{
			weight= weight * 0.91;
			System.out.println(pname+" "+weight); 	// parameter,increment
			break;
			
		}
		case Earth:{
			weight= weight * 1.0;
			System.out.println(pname+" "+weight); 	// parameter,increment
			break;
			
		}
		case Mars:{
			weight= weight * 0.38;
			System.out.println(pname+" "+weight); 	// parameter,increment
			break;
			
		}
		case Jupiter:{
			weight= weight * 2.36;
			System.out.println(pname+" "+weight); 	// parameter,increment
			break;
			
		}
		case Saturn:{
			weight= weight * 0.91;
			System.out.println(pname+" "+weight); 	// parameter,increment
			break;
			
		}
		case Uranus:{
			weight= weight * 0.89;
			System.out.println(pname+" "+weight); 	// parameter,increment
			break;
			
		}
		case Neptune:{
			weight= weight * 1.12;
			System.out.println(pname+" "+weight); 	// parameter,increment
			break;
			
		}
		default: break;
		
		}
	}
	
	public static void main(String[] args){
		
		int weight=Integer.parseInt(args[0]); 	// array,parameter
		
	    planet Merc = new planet(Planets.Mercury); 	// parameter
        Merc.planetweight(weight); 	// parameter
        
        planet Ven = new planet(Planets.Venus); 	// parameter
        Ven.planetweight(weight); 	// parameter
        
        planet Ear = new planet(Planets.Earth); 	// parameter
        Ear.planetweight(weight); 	// parameter
        
        planet Mar = new planet(Planets.Mars); 	// parameter
        Mar.planetweight(weight); 	// parameter
        
        planet Jup = new planet(Planets.Jupiter); 	// parameter
        Jup.planetweight(weight); 	// parameter
        
        planet Sat = new planet(Planets.Saturn); 	// parameter
        Sat.planetweight(weight); 	// parameter
        
        planet Ura = new planet(Planets.Uranus); 	// parameter
        Ura.planetweight(weight); 	// parameter
        
        planet Nep = new planet(Planets.Neptune); 	// parameter
        Nep.planetweight(weight); 	// parameter
        
	}
}


public enum Planet { //enum,parameter
	MERCURY (3.303e+23, 2.4397e6), 	// parameter
    VENUS   (4.869e+24, 6.0518e6), 	// parameter
    EARTH   (5.976e+24, 6.37814e6), 	// parameter
    MARS    (6.421e+23, 3.3972e6), 	// parameter
    JUPITER (1.9e+27,   7.1492e7), 	// parameter
    SATURN  (5.688e+26, 6.0268e7), 	// parameter
    URANUS  (8.686e+25, 2.5559e7), 	// parameter
    NEPTUNE (1.024e+26, 2.4746e7); 	// parameter
	
	double mass;
	double radius;
	private Planet(double m,double r){
		mass = m;
		radius = r;
	}
	public static final double G = 6.67300e-11;
	
	public double weightOnSurface(double m){
		return (G*m*mass)/(radius*radius); 	// parameter
	}
	public static double Mass(double w){
		return w/(G*EARTH.mass/(EARTH.radius*EARTH.radius));
	}
	
}


import java.util.Scanner;

public class Question6{
    public enum Planets{ //enum,parameter
        Mercury (3.7), Venus (8.87), Earth (9.978), Mars (3.71), Jupiter (24.92), Saturn (10.44), Uranus (8.87), Neptune (11.15), Pluto (0.58); 	// parameter
        private double specificGravity;
        private Planets(double sg) {
                this.specificGravity = sg;
        }
        public double getSpecficGravity(){
            return this.specificGravity;
        }
    };
    public static void main(String args[]){
        Scanner in=new Scanner(System.in); 	// parameter
        System.out.print("Enter weight on Earth (Kg): "); 	// parameter
        double weight = in.nextDouble(); 	// parameter
        //System.out.println("Entered wieght on Earth : "+ weight);
        for (Planets planet : Planets.values()) { 	// parameter
            double changedWeight= (double)(weight*planet.getSpecficGravity())/Planets.Earth.getSpecficGravity(); 	// parameter
            System.out.println("Weight on  "+ planet.name()+" is : "+ changedWeight + " Kg"); 	// parameter,increment
        }
    
    }
}

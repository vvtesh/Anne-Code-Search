package assign1_Q6;
import java.util.*;
public enum Question6 { //enum,parameter
    MERCURY (3.61), 	// parameter
    VENUS   (8.83), 	// parameter
    EARTH   (9.8), 	// parameter
    MARS    (3.75), 	// parameter
    JUPITER (26.0), 	// parameter
    SATURN  (11.2), 	// parameter
    URANUS  (10.5), 	// parameter
    NEPTUNE (13.3); 	// parameter

    private final double gravity;   // in kilograms
    Question6(double gravity) { 	// parameter
        this.gravity= gravity;
    }
    /*double surfaceWeight(double otherMass) {
        return otherMass * surfaceGravity(); 	// parameter
    }*/
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in); 	// parameter
        double earthWeight= scan.nextDouble(); 	// parameter
        double mass = earthWeight/9.8;
        for (Question6 p : Question6.values()) 	// parameter
        {
        	System.out.println("Your weight on "+p+" is "+ mass*p.gravity); 	// parameter,increment
           //System.out.printf("Your weight on %s is %f%n",p, p.surfaceWeight(mass));
        }
    }
}

package question6;

public enum Planet { //enum,parameter
    MERCURY (3.303e+23, 2.4397e6), 	// parameter
    VENUS   (4.869e+24, 6.0518e6), 	// parameter
    EARTH   (5.976e+24, 6.37814e6), 	// parameter
    MARS    (6.421e+23, 3.3972e6), 	// parameter
    JUPITER (1.9e+27,   7.1492e7), 	// parameter
    SATURN  (5.688e+26, 6.0268e7), 	// parameter
    URANUS  (8.686e+25, 2.5559e7), 	// parameter
    NEPTUNE (1.024e+26, 2.4746e7); 	// parameter

    public  double mass;   // in kgs
    public  double radius; // in meters
    Planet(double mass, double radius) { 	// parameter
        this.mass = mass;
        this.radius = radius;
    }
    public double mass() { 
    	return mass; 
    }
    public double radius(){ 
    	return radius; 
    }
    public double surfaceWeight(double otherMass) {
        return otherMass * surfaceGravity(); 	// parameter
    }
     
    public static final double G = 6.67300E-11;

    public double surfaceGravity() {
        return G * mass / (radius * radius);
    }
    
    public static void main(String[] args) {
		double earthWeight = Double.parseDouble(args[0]); 	// array,parameter
		double mass = earthWeight/EARTH.surfaceGravity();
		System.out.println("Planets" +"  " + "Weights"); 	// parameter,increment
		for (Planet p : Planet.values()) 	// parameter
			System.out.println(p + "  "+ p.surfaceWeight(mass)); 	// parameter,increment
                         
}
    
    
}
